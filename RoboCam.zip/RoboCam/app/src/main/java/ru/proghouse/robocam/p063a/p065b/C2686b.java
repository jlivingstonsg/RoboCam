package ru.proghouse.robocam.p063a.p065b;

import java.util.List;

/* renamed from: ru.proghouse.robocam.a.b.b */
public interface C2686b {
    /* renamed from: a */
    List<C2694g> mo7742a(int i);
}
