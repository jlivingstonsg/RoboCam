package ru.proghouse.robocam;

/* renamed from: ru.proghouse.robocam.j */
public class C2708j {

    /* renamed from: a */
    public volatile boolean f7572a = false;

    /* renamed from: b */
    public byte[] f7573b = null;

    /* renamed from: c */
    public int f7574c = 0;

    /* renamed from: d */
    public byte[] f7575d = null;

    /* renamed from: e */
    public byte[] f7576e = null;

    /* renamed from: f */
    public byte[] f7577f = null;

    /* renamed from: g */
    public byte[] f7578g = null;

    /* renamed from: h */
    public byte[] f7579h = null;

    /* renamed from: i */
    public int f7580i = 0;

    /* renamed from: j */
    public int f7581j = 0;

    /* renamed from: k */
    public int f7582k = 0;

    /* renamed from: l */
    public int f7583l = 0;

    /* renamed from: m */
    public int f7584m = 0;

    /* renamed from: n */
    public int f7585n = 0;

    /* renamed from: o */
    public volatile boolean f7586o = false;

    /* renamed from: p */
    public volatile int f7587p = 0;

    /* renamed from: a */
    public void mo7827a() {
        this.f7572a = false;
        this.f7586o = false;
        this.f7587p = 0;
    }
}
