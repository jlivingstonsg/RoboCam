package ru.proghouse.robocam;

/* renamed from: ru.proghouse.robocam.g */
public class C2705g {

    /* renamed from: a */
    private int f7565a;

    /* renamed from: b */
    private String f7566b;

    public C2705g(int i, String str) {
        this.f7565a = i;
        this.f7566b = str;
    }

    /* renamed from: a */
    public int mo7825a() {
        return this.f7565a;
    }

    /* renamed from: b */
    public String mo7826b() {
        return this.f7566b;
    }
}
