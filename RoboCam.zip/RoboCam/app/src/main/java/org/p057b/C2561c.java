package org.p057b;

import java.util.concurrent.Executor;

/* renamed from: org.b.c */
public interface C2561c extends Executor {
    /* renamed from: a */
    C2610f mo7426a();
}
