package org.p057b.p058a;

import java.util.Date;
import org.p057b.C2608d;
import org.p057b.C2609e;
import org.p057b.C2610f;
import org.p057b.C2611g;

/* renamed from: org.b.a.a */
public class C2547a implements C2609e {
    @Override // org.p057b.C2609e
    /* renamed from: a */
    public void mo7412a(C2610f fVar, C2611g gVar, C2608d dVar) {
        if (!gVar.mo7468a("Date")) {
            gVar.mo7466a("Date", new Date());
        }
        dVar.mo7453a();
    }
}
