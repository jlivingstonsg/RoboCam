package org.p057b.p061c;

import org.p035a.p036a.p039c.C2384f;
import org.p035a.p036a.p039c.C2396p;
import org.p035a.p036a.p043d.p044a.p050e.C2473b;

/* renamed from: org.b.c.m */
public class C2585m extends C2473b {
    /* access modifiers changed from: protected */
    @Override // org.p035a.p036a.p043d.p044a.p050e.C2473b
    /* renamed from: a */
    public Object mo7152a(C2396p pVar, C2384f fVar, Object obj) {
        return obj instanceof C2574f ? ((C2574f) obj).mo7444a() : obj;
    }
}
