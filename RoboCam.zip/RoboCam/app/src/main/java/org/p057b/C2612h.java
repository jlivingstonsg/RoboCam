package org.p057b;

/* renamed from: org.b.h */
public interface C2612h extends C2553b<C2612h> {
    /* renamed from: a */
    C2612h mo7479a(String str, C2615k kVar);
}
