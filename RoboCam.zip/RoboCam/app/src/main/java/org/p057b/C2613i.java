package org.p057b;

import org.p057b.p061c.C2593r;

/* renamed from: org.b.i */
public class C2613i {
    /* renamed from: a */
    public static C2612h m10267a(int i) {
        return new C2593r(i);
    }
}
