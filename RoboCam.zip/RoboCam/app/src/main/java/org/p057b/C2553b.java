package org.p057b;

import java.util.concurrent.Future;

/* renamed from: org.b.b */
public interface C2553b<T> {
    /* renamed from: a */
    Future<? extends T> mo7415a();

    /* renamed from: b */
    Future<? extends T> mo7416b();
}
