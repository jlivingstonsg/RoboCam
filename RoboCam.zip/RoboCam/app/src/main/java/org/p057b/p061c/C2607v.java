package org.p057b.p061c;

import org.p035a.p036a.p039c.C2395o;

/* renamed from: org.b.c.v */
public interface C2607v {
    /* renamed from: a */
    void mo7445a(C2598s sVar);

    /* renamed from: a */
    boolean mo7446a();

    /* renamed from: b */
    C2395o mo7447b();

    /* renamed from: c */
    C2395o mo7448c();
}
