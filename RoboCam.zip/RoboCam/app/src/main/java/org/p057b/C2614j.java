package org.p057b;

/* renamed from: org.b.j */
public interface C2614j extends C2561c {
    /* renamed from: a */
    C2614j mo7492a(String str);

    /* renamed from: a */
    C2614j mo7493a(byte[] bArr);

    /* renamed from: b */
    C2614j mo7497b();
}
