package org.p057b.p058a;

import org.p057b.C2608d;
import org.p057b.C2609e;
import org.p057b.C2610f;
import org.p057b.C2611g;
import org.p057b.C2615k;

/* renamed from: org.b.a.b */
public class C2550b implements C2609e {

    /* renamed from: a */
    private final C2615k f6826a;

    public C2550b(C2615k kVar) {
        this.f6826a = kVar;
    }

    @Override // org.p057b.C2609e
    /* renamed from: a */
    public void mo7412a(C2610f fVar, C2611g gVar, C2608d dVar) {
        dVar.mo7452a(this.f6826a);
    }
}
