package org.p057b;

import java.util.concurrent.Executor;

/* renamed from: org.b.d */
public interface C2608d extends Executor {
    /* renamed from: a */
    C2614j mo7452a(C2615k kVar);

    /* renamed from: a */
    void mo7453a();

    /* renamed from: a */
    void mo7454a(C2610f fVar, C2611g gVar);
}
