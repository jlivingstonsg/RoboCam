package org.p057b.p060b;

import java.io.UnsupportedEncodingException;

/* renamed from: org.b.b.e */
public class C2559e extends UnsupportedEncodingException {
    public C2559e(String str) {
        super(str);
    }
}
