package org.p057b.p058a.p059a;

import java.lang.Thread;

/* renamed from: org.b.a.a.b */
public class C2549b implements Thread.UncaughtExceptionHandler {
    public void uncaughtException(Thread thread, Throwable th) {
    }
}
