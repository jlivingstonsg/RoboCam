package org.p057b;

/* renamed from: org.b.e */
public interface C2609e {
    /* renamed from: a */
    void mo7412a(C2610f fVar, C2611g gVar, C2608d dVar);
}
