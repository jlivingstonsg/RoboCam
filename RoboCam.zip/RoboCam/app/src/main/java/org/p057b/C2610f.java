package org.p057b;

/* renamed from: org.b.f */
public interface C2610f {
    /* renamed from: a */
    String mo7459a();

    /* renamed from: a */
    String mo7460a(String str);
}
