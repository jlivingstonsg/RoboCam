package org.p057b;

/* renamed from: org.b.k */
public interface C2615k {
    /* renamed from: a */
    void mo7406a(C2614j jVar);

    /* renamed from: a */
    void mo7407a(C2614j jVar, String str);

    /* renamed from: a */
    void mo7408a(C2614j jVar, byte[] bArr);

    /* renamed from: b */
    void mo7409b(C2614j jVar);

    /* renamed from: b */
    void mo7410b(C2614j jVar, byte[] bArr);

    /* renamed from: c */
    void mo7411c(C2614j jVar, byte[] bArr);
}
