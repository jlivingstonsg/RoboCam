package org.p057b;

/* renamed from: org.b.a */
public class C2546a implements C2615k {
    @Override // org.p057b.C2615k
    /* renamed from: a */
    public void mo7406a(C2614j jVar) {
    }

    @Override // org.p057b.C2615k
    /* renamed from: a */
    public void mo7407a(C2614j jVar, String str) {
    }

    @Override // org.p057b.C2615k
    /* renamed from: a */
    public void mo7408a(C2614j jVar, byte[] bArr) {
    }

    @Override // org.p057b.C2615k
    /* renamed from: b */
    public void mo7409b(C2614j jVar) {
    }

    @Override // org.p057b.C2615k
    /* renamed from: b */
    public void mo7410b(C2614j jVar, byte[] bArr) {
        jVar.mo7493a(bArr);
    }

    @Override // org.p057b.C2615k
    /* renamed from: c */
    public void mo7411c(C2614j jVar, byte[] bArr) {
    }
}
