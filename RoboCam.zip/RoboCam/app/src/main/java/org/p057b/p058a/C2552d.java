package org.p057b.p058a;

import org.p057b.C2608d;
import org.p057b.C2609e;
import org.p057b.C2610f;
import org.p057b.C2611g;

/* renamed from: org.b.a.d */
public class C2552d implements C2609e {

    /* renamed from: a */
    private final String f6829a;

    public C2552d(String str) {
        this.f6829a = str;
    }

    @Override // org.p057b.C2609e
    /* renamed from: a */
    public void mo7412a(C2610f fVar, C2611g gVar, C2608d dVar) {
        gVar.mo7465a("Server", this.f6829a);
        dVar.mo7453a();
    }
}
