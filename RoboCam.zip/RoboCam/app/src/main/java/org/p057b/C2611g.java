package org.p057b;

import java.util.Date;

/* renamed from: org.b.g */
public interface C2611g {
    /* renamed from: a */
    C2611g mo7463a();

    /* renamed from: a */
    C2611g mo7464a(int i);

    /* renamed from: a */
    C2611g mo7465a(String str, String str2);

    /* renamed from: a */
    C2611g mo7466a(String str, Date date);

    /* renamed from: a */
    C2611g mo7467a(Throwable th);

    /* renamed from: a */
    boolean mo7468a(String str);
}
