package org.p035a.p036a.p054f;

/* renamed from: org.a.a.f.d */
public interface C2542d {

    /* renamed from: a */
    public static final C2542d f6819a = new C2542d() {
        /* class org.p035a.p036a.p054f.C2542d.C25431 */

        @Override // org.p035a.p036a.p054f.C2542d
        /* renamed from: a */
        public String mo7404a(String str, String str2) {
            return str2;
        }
    };

    /* renamed from: b */
    public static final C2542d f6820b = new C2542d() {
        /* class org.p035a.p036a.p054f.C2542d.C25442 */

        @Override // org.p035a.p036a.p054f.C2542d
        /* renamed from: a */
        public String mo7404a(String str, String str2) {
            return null;
        }
    };

    /* renamed from: a */
    String mo7404a(String str, String str2);
}
