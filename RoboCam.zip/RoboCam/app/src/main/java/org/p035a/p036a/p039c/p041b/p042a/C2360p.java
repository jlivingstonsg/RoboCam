package org.p035a.p036a.p039c.p041b.p042a;

import java.util.concurrent.Executor;

/* renamed from: org.a.a.c.b.a.p */
public class C2360p extends C2345d<C2358o> {
    public C2360p(Executor executor, int i) {
        super(executor, i);
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public C2358o mo7103a(Executor executor, boolean z) {
        return new C2358o(executor, z);
    }
}
