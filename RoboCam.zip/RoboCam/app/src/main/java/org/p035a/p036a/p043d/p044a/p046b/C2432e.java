package org.p035a.p036a.p043d.p044a.p046b;

import org.p035a.p036a.p039c.C2384f;
import org.p035a.p036a.p039c.C2389k;
import org.p035a.p036a.p039c.C2398r;

/* renamed from: org.a.a.d.a.b.e */
final class C2432e implements C2389k {

    /* renamed from: a */
    static final C2389k f6392a = new C2432e();

    private C2432e() {
    }

    @Override // org.p035a.p036a.p039c.C2389k
    /* renamed from: a */
    public C2384f mo7116a(C2398r rVar) {
        throw new UnsupportedOperationException();
    }

    @Override // org.p035a.p036a.p054f.C2541c, org.p035a.p036a.p039c.C2389k
    /* renamed from: d */
    public void mo6810d() {
    }
}
