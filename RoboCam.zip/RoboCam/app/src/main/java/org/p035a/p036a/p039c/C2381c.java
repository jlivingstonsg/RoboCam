package org.p035a.p036a.p039c;

/* renamed from: org.a.a.c.c */
public abstract class C2381c extends C2296a implements C2327as {
    protected C2381c(C2389k kVar, C2398r rVar, C2401u uVar) {
        super(null, kVar, rVar, uVar);
    }

    @Override // org.p035a.p036a.p039c.C2384f, org.p035a.p036a.p039c.C2296a
    /* renamed from: a */
    public C2390l mo6892a(Object obj) {
        return mo6901f();
    }

    /* access modifiers changed from: protected */
    @Override // org.p035a.p036a.p039c.C2296a
    /* renamed from: a */
    public void mo6894a(int i) {
    }

    @Override // org.p035a.p036a.p039c.C2296a
    /* renamed from: k */
    public int mo6907k() {
        return 0;
    }

    @Override // org.p035a.p036a.p039c.C2384f
    /* renamed from: l */
    public boolean mo7120l() {
        return false;
    }
}
