package org.p035a.p036a.p039c;

import java.util.EventListener;

/* renamed from: org.a.a.c.m */
public interface C2391m extends EventListener {

    /* renamed from: a */
    public static final C2391m f6335a = new C2391m() {
        /* class org.p035a.p036a.p039c.C2391m.C23921 */

        @Override // org.p035a.p036a.p039c.C2391m
        /* renamed from: a */
        public void mo6933a(C2390l lVar) {
            lVar.mo6939c().mo6905i();
        }
    };

    /* renamed from: b */
    public static final C2391m f6336b = new C2391m() {
        /* class org.p035a.p036a.p039c.C2391m.C23932 */

        @Override // org.p035a.p036a.p039c.C2391m
        /* renamed from: a */
        public void mo6933a(C2390l lVar) {
            if (!lVar.mo6949d()) {
                lVar.mo6939c().mo6905i();
            }
        }
    };

    /* renamed from: a */
    void mo6933a(C2390l lVar);
}
