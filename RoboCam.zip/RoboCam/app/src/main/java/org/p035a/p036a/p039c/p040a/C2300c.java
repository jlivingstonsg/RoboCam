package org.p035a.p036a.p039c.p040a;

import java.util.EventListener;

/* renamed from: org.a.a.c.a.c */
public interface C2300c extends EventListener {
    /* renamed from: a */
    void mo6914a(C2299b bVar);
}
