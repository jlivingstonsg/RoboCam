package org.p035a.p036a.p039c;

/* renamed from: org.a.a.c.ar */
public interface C2326ar {
    /* renamed from: a */
    C2325aq mo7015a();
}
