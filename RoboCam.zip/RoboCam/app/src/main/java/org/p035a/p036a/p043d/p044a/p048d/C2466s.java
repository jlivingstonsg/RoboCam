package org.p035a.p036a.p043d.p044a.p048d;

/* renamed from: org.a.a.d.a.d.s */
public interface C2466s extends C2460o {
    /* renamed from: g */
    C2465r mo7207g();

    /* renamed from: h */
    String mo7208h();
}
