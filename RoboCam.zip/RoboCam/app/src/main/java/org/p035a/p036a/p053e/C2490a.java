package org.p035a.p036a.p053e;

/* renamed from: org.a.a.e.a */
public abstract class C2490a implements C2491b {
    protected C2490a() {
    }
}
