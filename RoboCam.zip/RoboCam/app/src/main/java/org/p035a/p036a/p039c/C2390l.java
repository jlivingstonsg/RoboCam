package org.p035a.p036a.p039c;

/* renamed from: org.a.a.c.l */
public interface C2390l {
    /* renamed from: a */
    void mo6936a(C2391m mVar);

    /* renamed from: a */
    boolean mo6909a();

    /* renamed from: a */
    boolean mo6937a(long j, long j2, long j3);

    /* renamed from: a */
    boolean mo6910a(Throwable th);

    /* renamed from: b */
    void mo6938b(C2391m mVar);

    /* renamed from: c */
    C2384f mo6939c();

    /* renamed from: d */
    boolean mo6949d();

    /* renamed from: e */
    Throwable mo6950e();

    /* renamed from: f */
    C2390l mo6940f();

    /* renamed from: g */
    C2390l mo6941g();
}
