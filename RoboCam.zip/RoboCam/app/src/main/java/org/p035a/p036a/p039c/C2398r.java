package org.p035a.p036a.p039c;

import java.util.Map;

/* renamed from: org.a.a.c.r */
public interface C2398r {
    /* renamed from: a */
    C2390l mo6954a(Runnable runnable);

    /* renamed from: a */
    C2395o mo6955a();

    /* renamed from: a */
    C2395o mo6956a(String str);

    /* renamed from: a */
    void mo6957a(String str, String str2, C2395o oVar);

    /* renamed from: a */
    void mo6958a(String str, C2395o oVar);

    /* renamed from: a */
    void mo6960a(C2384f fVar, C2401u uVar);

    /* renamed from: a */
    void mo6961a(C2387i iVar);

    /* renamed from: a */
    void mo6963a(C2395o oVar);

    /* renamed from: b */
    C2384f mo6965b();

    /* renamed from: b */
    C2395o mo6966b(String str, String str2, C2395o oVar);

    /* renamed from: b */
    void mo6971b(C2387i iVar);

    /* renamed from: c */
    Map<String, C2395o> mo6972c();
}
