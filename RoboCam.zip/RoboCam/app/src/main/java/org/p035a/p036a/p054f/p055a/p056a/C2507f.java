package org.p035a.p036a.p054f.p055a.p056a;

import android.support.v8.renderscript.Allocation;
import android.support.v8.renderscript.ScriptIntrinsicBLAS;

/* renamed from: org.a.a.f.a.a.f */
final class C2507f {

    /* renamed from: a */
    static final int[] f6703a = {96, 7, 256, 0, 8, 80, 0, 8, 16, 84, 8, 115, 82, 7, 31, 0, 8, 112, 0, 8, 48, 0, 9, 192, 80, 7, 10, 0, 8, 96, 0, 8, 32, 0, 9, 160, 0, 8, 0, 0, 8, Allocation.USAGE_SHARED, 0, 8, 64, 0, 9, 224, 80, 7, 6, 0, 8, 88, 0, 8, 24, 0, 9, 144, 83, 7, 59, 0, 8, 120, 0, 8, 56, 0, 9, 208, 81, 7, 17, 0, 8, 104, 0, 8, 40, 0, 9, 176, 0, 8, 8, 0, 8, 136, 0, 8, 72, 0, 9, 240, 80, 7, 4, 0, 8, 84, 0, 8, 20, 85, 8, 227, 83, 7, 43, 0, 8, 116, 0, 8, 52, 0, 9, 200, 81, 7, 13, 0, 8, 100, 0, 8, 36, 0, 9, 168, 0, 8, 4, 0, 8, ScriptIntrinsicBLAS.UNIT, 0, 8, 68, 0, 9, 232, 80, 7, 8, 0, 8, 92, 0, 8, 28, 0, 9, 152, 84, 7, 83, 0, 8, 124, 0, 8, 60, 0, 9, 216, 82, 7, 23, 0, 8, 108, 0, 8, 44, 0, 9, 184, 0, 8, 12, 0, 8, 140, 0, 8, 76, 0, 9, 248, 80, 7, 3, 0, 8, 82, 0, 8, 18, 85, 8, 163, 83, 7, 35, 0, 8, 114, 0, 8, 50, 0, 9, 196, 81, 7, 11, 0, 8, 98, 0, 8, 34, 0, 9, 164, 0, 8, 2, 0, 8, 130, 0, 8, 66, 0, 9, 228, 80, 7, 7, 0, 8, 90, 0, 8, 26, 0, 9, 148, 84, 7, 67, 0, 8, ScriptIntrinsicBLAS.LOWER, 0, 8, 58, 0, 9, 212, 82, 7, 19, 0, 8, 106, 0, 8, 42, 0, 9, 180, 0, 8, 10, 0, 8, 138, 0, 8, 74, 0, 9, 244, 80, 7, 5, 0, 8, 86, 0, 8, 22, 192, 8, 0, 83, 7, 51, 0, 8, 118, 0, 8, 54, 0, 9, 204, 81, 7, 15, 0, 8, 102, 0, 8, 38, 0, 9, 172, 0, 8, 6, 0, 8, 134, 0, 8, 70, 0, 9, 236, 80, 7, 9, 0, 8, 94, 0, 8, 30, 0, 9, 156, 84, 7, 99, 0, 8, 126, 0, 8, 62, 0, 9, 220, 82, 7, 27, 0, 8, 110, 0, 8, 46, 0, 9, 188, 0, 8, 14, 0, 8, ScriptIntrinsicBLAS.RIGHT, 0, 8, 78, 0, 9, 252, 96, 7, 256, 0, 8, 81, 0, 8, 17, 85, 8, ScriptIntrinsicBLAS.NON_UNIT, 82, 7, 31, 0, 8, 113, 0, 8, 49, 0, 9, 194, 80, 7, 10, 0, 8, 97, 0, 8, 33, 0, 9, 162, 0, 8, 1, 0, 8, 129, 0, 8, 65, 0, 9, 226, 80, 7, 6, 0, 8, 89, 0, 8, 25, 0, 9, 146, 83, 7, 59, 0, 8, ScriptIntrinsicBLAS.UPPER, 0, 8, 57, 0, 9, 210, 81, 7, 17, 0, 8, 105, 0, 8, 41, 0, 9, 178, 0, 8, 9, 0, 8, 137, 0, 8, 73, 0, 9, 242, 80, 7, 4, 0, 8, 85, 0, 8, 21, 80, 8, 258, 83, 7, 43, 0, 8, 117, 0, 8, 53, 0, 9, 202, 81, 7, 13, 0, 8, 101, 0, 8, 37, 0, 9, 170, 0, 8, 5, 0, 8, 133, 0, 8, 69, 0, 9, 234, 80, 7, 8, 0, 8, 93, 0, 8, 29, 0, 9, 154, 84, 7, 83, 0, 8, 125, 0, 8, 61, 0, 9, 218, 82, 7, 23, 0, 8, 109, 0, 8, 45, 0, 9, 186, 0, 8, 13, 0, 8, ScriptIntrinsicBLAS.LEFT, 0, 8, 77, 0, 9, 250, 80, 7, 3, 0, 8, 83, 0, 8, 19, 85, 8, 195, 83, 7, 35, 0, 8, 115, 0, 8, 51, 0, 9, 198, 81, 7, 11, 0, 8, 99, 0, 8, 35, 0, 9, 166, 0, 8, 3, 0, 8, ScriptIntrinsicBLAS.NON_UNIT, 0, 8, 67, 0, 9, 230, 80, 7, 7, 0, 8, 91, 0, 8, 27, 0, 9, 150, 84, 7, 67, 0, 8, 123, 0, 8, 59, 0, 9, 214, 82, 7, 19, 0, 8, 107, 0, 8, 43, 0, 9, 182, 0, 8, 11, 0, 8, 139, 0, 8, 75, 0, 9, 246, 80, 7, 5, 0, 8, 87, 0, 8, 23, 192, 8, 0, 83, 7, 51, 0, 8, 119, 0, 8, 55, 0, 9, 206, 81, 7, 15, 0, 8, 103, 0, 8, 39, 0, 9, 174, 0, 8, 7, 0, 8, 135, 0, 8, 71, 0, 9, 238, 80, 7, 9, 0, 8, 95, 0, 8, 31, 0, 9, 158, 84, 7, 99, 0, 8, 127, 0, 8, 63, 0, 9, 222, 82, 7, 27, 0, 8, 111, 0, 8, 47, 0, 9, 190, 0, 8, 15, 0, 8, 143, 0, 8, 79, 0, 9, 254, 96, 7, 256, 0, 8, 80, 0, 8, 16, 84, 8, 115, 82, 7, 31, 0, 8, 112, 0, 8, 48, 0, 9, 193, 80, 7, 10, 0, 8, 96, 0, 8, 32, 0, 9, 161, 0, 8, 0, 0, 8, Allocation.USAGE_SHARED, 0, 8, 64, 0, 9, 225, 80, 7, 6, 0, 8, 88, 0, 8, 24, 0, 9, 145, 83, 7, 59, 0, 8, 120, 0, 8, 56, 0, 9, 209, 81, 7, 17, 0, 8, 104, 0, 8, 40, 0, 9, 177, 0, 8, 8, 0, 8, 136, 0, 8, 72, 0, 9, 241, 80, 7, 4, 0, 8, 84, 0, 8, 20, 85, 8, 227, 83, 7, 43, 0, 8, 116, 0, 8, 52, 0, 9, 201, 81, 7, 13, 0, 8, 100, 0, 8, 36, 0, 9, 169, 0, 8, 4, 0, 8, ScriptIntrinsicBLAS.UNIT, 0, 8, 68, 0, 9, 233, 80, 7, 8, 0, 8, 92, 0, 8, 28, 0, 9, 153, 84, 7, 83, 0, 8, 124, 0, 8, 60, 0, 9, 217, 82, 7, 23, 0, 8, 108, 0, 8, 44, 0, 9, 185, 0, 8, 12, 0, 8, 140, 0, 8, 76, 0, 9, 249, 80, 7, 3, 0, 8, 82, 0, 8, 18, 85, 8, 163, 83, 7, 35, 0, 8, 114, 0, 8, 50, 0, 9, 197, 81, 7, 11, 0, 8, 98, 0, 8, 34, 0, 9, 165, 0, 8, 2, 0, 8, 130, 0, 8, 66, 0, 9, 229, 80, 7, 7, 0, 8, 90, 0, 8, 26, 0, 9, 149, 84, 7, 67, 0, 8, ScriptIntrinsicBLAS.LOWER, 0, 8, 58, 0, 9, 213, 82, 7, 19, 0, 8, 106, 0, 8, 42, 0, 9, 181, 0, 8, 10, 0, 8, 138, 0, 8, 74, 0, 9, 245, 80, 7, 5, 0, 8, 86, 0, 8, 22, 192, 8, 0, 83, 7, 51, 0, 8, 118, 0, 8, 54, 0, 9, 205, 81, 7, 15, 0, 8, 102, 0, 8, 38, 0, 9, 173, 0, 8, 6, 0, 8, 134, 0, 8, 70, 0, 9, 237, 80, 7, 9, 0, 8, 94, 0, 8, 30, 0, 9, 157, 84, 7, 99, 0, 8, 126, 0, 8, 62, 0, 9, 221, 82, 7, 27, 0, 8, 110, 0, 8, 46, 0, 9, 189, 0, 8, 14, 0, 8, ScriptIntrinsicBLAS.RIGHT, 0, 8, 78, 0, 9, 253, 96, 7, 256, 0, 8, 81, 0, 8, 17, 85, 8, ScriptIntrinsicBLAS.NON_UNIT, 82, 7, 31, 0, 8, 113, 0, 8, 49, 0, 9, 195, 80, 7, 10, 0, 8, 97, 0, 8, 33, 0, 9, 163, 0, 8, 1, 0, 8, 129, 0, 8, 65, 0, 9, 227, 80, 7, 6, 0, 8, 89, 0, 8, 25, 0, 9, 147, 83, 7, 59, 0, 8, ScriptIntrinsicBLAS.UPPER, 0, 8, 57, 0, 9, 211, 81, 7, 17, 0, 8, 105, 0, 8, 41, 0, 9, 179, 0, 8, 9, 0, 8, 137, 0, 8, 73, 0, 9, 243, 80, 7, 4, 0, 8, 85, 0, 8, 21, 80, 8, 258, 83, 7, 43, 0, 8, 117, 0, 8, 53, 0, 9, 203, 81, 7, 13, 0, 8, 101, 0, 8, 37, 0, 9, 171, 0, 8, 5, 0, 8, 133, 0, 8, 69, 0, 9, 235, 80, 7, 8, 0, 8, 93, 0, 8, 29, 0, 9, 155, 84, 7, 83, 0, 8, 125, 0, 8, 61, 0, 9, 219, 82, 7, 23, 0, 8, 109, 0, 8, 45, 0, 9, 187, 0, 8, 13, 0, 8, ScriptIntrinsicBLAS.LEFT, 0, 8, 77, 0, 9, 251, 80, 7, 3, 0, 8, 83, 0, 8, 19, 85, 8, 195, 83, 7, 35, 0, 8, 115, 0, 8, 51, 0, 9, 199, 81, 7, 11, 0, 8, 99, 0, 8, 35, 0, 9, 167, 0, 8, 3, 0, 8, ScriptIntrinsicBLAS.NON_UNIT, 0, 8, 67, 0, 9, 231, 80, 7, 7, 0, 8, 91, 0, 8, 27, 0, 9, 151, 84, 7, 67, 0, 8, 123, 0, 8, 59, 0, 9, 215, 82, 7, 19, 0, 8, 107, 0, 8, 43, 0, 9, 183, 0, 8, 11, 0, 8, 139, 0, 8, 75, 0, 9, 247, 80, 7, 5, 0, 8, 87, 0, 8, 23, 192, 8, 0, 83, 7, 51, 0, 8, 119, 0, 8, 55, 0, 9, 207, 81, 7, 15, 0, 8, 103, 0, 8, 39, 0, 9, 175, 0, 8, 7, 0, 8, 135, 0, 8, 71, 0, 9, 239, 80, 7, 9, 0, 8, 95, 0, 8, 31, 0, 9, 159, 84, 7, 99, 0, 8, 127, 0, 8, 63, 0, 9, 223, 82, 7, 27, 0, 8, 111, 0, 8, 47, 0, 9, 191, 0, 8, 15, 0, 8, 143, 0, 8, 79, 0, 9, 255};

    /* renamed from: b */
    static final int[] f6704b = {80, 5, 1, 87, 5, 257, 83, 5, 17, 91, 5, 4097, 81, 5, 5, 89, 5, 1025, 85, 5, 65, 93, 5, 16385, 80, 5, 3, 88, 5, 513, 84, 5, 33, 92, 5, 8193, 82, 5, 9, 90, 5, 2049, 86, 5, 129, 192, 5, 24577, 80, 5, 2, 87, 5, 385, 83, 5, 25, 91, 5, 6145, 81, 5, 7, 89, 5, 1537, 85, 5, 97, 93, 5, 24577, 80, 5, 4, 88, 5, 769, 84, 5, 49, 92, 5, 12289, 82, 5, 13, 90, 5, 3073, 86, 5, 193, 192, 5, 24577};

    /* renamed from: c */
    static final int[] f6705c = {3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, ScriptIntrinsicBLAS.NON_UNIT, 163, 195, 227, 258, 0, 0};

    /* renamed from: d */
    static final int[] f6706d = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, 112, 112};

    /* renamed from: e */
    static final int[] f6707e = {1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577};

    /* renamed from: f */
    static final int[] f6708f = {0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13};

    /* renamed from: g */
    private int[] f6709g;

    /* renamed from: h */
    private int[] f6710h;

    /* renamed from: i */
    private int[] f6711i;

    /* renamed from: j */
    private int[] f6712j;

    /* renamed from: k */
    private int[] f6713k;

    /* renamed from: l */
    private int[] f6714l;

    C2507f() {
    }

    /* JADX WARNING: Code restructure failed: missing block: B:91:0x0265, code lost:
        r12 = r12 + 1;
     */
    /* renamed from: a */
    private int m10000a(int[] iArr, int i, int i2, int i3, int[] iArr2, int[] iArr3, int[] iArr4, int[] iArr5, int[] iArr6, int[] iArr7, int[] iArr8) {
        int i4;
        int i5 = 0;
        int i6 = i2;
        do {
            int[] iArr9 = this.f6711i;
            int i7 = iArr[i + i5];
            iArr9[i7] = iArr9[i7] + 1;
            i5++;
            i6--;
        } while (i6 != 0);
        if (this.f6711i[0] == i2) {
            iArr4[0] = -1;
            iArr5[0] = 0;
            return 0;
        }
        int i8 = iArr5[0];
        int i9 = 1;
        while (i9 <= 15 && this.f6711i[i9] == 0) {
            i9++;
        }
        if (i8 < i9) {
            i8 = i9;
        }
        int i10 = 15;
        while (i10 != 0 && this.f6711i[i10] == 0) {
            i10--;
        }
        if (i8 > i10) {
            i8 = i10;
        }
        iArr5[0] = i8;
        int i11 = 1 << i9;
        int i12 = i9;
        while (i12 < i10) {
            int i13 = i11 - this.f6711i[i12];
            if (i13 < 0) {
                return -3;
            }
            i12++;
            i11 = i13 << 1;
        }
        int i14 = i11 - this.f6711i[i10];
        if (i14 < 0) {
            return -3;
        }
        int[] iArr10 = this.f6711i;
        iArr10[i10] = iArr10[i10] + i14;
        int i15 = 0;
        this.f6714l[1] = 0;
        int i16 = 1;
        int i17 = 2;
        int i18 = i10;
        while (true) {
            i18--;
            if (i18 == 0) {
                break;
            }
            int[] iArr11 = this.f6714l;
            i15 += this.f6711i[i16];
            iArr11[i17] = i15;
            i17++;
            i16++;
        }
        int i19 = 0;
        int i20 = 0;
        do {
            int i21 = iArr[i + i20];
            if (i21 != 0) {
                int[] iArr12 = this.f6714l;
                int i22 = iArr12[i21];
                iArr12[i21] = i22 + 1;
                iArr8[i22] = i19;
            }
            i20++;
            i19++;
        } while (i19 < i2);
        int i23 = this.f6714l[i10];
        this.f6714l[0] = 0;
        int i24 = -1;
        int i25 = -i8;
        this.f6713k[0] = 0;
        int i26 = 0;
        int i27 = 0;
        int i28 = 0;
        int i29 = i9;
        int i30 = 0;
        while (i29 <= i10) {
            int i31 = this.f6711i[i29];
            while (true) {
                int i32 = i31 - 1;
                if (i31 == 0) {
                    break;
                }
                int i33 = i26;
                int i34 = i24;
                int i35 = i30;
                while (i29 > i25 + i8) {
                    int i36 = i34 + 1;
                    int i37 = i25 + i8;
                    int i38 = i10 - i37;
                    int i39 = i38 > i8 ? i8 : i38;
                    int i40 = i29 - i37;
                    int i41 = 1 << i40;
                    if (i41 > i32 + 1) {
                        int i42 = i41 - (i32 + 1);
                        if (i40 < i39) {
                            int i43 = i42;
                            int i44 = i29;
                            while (true) {
                                i40++;
                                if (i40 >= i39) {
                                    break;
                                }
                                int i45 = i43 << 1;
                                i44++;
                                if (i45 <= this.f6711i[i44]) {
                                    break;
                                }
                                i43 = i45 - this.f6711i[i44];
                            }
                        }
                    }
                    int i46 = 1 << i40;
                    if (iArr7[0] + i46 > 1440) {
                        return -3;
                    }
                    int[] iArr13 = this.f6713k;
                    int i47 = iArr7[0];
                    iArr13[i36] = i47;
                    iArr7[0] = iArr7[0] + i46;
                    if (i36 != 0) {
                        this.f6714l[i36] = i28;
                        this.f6712j[0] = (byte) i40;
                        this.f6712j[1] = (byte) i8;
                        int i48 = i28 >>> (i37 - i8);
                        this.f6712j[2] = (i47 - this.f6713k[i36 - 1]) - i48;
                        System.arraycopy(this.f6712j, 0, iArr6, (i48 + this.f6713k[i36 - 1]) * 3, 3);
                        i35 = i46;
                        i25 = i37;
                        i33 = i47;
                        i34 = i36;
                    } else {
                        iArr4[0] = i47;
                        i35 = i46;
                        i25 = i37;
                        i33 = i47;
                        i34 = i36;
                    }
                }
                this.f6712j[1] = (byte) (i29 - i25);
                if (i27 >= i23) {
                    this.f6712j[0] = 192;
                    i4 = i27;
                } else if (iArr8[i27] < i3) {
                    this.f6712j[0] = (byte) (iArr8[i27] < 256 ? 0 : 96);
                    i4 = i27 + 1;
                    this.f6712j[2] = iArr8[i27];
                } else {
                    this.f6712j[0] = (byte) (iArr3[iArr8[i27] - i3] + 16 + 64);
                    i4 = i27 + 1;
                    this.f6712j[2] = iArr2[iArr8[i27] - i3];
                }
                int i49 = 1 << (i29 - i25);
                for (int i50 = i28 >>> i25; i50 < i35; i50 += i49) {
                    System.arraycopy(this.f6712j, 0, iArr6, (i33 + i50) * 3, 3);
                }
                int i51 = 1 << (i29 - 1);
                while ((i28 & i51) != 0) {
                    i28 ^= i51;
                    i51 >>>= 1;
                }
                i28 ^= i51;
                int i52 = (1 << i25) - 1;
                int i53 = i25;
                while ((i52 & i28) != this.f6714l[i34]) {
                    i34--;
                    i53 -= i8;
                    i52 = (1 << i53) - 1;
                }
                i25 = i53;
                i27 = i4;
                i30 = i35;
                i24 = i34;
                i26 = i33;
                i31 = i32;
            }
        }
        return (i14 == 0 || i10 == 1) ? 0 : -5;
    }

    /* renamed from: a */
    static int m10001a(int[] iArr, int[] iArr2, int[][] iArr3, int[][] iArr4) {
        iArr[0] = 9;
        iArr2[0] = 5;
        iArr3[0] = f6703a;
        iArr4[0] = f6704b;
        return 0;
    }

    /* renamed from: a */
    private void m10002a(int i) {
        if (this.f6709g == null) {
            this.f6709g = new int[1];
            this.f6710h = new int[i];
            this.f6711i = new int[16];
            this.f6712j = new int[3];
            this.f6713k = new int[15];
            this.f6714l = new int[16];
            return;
        }
        if (this.f6710h.length < i) {
            this.f6710h = new int[i];
        } else {
            for (int i2 = 0; i2 < i; i2++) {
                this.f6710h[i2] = 0;
            }
        }
        for (int i3 = 0; i3 < 16; i3++) {
            this.f6711i[i3] = 0;
        }
        for (int i4 = 0; i4 < 3; i4++) {
            this.f6712j[i4] = 0;
        }
        System.arraycopy(this.f6711i, 0, this.f6713k, 0, 15);
        System.arraycopy(this.f6711i, 0, this.f6714l, 0, 16);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public int mo7306a(int i, int i2, int[] iArr, int[] iArr2, int[] iArr3, int[] iArr4, int[] iArr5, int[] iArr6, C2514k kVar) {
        m10002a(288);
        this.f6709g[0] = 0;
        int a = m10000a(iArr, 0, i, 257, f6705c, f6706d, iArr4, iArr2, iArr6, this.f6709g, this.f6710h);
        if (a == 0 && iArr2[0] != 0) {
            m10002a(288);
            int a2 = m10000a(iArr, i, i2, 0, f6707e, f6708f, iArr5, iArr3, iArr6, this.f6709g, this.f6710h);
            if (a2 == 0 && (iArr3[0] != 0 || i <= 257)) {
                return 0;
            }
            if (a2 == -3) {
                kVar.f6769i = "oversubscribed distance tree";
                return a2;
            } else if (a2 == -5) {
                kVar.f6769i = "incomplete distance tree";
                return -3;
            } else if (a2 == -4) {
                return a2;
            } else {
                kVar.f6769i = "empty distance tree with lengths";
                return -3;
            }
        } else if (a == -3) {
            kVar.f6769i = "oversubscribed literal/length tree";
            return a;
        } else if (a == -4) {
            return a;
        } else {
            kVar.f6769i = "incomplete literal/length tree";
            return -3;
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: a */
    public int mo7307a(int[] iArr, int[] iArr2, int[] iArr3, int[] iArr4, C2514k kVar) {
        m10002a(19);
        this.f6709g[0] = 0;
        int a = m10000a(iArr, 0, 19, 19, null, null, iArr3, iArr2, iArr4, this.f6709g, this.f6710h);
        if (a == -3) {
            kVar.f6769i = "oversubscribed dynamic bit lengths tree";
            return a;
        } else if (a != -5 && iArr2[0] != 0) {
            return a;
        } else {
            kVar.f6769i = "incomplete dynamic bit lengths tree";
            return -3;
        }
    }
}
