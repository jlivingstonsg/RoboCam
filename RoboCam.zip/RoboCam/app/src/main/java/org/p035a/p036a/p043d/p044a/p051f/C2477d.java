package org.p035a.p036a.p043d.p044a.p051f;

/* renamed from: org.a.a.d.a.f.d */
public class C2477d extends UnsupportedOperationException {
}
