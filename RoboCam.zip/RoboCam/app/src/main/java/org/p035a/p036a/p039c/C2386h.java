package org.p035a.p036a.p039c;

/* renamed from: org.a.a.c.h */
public interface C2386h extends C2395o {
    /* renamed from: a */
    void mo7019a(C2396p pVar, C2387i iVar);
}
