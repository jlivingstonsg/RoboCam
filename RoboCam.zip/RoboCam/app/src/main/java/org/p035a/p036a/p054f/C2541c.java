package org.p035a.p036a.p054f;

/* renamed from: org.a.a.f.c */
public interface C2541c {
    /* renamed from: d */
    void mo6810d();
}
