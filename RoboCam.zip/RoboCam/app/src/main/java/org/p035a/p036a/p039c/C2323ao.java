package org.p035a.p036a.p039c;

/* renamed from: org.a.a.c.ao */
public interface C2323ao extends C2395o {
    /* renamed from: a */
    void mo7009a(C2396p pVar);

    /* renamed from: b */
    void mo7010b(C2396p pVar);

    /* renamed from: c */
    void mo7011c(C2396p pVar);

    /* renamed from: d */
    void mo7012d(C2396p pVar);
}
