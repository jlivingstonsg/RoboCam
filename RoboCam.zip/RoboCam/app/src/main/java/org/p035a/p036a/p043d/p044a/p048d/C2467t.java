package org.p035a.p036a.p043d.p044a.p048d;

/* renamed from: org.a.a.d.a.d.t */
public class C2467t extends C2461p {
    public C2467t() {
    }

    public C2467t(int i, int i2, int i3) {
        super(i, i2, i3);
    }

    /* access modifiers changed from: protected */
    @Override // org.p035a.p036a.p043d.p044a.p048d.C2461p
    /* renamed from: a */
    public C2460o mo7235a(String[] strArr) {
        return new C2446d(C2471x.m9806a(strArr[2]), C2465r.m9792a(strArr[0]), strArr[1]);
    }

    /* access modifiers changed from: protected */
    @Override // org.p035a.p036a.p043d.p044a.p048d.C2461p
    /* renamed from: d */
    public boolean mo7237d() {
        return true;
    }
}
