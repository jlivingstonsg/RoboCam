package org.p035a.p036a.p039c.p041b;

import org.p035a.p036a.p039c.C2385g;

/* renamed from: org.a.a.c.b.e */
public interface C2376e extends C2385g {
    /* renamed from: c */
    int mo7135c();
}
