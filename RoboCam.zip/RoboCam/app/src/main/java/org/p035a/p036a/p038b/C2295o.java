package org.p035a.p036a.p038b;

/* renamed from: org.a.a.b.o */
public interface C2295o extends C2284d {
}
