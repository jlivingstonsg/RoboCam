package org.p035a.p036a.p039c;

import java.net.SocketAddress;

/* renamed from: org.a.a.c.f */
public interface C2384f extends Comparable<C2384f> {
    /* renamed from: a */
    Integer mo6891a();

    /* renamed from: a */
    C2390l mo6892a(Object obj);

    /* renamed from: a */
    C2390l mo6893a(SocketAddress socketAddress);

    /* renamed from: b */
    C2384f mo6895b();

    /* renamed from: d */
    C2398r mo6898d();

    /* renamed from: g */
    boolean mo6902g();

    /* renamed from: i */
    C2390l mo6905i();

    /* renamed from: j */
    C2390l mo6906j();

    /* renamed from: l */
    boolean mo7120l();

    /* renamed from: m */
    C2385g mo7051m();

    /* renamed from: n */
    boolean mo7113n();

    /* renamed from: o */
    SocketAddress mo7052o();

    /* renamed from: p */
    SocketAddress mo7053p();
}
