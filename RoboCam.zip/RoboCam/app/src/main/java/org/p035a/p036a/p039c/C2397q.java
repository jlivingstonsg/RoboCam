package org.p035a.p036a.p039c;

/* renamed from: org.a.a.c.q */
public class C2397q extends RuntimeException {
    public C2397q() {
    }

    public C2397q(String str) {
        super(str);
    }

    public C2397q(String str, Throwable th) {
        super(str, th);
    }
}
