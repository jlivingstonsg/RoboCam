package org.p035a.p036a.p043d.p044a.p048d;

/* renamed from: org.a.a.d.a.d.u */
public interface C2468u extends C2460o {
    /* renamed from: a */
    void mo7209a(C2470w wVar);

    /* renamed from: g */
    C2470w mo7210g();
}
