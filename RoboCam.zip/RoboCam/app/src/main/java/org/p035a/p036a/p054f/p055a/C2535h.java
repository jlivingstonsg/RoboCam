package org.p035a.p036a.p054f.p055a;

import java.util.Iterator;

/* renamed from: org.a.a.f.a.h */
public interface C2535h extends Iterator {
}
