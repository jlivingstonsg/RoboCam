package org.p035a.p036a.p039c;

/* renamed from: org.a.a.c.as */
public interface C2327as extends C2384f {
}
