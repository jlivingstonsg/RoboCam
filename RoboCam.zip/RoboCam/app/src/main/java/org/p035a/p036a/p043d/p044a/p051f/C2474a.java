package org.p035a.p036a.p043d.p044a.p051f;

/* renamed from: org.a.a.d.a.f.a */
class C2474a extends Error {
    C2474a() {
    }
}
