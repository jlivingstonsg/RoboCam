package org.p035a.p036a.p039c;

import java.nio.channels.WritableByteChannel;
import org.p035a.p036a.p054f.C2541c;

/* renamed from: org.a.a.c.an */
public interface C2322an extends C2541c {
    /* renamed from: a */
    long mo6996a();

    /* renamed from: a */
    long mo6997a(WritableByteChannel writableByteChannel, long j);
}
