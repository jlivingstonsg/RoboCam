package org.p035a.p036a.p043d.p052b;

import java.util.concurrent.Executor;

/* renamed from: org.a.a.d.b.a */
final class C2479a implements Executor {

    /* renamed from: a */
    static final C2479a f6542a = new C2479a();

    C2479a() {
    }

    public void execute(Runnable runnable) {
        runnable.run();
    }
}
