package org.p035a.p036a.p039c.p041b.p042a;

import org.p035a.p036a.p039c.C2385g;

/* renamed from: org.a.a.c.b.a.g */
public interface C2348g extends C2385g {
    /* renamed from: c */
    int mo7107c();

    /* renamed from: d */
    int mo7108d();

    /* renamed from: e */
    int mo7109e();
}
