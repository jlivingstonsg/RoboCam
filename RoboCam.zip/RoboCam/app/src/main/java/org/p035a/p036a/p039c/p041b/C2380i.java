package org.p035a.p036a.p039c.p041b;

/* renamed from: org.a.a.c.b.i */
public interface C2380i extends Runnable {
}
