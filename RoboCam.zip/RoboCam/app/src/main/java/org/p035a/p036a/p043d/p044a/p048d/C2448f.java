package org.p035a.p036a.p043d.p044a.p048d;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.p035a.p036a.p038b.C2284d;
import org.p035a.p036a.p038b.C2286f;

/* renamed from: org.a.a.d.a.d.f */
public interface C2448f {

    /* renamed from: a */
    public static final C2451h f6415a = new C2451h() {
        /* class org.p035a.p036a.p043d.p044a.p048d.C2448f.C24491 */

        @Override // org.p035a.p036a.p043d.p044a.p048d.C2451h
        /* renamed from: a */
        public List<String> mo7183a(String str) {
            return Collections.emptyList();
        }

        @Override // org.p035a.p036a.p043d.p044a.p048d.C2448f
        /* renamed from: a */
        public C2284d mo7172a() {
            return C2286f.f6097c;
        }

        @Override // org.p035a.p036a.p043d.p044a.p048d.C2451h
        /* renamed from: a */
        public void mo7184a(String str, Object obj) {
            throw new IllegalStateException("read-only");
        }

        @Override // org.p035a.p036a.p043d.p044a.p048d.C2448f
        /* renamed from: a */
        public void mo7173a(C2284d dVar) {
            throw new IllegalStateException("read-only");
        }

        @Override // org.p035a.p036a.p043d.p044a.p048d.C2448f
        /* renamed from: b */
        public boolean mo7174b() {
            return true;
        }

        @Override // org.p035a.p036a.p043d.p044a.p048d.C2451h
        /* renamed from: c */
        public List<Map.Entry<String, String>> mo7185c() {
            return Collections.emptyList();
        }
    };

    /* renamed from: a */
    C2284d mo7172a();

    /* renamed from: a */
    void mo7173a(C2284d dVar);

    /* renamed from: b */
    boolean mo7174b();
}
