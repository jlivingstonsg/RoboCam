package org.p035a.p036a.p039c;

/* renamed from: org.a.a.c.aq */
public interface C2325aq {
    /* renamed from: a */
    int mo7013a();

    /* renamed from: a */
    void mo7014a(int i);
}
