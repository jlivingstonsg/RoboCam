package org.p035a.p036a.p039c;

/* renamed from: org.a.a.c.s */
public class C2399s extends C2388j {
    public C2399s() {
    }

    public C2399s(Throwable th) {
        super(th);
    }
}
