package org.p035a.p036a.p043d.p044a.p046b;

import org.p035a.p036a.p039c.C2386h;
import org.p035a.p036a.p039c.C2405y;

/* renamed from: org.a.a.d.a.b.g */
public class C2434g<E> extends C2426a<E> {
    public C2434g(C2386h... hVarArr) {
        super(hVarArr);
    }

    @Override // org.p035a.p036a.p043d.p044a.p046b.C2426a
    /* renamed from: a */
    public /* bridge */ /* synthetic */ boolean mo7154a() {
        return super.mo7154a();
    }

    /* renamed from: a */
    public boolean mo7161a(Object obj) {
        C2405y.m9550b(mo7156b(), obj).mo6909a();
        return !mo7157c();
    }
}
