package org.p035a.p036a.p039c.p040a;

import org.p035a.p036a.p039c.C2390l;

/* renamed from: org.a.a.c.a.b */
public interface C2299b extends Iterable<C2390l> {
}
