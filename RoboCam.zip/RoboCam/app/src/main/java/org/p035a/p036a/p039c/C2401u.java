package org.p035a.p036a.p039c;

/* renamed from: org.a.a.c.u */
public interface C2401u {
    /* renamed from: a */
    C2390l mo6987a(C2398r rVar, Runnable runnable);

    /* renamed from: a */
    void mo6988a(C2398r rVar, C2387i iVar);

    /* renamed from: a */
    void mo6989a(C2398r rVar, C2387i iVar, C2399s sVar);
}
