package org.p035a.p036a.p043d.p044a.p046b;

import java.net.SocketAddress;

/* renamed from: org.a.a.d.a.b.f */
class C2433f extends SocketAddress {
    C2433f() {
    }
}
