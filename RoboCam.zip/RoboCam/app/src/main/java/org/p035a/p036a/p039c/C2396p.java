package org.p035a.p036a.p039c;

/* renamed from: org.a.a.c.p */
public interface C2396p {
    /* renamed from: a */
    C2384f mo6977a();

    /* renamed from: a */
    void mo6978a(Object obj);

    /* renamed from: a */
    void mo6979a(C2387i iVar);

    /* renamed from: b */
    C2398r mo6980b();

    /* renamed from: b */
    void mo6981b(C2387i iVar);

    /* renamed from: c */
    String mo6982c();

    /* renamed from: d */
    C2395o mo6983d();

    /* renamed from: e */
    Object mo6984e();
}
