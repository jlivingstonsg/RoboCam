package org.p035a.p036a.p038b;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;

/* renamed from: org.a.a.b.d */
public interface C2284d extends Comparable<C2284d> {
    /* renamed from: a */
    int mo6816a();

    /* renamed from: a */
    int mo6817a(int i, int i2, byte b);

    /* renamed from: a */
    String mo6819a(Charset charset);

    /* renamed from: a */
    void mo6820a(int i);

    /* renamed from: a */
    void mo6821a(int i, int i2);

    /* renamed from: a */
    void mo6862a(int i, long j);

    /* renamed from: a */
    void mo6872a(int i, ByteBuffer byteBuffer);

    /* renamed from: a */
    void mo6873a(int i, C2284d dVar, int i2, int i3);

    /* renamed from: a */
    void mo6874a(int i, byte[] bArr, int i2, int i3);

    /* renamed from: a */
    void mo6822a(long j);

    /* renamed from: a */
    void mo6823a(ByteBuffer byteBuffer);

    /* renamed from: a */
    void mo6824a(C2284d dVar);

    /* renamed from: a */
    void mo6826a(C2284d dVar, int i, int i2);

    /* renamed from: a */
    void mo6827a(byte[] bArr);

    /* renamed from: b */
    int mo6829b();

    /* renamed from: b */
    void mo6831b(int i);

    /* renamed from: b */
    void mo6875b(int i, ByteBuffer byteBuffer);

    /* renamed from: b */
    void mo6876b(int i, C2284d dVar, int i2, int i3);

    /* renamed from: b */
    void mo6877b(int i, byte[] bArr, int i2, int i3);

    /* renamed from: b */
    void mo6832b(byte[] bArr);

    /* renamed from: b */
    void mo6833b(byte[] bArr, int i, int i2);

    /* renamed from: c */
    void mo6863c(int i, int i2);

    /* renamed from: c */
    boolean mo6836c();

    /* renamed from: d */
    int mo6838d();

    /* renamed from: d */
    short mo6839d(int i);

    /* renamed from: d */
    void mo6864d(int i, int i2);

    /* renamed from: e */
    long mo6841e(int i);

    /* renamed from: e */
    C2284d mo6865e(int i, int i2);

    /* renamed from: f */
    byte mo6843f();

    /* renamed from: f */
    C2284d mo6844f(int i);

    /* renamed from: f */
    void mo6878f(int i, int i2);

    /* renamed from: g */
    C2284d mo6879g(int i, int i2);

    /* renamed from: g */
    short mo6845g();

    /* renamed from: g */
    void mo6846g(int i);

    /* renamed from: h */
    ByteBuffer mo6880h(int i, int i2);

    /* renamed from: h */
    void mo6848h(int i);

    /* renamed from: i */
    int mo6850i();

    /* renamed from: i */
    void mo6851i(int i);

    /* renamed from: j */
    long mo6852j();

    /* renamed from: k */
    short mo6866k(int i);

    /* renamed from: l */
    int mo6867l(int i);

    /* renamed from: l */
    C2284d mo6855l();

    /* renamed from: m */
    long mo6868m(int i);

    /* renamed from: m */
    ByteBuffer mo6856m();

    /* renamed from: n */
    byte mo6881n(int i);

    /* renamed from: n */
    ByteBuffer[] mo6857n();

    /* renamed from: o */
    C2285e mo6869o();

    /* renamed from: p */
    ByteOrder mo6870p();

    /* renamed from: q */
    C2284d mo6871q();

    /* renamed from: r */
    int mo6882r();

    /* renamed from: s */
    boolean mo6883s();

    /* renamed from: t */
    byte[] mo6884t();
}
