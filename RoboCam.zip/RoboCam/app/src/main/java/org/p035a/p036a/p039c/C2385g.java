package org.p035a.p036a.p039c;

import java.util.Map;
import org.p035a.p036a.p038b.C2285e;

/* renamed from: org.a.a.c.g */
public interface C2385g {
    /* renamed from: a */
    C2285e mo6942a();

    /* renamed from: a */
    void mo6944a(Map<String, Object> map);

    /* renamed from: a */
    void mo6946a(C2400t tVar);

    /* renamed from: b */
    C2400t mo6948b();
}
