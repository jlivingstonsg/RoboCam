package org.p035a.p036a.p039c;

/* renamed from: org.a.a.c.j */
public class C2388j extends RuntimeException {
    public C2388j() {
    }

    public C2388j(String str, Throwable th) {
        super(str, th);
    }

    public C2388j(Throwable th) {
        super(th);
    }
}
