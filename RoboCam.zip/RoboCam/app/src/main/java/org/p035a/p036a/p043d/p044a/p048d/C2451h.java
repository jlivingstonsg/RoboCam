package org.p035a.p036a.p043d.p044a.p048d;

import java.util.List;
import java.util.Map;

/* renamed from: org.a.a.d.a.d.h */
public interface C2451h extends C2448f {
    /* renamed from: a */
    List<String> mo7183a(String str);

    /* renamed from: a */
    void mo7184a(String str, Object obj);

    /* renamed from: c */
    List<Map.Entry<String, String>> mo7185c();
}
