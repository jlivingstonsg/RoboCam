package org.p035a.p036a.p043d.p044a.p047c;

/* renamed from: org.a.a.d.a.c.a */
public class C2435a extends Exception {
    public C2435a() {
    }

    public C2435a(String str) {
        super(str);
    }
}
