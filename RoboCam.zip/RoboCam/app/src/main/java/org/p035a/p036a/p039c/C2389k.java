package org.p035a.p036a.p039c;

import org.p035a.p036a.p054f.C2541c;

/* renamed from: org.a.a.c.k */
public interface C2389k extends C2541c {
    /* renamed from: a */
    C2384f mo7116a(C2398r rVar);

    @Override // org.p035a.p036a.p054f.C2541c
    /* renamed from: d */
    void mo6810d();
}
