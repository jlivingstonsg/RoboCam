package org.p035a.p036a.p039c.p041b;

import org.p035a.p036a.p039c.C2385g;

/* renamed from: org.a.a.c.b.h */
public interface C2379h extends C2385g {
}
