package org.p035a.p036a.p053e;

/* renamed from: org.a.a.e.b */
public interface C2491b {
    /* renamed from: a */
    void mo7281a(String str);

    /* renamed from: a */
    void mo7282a(String str, Throwable th);

    /* renamed from: a */
    boolean mo7283a();

    /* renamed from: b */
    void mo7284b(String str);

    /* renamed from: b */
    void mo7285b(String str, Throwable th);

    /* renamed from: b */
    boolean mo7286b();

    /* renamed from: c */
    void mo7287c(String str);

    /* renamed from: c */
    boolean mo7288c();
}
