package org.p035a.p036a.p039c;

/* renamed from: org.a.a.c.i */
public interface C2387i {
    /* renamed from: a */
    C2384f mo6990a();

    /* renamed from: b */
    C2390l mo6991b();
}
