package org.p035a.p036a.p053e;

import java.util.logging.Logger;

/* renamed from: org.a.a.e.e */
public class C2495e extends C2492c {
    @Override // org.p035a.p036a.p053e.C2492c
    /* renamed from: b */
    public C2491b mo7289b(String str) {
        return new C2494d(Logger.getLogger(str), str);
    }
}
