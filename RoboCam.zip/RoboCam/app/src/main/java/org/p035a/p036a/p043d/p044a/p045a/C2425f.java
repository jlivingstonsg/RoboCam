package org.p035a.p036a.p043d.p044a.p045a;

/* renamed from: org.a.a.d.a.a.f */
public enum C2425f {
    ZLIB,
    GZIP,
    NONE,
    ZLIB_OR_NONE
}
