package org.p035a.p036a.p039c;

/* renamed from: org.a.a.c.n */
public interface C2394n extends C2391m {
    /* renamed from: a */
    void mo7143a(C2390l lVar, long j, long j2, long j3);
}
