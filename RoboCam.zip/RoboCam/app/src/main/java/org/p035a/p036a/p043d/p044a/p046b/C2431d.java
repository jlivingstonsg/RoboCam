package org.p035a.p036a.p043d.p044a.p046b;

import java.net.SocketAddress;
import org.p035a.p036a.p039c.C2296a;
import org.p035a.p036a.p039c.C2307ab;
import org.p035a.p036a.p039c.C2385g;
import org.p035a.p036a.p039c.C2398r;
import org.p035a.p036a.p039c.C2401u;

/* renamed from: org.a.a.d.a.b.d */
class C2431d extends C2296a {

    /* renamed from: c */
    private static final Integer f6388c = 0;

    /* renamed from: d */
    private final C2385g f6389d = new C2307ab();

    /* renamed from: e */
    private final SocketAddress f6390e = new C2433f();

    /* renamed from: f */
    private final SocketAddress f6391f = new C2433f();

    C2431d(C2398r rVar, C2401u uVar) {
        super(f6388c, null, C2432e.f6392a, rVar, uVar);
    }

    @Override // org.p035a.p036a.p039c.C2384f
    /* renamed from: l */
    public boolean mo7120l() {
        return true;
    }

    @Override // org.p035a.p036a.p039c.C2384f
    /* renamed from: m */
    public C2385g mo7051m() {
        return this.f6389d;
    }

    @Override // org.p035a.p036a.p039c.C2384f
    /* renamed from: n */
    public boolean mo7113n() {
        return true;
    }

    @Override // org.p035a.p036a.p039c.C2384f
    /* renamed from: o */
    public SocketAddress mo7052o() {
        return this.f6390e;
    }

    @Override // org.p035a.p036a.p039c.C2384f
    /* renamed from: p */
    public SocketAddress mo7053p() {
        return this.f6391f;
    }
}
