package org.p035a.p036a.p043d.p044a.p045a;

/* renamed from: org.a.a.d.a.a.a */
public class C2415a extends RuntimeException {
    public C2415a() {
    }

    public C2415a(String str) {
        super(str);
    }
}
