package org.p035a.p036a.p054f.p055a.p056a;

/* renamed from: org.a.a.f.a.a.h */
public final class C2510h {

    /* renamed from: a */
    public static final Enum<?> f6731a = C2511a.NONE;

    /* renamed from: b */
    public static final Enum<?> f6732b = C2511a.ZLIB;

    /* renamed from: c */
    public static final Enum<?> f6733c = C2511a.GZIP;

    /* renamed from: d */
    public static final Enum<?> f6734d = C2511a.ZLIB_OR_NONE;

    /* renamed from: org.a.a.f.a.a.h$a */
    enum C2511a {
        NONE,
        ZLIB,
        GZIP,
        ZLIB_OR_NONE
    }
}
