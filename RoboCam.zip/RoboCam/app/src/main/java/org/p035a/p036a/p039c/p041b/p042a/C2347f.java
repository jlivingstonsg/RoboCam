package org.p035a.p036a.p039c.p041b.p042a;

import java.nio.channels.SocketChannel;
import org.p035a.p036a.p039c.C2384f;
import org.p035a.p036a.p039c.C2389k;
import org.p035a.p036a.p039c.C2398r;
import org.p035a.p036a.p039c.C2401u;
import org.p035a.p036a.p039c.C2405y;

/* renamed from: org.a.a.c.b.a.f */
final class C2347f extends C2356m {

    /* renamed from: q */
    final Thread f6265q;

    C2347f(C2389k kVar, C2398r rVar, C2384f fVar, C2401u uVar, SocketChannel socketChannel, C2358o oVar, Thread thread) {
        super(fVar, kVar, rVar, uVar, socketChannel, oVar);
        this.f6265q = thread;
        mo7122x();
        C2405y.m9558c(this);
    }
}
