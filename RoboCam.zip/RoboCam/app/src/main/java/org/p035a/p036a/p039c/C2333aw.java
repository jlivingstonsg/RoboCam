package org.p035a.p036a.p039c;

/* renamed from: org.a.a.c.aw */
public class C2333aw extends C2306aa {
    public C2333aw(C2384f fVar) {
        super(fVar);
    }

    @Override // org.p035a.p036a.p039c.C2390l
    /* renamed from: d */
    public boolean mo6949d() {
        return true;
    }

    @Override // org.p035a.p036a.p039c.C2390l
    /* renamed from: e */
    public Throwable mo6950e() {
        return null;
    }
}
