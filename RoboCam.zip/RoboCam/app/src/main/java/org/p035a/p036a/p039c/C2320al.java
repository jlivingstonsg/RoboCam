package org.p035a.p036a.p039c;

/* renamed from: org.a.a.c.al */
public interface C2320al extends C2387i {
    /* renamed from: c */
    Throwable mo6994c();
}
