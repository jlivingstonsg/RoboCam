package org.p035a.p036a.p043d.p052b;

import javax.net.ssl.SSLException;

/* renamed from: org.a.a.d.b.b */
public class C2480b extends SSLException {
    public C2480b() {
        super("");
    }

    public C2480b(String str) {
        super(str);
    }
}
