package org.p035a.p036a.p039c.p041b.p042a;

import org.p035a.p036a.p039c.p041b.C2380i;

/* renamed from: org.a.a.c.b.a.t */
public interface C2372t<E extends C2380i> {
    /* renamed from: b */
    E mo7104b();
}
