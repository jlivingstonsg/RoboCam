package org.p035a.p036a.p038b;

import java.nio.ByteOrder;

/* renamed from: org.a.a.b.e */
public interface C2285e {
    /* renamed from: a */
    ByteOrder mo6859a();

    /* renamed from: a */
    C2284d mo6860a(int i);

    /* renamed from: a */
    C2284d mo6885a(ByteOrder byteOrder, int i);

    /* renamed from: a */
    C2284d mo6886a(ByteOrder byteOrder, byte[] bArr, int i, int i2);

    /* renamed from: a */
    C2284d mo6861a(byte[] bArr, int i, int i2);
}
