package org.p035a.p036a.p039c;

/* renamed from: org.a.a.c.x */
public interface C2404x extends C2395o {
    /* renamed from: b */
    void mo7023b(C2396p pVar, C2387i iVar);
}
