package org.p035a.p036a.p039c;

import java.net.SocketAddress;

/* renamed from: org.a.a.c.ap */
public interface C2324ap extends C2387i {
    /* renamed from: c */
    Object mo7006c();

    /* renamed from: d */
    SocketAddress mo7007d();
}
