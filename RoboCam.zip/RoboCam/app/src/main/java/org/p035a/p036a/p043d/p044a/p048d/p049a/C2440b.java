package org.p035a.p036a.p043d.p044a.p048d.p049a;

import org.p035a.p036a.p038b.C2284d;
import org.p035a.p036a.p038b.C2286f;

@Deprecated
/* renamed from: org.a.a.d.a.d.a.b */
public interface C2440b {

    /* renamed from: a */
    public static final C2440b f6403a = new C2439a(255, C2286f.f6097c);

    /* renamed from: a */
    int mo7175a();

    /* renamed from: b */
    boolean mo7177b();

    /* renamed from: c */
    C2284d mo7178c();

    /* renamed from: d */
    String mo7179d();
}
