package org.p035a.p036a.p043d.p044a.p047c;

/* renamed from: org.a.a.d.a.c.c */
public class C2437c extends Exception {
    public C2437c() {
    }

    public C2437c(String str) {
        super(str);
    }
}
