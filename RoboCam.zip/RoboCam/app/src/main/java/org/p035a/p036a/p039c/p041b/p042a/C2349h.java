package org.p035a.p036a.p039c.p041b.p042a;

import org.p035a.p036a.p039c.C2384f;
import org.p035a.p036a.p039c.C2389k;
import org.p035a.p036a.p039c.C2398r;
import org.p035a.p036a.p039c.C2401u;
import org.p035a.p036a.p053e.C2491b;
import org.p035a.p036a.p053e.C2492c;

import java.nio.channels.SocketChannel;

/* renamed from: org.a.a.c.b.a.h */
final class C2349h extends C2356m {

    /* renamed from: t */
    private static final C2491b f6266t = C2492c.m9929a(C2349h.class);

    /* renamed from: q */
    volatile boolean f6267q;

    public C2349h(C2384f fVar, C2389k kVar, C2398r rVar, C2401u uVar, SocketChannel socketChannel, C2358o oVar) {
        super(fVar, kVar, rVar, uVar, socketChannel, oVar);
    }
}
