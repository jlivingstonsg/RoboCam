package org.p035a.p036a.p039c;

/* renamed from: org.a.a.c.t */
public interface C2400t {
    /* renamed from: a */
    C2398r mo7144a();
}
