package org.p035a.p036a.p043d.p044a.p046b;

import org.p035a.p036a.p039c.C2404x;
import org.p035a.p036a.p039c.C2405y;

/* renamed from: org.a.a.d.a.b.c */
public class C2430c<E> extends C2426a<E> {
    public C2430c(C2404x... xVarArr) {
        super(xVarArr);
    }

    @Override // org.p035a.p036a.p043d.p044a.p046b.C2426a
    /* renamed from: a */
    public /* bridge */ /* synthetic */ boolean mo7154a() {
        return super.mo7154a();
    }

    /* renamed from: a */
    public boolean mo7160a(Object obj) {
        C2405y.m9541a(mo7156b(), obj);
        return !super.mo7157c();
    }
}
