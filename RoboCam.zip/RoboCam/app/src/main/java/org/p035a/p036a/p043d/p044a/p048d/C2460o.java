package org.p035a.p036a.p043d.p044a.p048d;

import java.util.List;
import java.util.Map;
import org.p035a.p036a.p038b.C2284d;

/* renamed from: org.a.a.d.a.d.o */
public interface C2460o {
    /* renamed from: a */
    void mo7187a(String str);

    /* renamed from: a */
    void mo7188a(String str, Iterable<?> iterable);

    /* renamed from: a */
    void mo7189a(String str, Object obj);

    /* renamed from: a */
    void mo7191a(C2284d dVar);

    /* renamed from: a */
    void mo7193a(boolean z);

    /* renamed from: a */
    boolean mo7194a();

    /* renamed from: b */
    String mo7195b(String str);

    /* renamed from: b */
    void mo7196b(String str, Object obj);

    /* renamed from: c */
    List<String> mo7198c(String str);

    /* renamed from: c */
    void mo7199c();

    /* renamed from: d */
    List<Map.Entry<String, String>> mo7200d();

    /* renamed from: d */
    boolean mo7201d(String str);

    /* renamed from: e */
    C2471x mo7202e();

    /* renamed from: f */
    C2284d mo7203f();
}
