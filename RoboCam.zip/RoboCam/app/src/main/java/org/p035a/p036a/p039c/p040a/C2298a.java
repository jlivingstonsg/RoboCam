package org.p035a.p036a.p039c.p040a;

import java.util.Set;
import org.p035a.p036a.p039c.C2384f;

/* renamed from: org.a.a.c.a.a */
public interface C2298a extends Comparable<C2298a>, Set<C2384f> {
    /* renamed from: a */
    String mo6912a();

    /* renamed from: b */
    C2299b mo6913b();
}
