package org.p035a.p036a.p043d.p044a.p046b;

/* renamed from: org.a.a.d.a.b.b */
public class C2429b extends RuntimeException {
    public C2429b() {
    }

    public C2429b(Throwable th) {
        super(th);
    }
}
