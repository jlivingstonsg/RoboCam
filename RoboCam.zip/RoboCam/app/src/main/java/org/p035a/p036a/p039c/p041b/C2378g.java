package org.p035a.p036a.p039c.p041b;

import org.p035a.p036a.p039c.C2384f;

/* renamed from: org.a.a.c.b.g */
public interface C2378g extends C2384f {

}
