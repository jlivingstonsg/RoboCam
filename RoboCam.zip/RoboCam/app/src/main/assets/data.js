﻿{
	"project": [null, null, [
			[0, true, false, false, false, false, false, false, false, false],
			[1, false, false, false, false, false, false, false, false, false],
			[2, true, false, false, false, false, false, false, false, false],
			[3, false, false, false, false, false, false, false, false, false],
			[4, true, false, false, false, false, false, false, false, false],
			[5, false, true, true, true, true, false, false, false, false],
			[6, false, true, true, true, false, false, false, false, false],
			[7, true, false, false, false, false, false, false, false, false],
			[8, true, false, false, false, false, false, false, false, false],
			[9, false, true, true, true, true, true, true, true, false],
			[10, false, true, true, true, true, true, true, true, false],
			[11, true, false, false, false, false, false, false, false, false],
			[12, true, false, false, false, false, false, false, false, false],
			[13, false, false, false, false, false, false, false, false, false]
		],
		[
			["t0", 6, false, [], 0, 0, null, null, [], false, false, 1430335673504537, [], null],
			["t1", 12, false, [], 0, 0, null, null, [], false, false, 7905125462838331, [], null, []],
			["t2", 2, false, [], 0, 0, null, null, [], false, false, 6097091756552878, [], null, []],
			["t3", 10, false, [], 0, 0, null, null, [], false, false, 6660882780439669, [], null],
			["t4", 13, false, [], 0, 0, null, null, [], true, false, 3187270844108768, [], null],
			["t5", 0, false, [], 0, 0, null, null, [], false, false, 8904955269855946, [], null, []],
			["t6", 4, false, [], 0, 0, null, null, [], false, false, 7599274550078495, [], null, []],
			["t7", 3, false, [], 0, 0, null, null, [], true, false, 9672216888452997, [], null],
			["t8", 3, false, [], 0, 0, null, null, [], true, false, 9492544765752415, [], null],
			["t9", 1, false, [], 0, 0, null, null, [], true, false, 3551155064998923, [], null],
			["t10", 9, false, [], 0, 0, null, [
					["Default", 5, false, 1, 0, false, 3545497451386574, [
						["images/joystick1-sheet0.png", 13084, 1, 1, 540, 540, 1, 0.5, 0.5, [],
							[], 0
						],
						["images/joystick1-sheet0.png", 13084, 543, 1, 540, 540, 1, 0.5, 0.5, [],
							[], 0
						],
						["images/joystick1-sheet0.png", 13084, 1085, 1, 540, 540, 1, 0.5, 0.5, [],
							[], 0
						],
						["images/joystick1-sheet0.png", 13084, 1, 543, 540, 540, 1, 0.5, 0.5, [],
							[], 0
						],
						["images/joystick1-sheet0.png", 13084, 543, 543, 540, 540, 1, 0.5, 0.5, [],
							[-0.5, 0.5, -0.5, -0.5, 0.5, -0.5, 0.5, 0.5], 0
						],
						["images/joystick1-sheet0.png", 13084, 1085, 543, 540, 540, 1, 0.5, 0.5, [],
							[], 0
						],
						["images/joystick1-sheet0.png", 13084, 1, 1085, 540, 540, 1, 0.5, 0.5, [],
							[], 0
						]
					]]
				],
				[], false, false, 8260120003550251, [], null
			],
			["t11", 9, false, [], 0, 0, null, [
					["Default", 5, false, 1, 0, false, 1424651241016938, [
						["images/joystick1-sheet0.png", 13084, 1, 1, 540, 540, 1, 0.5, 0.5, [],
							[], 0
						],
						["images/joystick1-sheet0.png", 13084, 543, 1, 540, 540, 1, 0.5, 0.5, [],
							[], 0
						],
						["images/joystick1-sheet0.png", 13084, 1085, 1, 540, 540, 1, 0.5, 0.5, [],
							[], 0
						],
						["images/joystick1-sheet0.png", 13084, 1, 543, 540, 540, 1, 0.5, 0.5, [],
							[], 0
						],
						["images/joystick1-sheet0.png", 13084, 543, 543, 540, 540, 1, 0.5, 0.5, [],
							[-0.5, 0.5, -0.5, -0.5, 0.5, -0.5, 0.5, 0.5], 0
						],
						["images/joystick1-sheet0.png", 13084, 1085, 543, 540, 540, 1, 0.5, 0.5, [],
							[], 0
						],
						["images/joystick1-sheet0.png", 13084, 1, 1085, 540, 540, 1, 0.5, 0.5, [],
							[], 0
						]
					]]
				],
				[], false, false, 638728096525941, [], null
			],
			["t12", 13, false, [], 0, 0, null, null, [], true, false, 9750101557477202, [], null],
			["t13", 11, false, [], 0, 0, null, null, [], false, false, 6644251450617713, [], null, [1]],
			["t14", 9, false, [], 0, 0, null, [
					["Default", 5, false, 1, 0, false, 7045075112737459, [
						["images/buttonfullscreen-sheet0.png", 1861, 0, 0, 120, 120, 1, 1, 0, [],
							[], 0
						]
					]]
				],
				[], false, false, 5454142753546278, [], null
			],
			["t15", 9, false, [], 0, 0, null, [
					["Default", 5, false, 1, 0, false, 2152376871933132, [
						["images/hands-sheet0.png", 7162, 0, 0, 120, 120, 1, 1, 0, [],
							[], 0
						],
						["images/hands-sheet1.png", 6594, 0, 0, 120, 120, 1, 1, 0, [],
							[], 0
						]
					]]
				],
				[], false, false, 3461172665253951, [], null
			],
			["t16", 8, false, [], 0, 0, null, null, [], false, false, 4313712440618914, [], null, []],
			["t17", 9, false, [], 0, 0, null, [
					["Default", 5, false, 1, 0, false, 217031552685972, [
						["images/currentjoystick-sheet0.png", 9245, 0, 0, 120, 120, 1, 1, 0, [],
							[], 0
						],
						["images/currentjoystick-sheet1.png", 8065, 0, 0, 120, 120, 1, 1, 0, [],
							[], 0
						]
					]]
				],
				[], false, false, 9186922354651225, [], null
			],
			["t18", 5, false, [128615212594944, 1264880366486014, 6756113329402808], 0, 0, null, null, [], false, false, 5942543646519764, [], null],
			["t19", 10, false, [], 0, 0, null, null, [], false, false, 3391463512936438, [], null],
			["t20", 7, false, [], 0, 0, null, null, [], false, false, 5716854581914752, [], null, []]
		],
		[],
		[
			["MainLayout", 1080, 1080, true, "MainEvents", 8873350371196689, [
					["Layer 0", 0, 8722530541249526, true, [255, 255, 255], true, 1, 1, 1, false, false, 1, 0, 0, [
							[
								[0, 0, 0, 1080, 1080, 0, 0, 1, 0, 0, 0, 0, []], 0, 0, [],
								[],
								[0, "", "z-index:0;position:absolute;"]
							],
							[
								[145, 164, 0, 790, 195, 0, 0, 1, 0, 0, 0, 0, []], 3, 3, [],
								[],
								["Text", 0, "25pt Arial", "rgb(255,255,255)", 1, 1, 0, 0, 0]
							],
							[
								[810, 810, 0, 540, 540, 0, 0, 1, 0.5, 0.5, 0, 0, []], 10, 9, [],
								[],
								[0, "Default", 0, 1]
							],
							[
								[270, 810, 0, 540, 540, 0, 0, 1, 0.5, 0.5, 0, 0, []], 11, 11, [],
								[],
								[0, "Default", 0, 1]
							],
							[
								[1058, 29, 0, 120, 120, 0, 0, 1, 1, 0, 0, 0, []], 14, 14, [],
								[],
								[0, "Default", 0, 1]
							],
							[
								[1058, 149, 0, 120, 120, 0, 0, 1, 1, 0, 0, 0, []], 15, 15, [],
								[],
								[1, "Default", 0, 1]
							],
							[
								[1058, 440, 0, 120, 120, 0, 0, 1, 1, 0, 0, 0, []], 17, 17, [],
								[],
								[1, "Default", 0, 1]
							],
							[
								[0, 0, 0, 1080, 159, 0, 0, 1, 0, 0, 0, 0, []], 19, 19, [],
								[],
								["Text", 0, "26pt Arial", "rgb(255,255,255)", 0, 0, 0, 0, 0]
							],
							[
								[240, 0, 0, 600, 160, 0, 0, 1, 0, 0, 0, 0, []], 18, 18, [
									[0],
									[0],
									[""]
								],
								[],
								[0, "", "border-width: 0px;"]
							]
						],
						[]
					]
				],
				[
					[null, 4, 4, [],
						[],
						[]
					],
					[null, 7, 7, [],
						[],
						[]
					],
					[null, 8, 8, [],
						[],
						[]
					],
					[null, 9, 10, [],
						[],
						["client.css"]
					],
					[null, 12, 12, [],
						[],
						[]
					]
				],
				[]
			]
		],
		[
			["MainEvents", [
				[1, "showDebugInfo", 0, 1, false, false, 2447692801898707, false],
				[1, "showJoysticks", 0, 1, false, false, 6960568052552574, false],
				[1, "hideJoysticks", 0, 1, false, false, 3715489092185918, false],
				[1, "oldPressedKeys", 1, "", false, false, 5667230809520629, false],
				[1, "pressedKeys", 1, "", false, false, 5034488240580791, false],
				[1, "usedKeys", 1, "", false, false, 1762478173707329, false],
				[1, "lastTestMessageTime", 0, 0, false, false, 8355941067121701, false],
				[1, "testCount", 0, 0, false, false, 7090902380437229, false],
				[1, "pictureHeight", 0, 0, false, false, 2537512275349522, false],
				[1, "pictureWidth", 0, 0, false, false, 4439639181443535, false],
				[1, "oldX", 0, 0, false, false, 1647699486674542, false],
				[1, "oldY", 0, 0, false, false, 9161433695740714, false],
				[1, "oldZ", 0, 0, false, false, 7538708403413303, false],
				[1, "oldW", 0, 0, false, false, 1906479920078791, false],
				[1, "oldA", 0, 0, false, false, 5972353306666061, false],
				[1, "oldB", 0, 0, false, false, 1153157104927991, false],
				[1, "oldC", 0, 0, false, false, 5064689432558995, false],
				[1, "oldD", 0, 0, false, false, 786927512584224, false],
				[1, "tmpAngle", 0, 0, false, false, 836185609121533, false],
				[1, "joystickCurrentPanel", 0, 0, false, false, 7183404290330898, false],
				[1, "joystickShapes", 1, "----", false, false, 8307682872537996, false],
				[1, "joystickBehaviors", 1, "00000000", false, false, 242730692073833, false],
				[1, "x", 0, 0, false, false, 6953064301391794, false],
				[1, "y", 0, 0, false, false, 3653546610868695, false],
				[1, "z", 0, 0, false, false, 9761840362493052, false],
				[1, "w", 0, 0, false, false, 6592137228013898, false],
				[1, "a", 0, 0, false, false, 1877284276058716, false],
				[1, "b", 0, 0, false, false, 9573339341609678, false],
				[1, "c", 0, 0, false, false, 9028455058677156, false],
				[1, "d", 0, 0, false, false, 6481751038084253, false],
				[1, "touchId1", 0, -1, false, false, 146005083147855, false],
				[1, "touchId2", 0, -1, false, false, 2472402470308117, false],
				[1, "domain", 1, "", false, false, 2154277533777337, false],
				[1, "control", 1, "left-handed", false, false, 638720559228413, false],
				[1, "previewHeight", 0, 0, false, false, 1345874831136563, false],
				[1, "previewWidth", 0, 0, false, false, 866317152175391, false],
				[1, "ratioY", 0, 0, false, false, 6209200604935743, false],
				[1, "ratioX", 0, 0, false, false, 9509574867946956, false],
				[1, "lang", 1, "def", false, false, 7887945286887404, false],
				[1, "port", 0, 80, false, false, 3994170770058124, false],
				[1, "portStr", 1, "", false, false, 9653656408179591, false],
				[1, "httpRoot", 1, "", false, false, 1578844985295548, false],
				[2, "Functions", false],
				[0, null, false, null, 7467258620469235, [
						[-1, 14, null, 1, false, false, false, 1680095809976735, false]
					],
					[
						[-1, 15, null, 7029325167276069, false, [
							[11, "domain"],
							[7, [20, 2, 16, true, null]]
						]],
						[3, 17, null, 9839949412957336, false, [
							[7, [2, ""]]
						]],
						[19, 17, null, 8739687159886804, false, [
							[7, [2, ""]]
						]],
						[6, 18, null, 8397585716976853, false, [
							[1, [2, "setLangByBrowserSettings"]],
							[13]
						]],
						[11, 19, null, 4056074243632011, false],
						[11, 20, null, 9210395330093076, false, [
							[0, [0, 0]]
						]],
						[10, 19, null, 9279048238731932, false],
						[10, 20, null, 7046358587500035, false, [
							[0, [0, 0]]
						]],
						[10, 21, null, 1785142158431681, false, [
							[3, 0]
						]],
						[11, 21, null, 2116508798057796, false, [
							[3, 0]
						]],
						[15, 19, null, 9577485782454701, false],
						[15, 20, null, 3706416821742659, false, [
							[0, [0, 0]]
						]],
						[17, 19, null, 543102618194812, false],
						[17, 20, null, 6528475441176344, false, [
							[0, [0, 0]]
						]],
						[6, 18, null, 7592723692904235, false, [
							[1, [2, "initStrings"]],
							[13]
						]],
						[6, 18, null, 3522056099370143, false, [
							[1, [2, "parseBrowserURL"]],
							[13]
						]],
						[5, 22, null, 9244480264470922, false, [
							[1, [2, "settings"]],
							[1, [10, [10, [23, "httpRoot"],
									[2, "/settings?sm="]
								],
								[19, 23, [
									[20, 2, 24, false, null],
									[20, 2, 25, false, null]
								]]
							]]
						]],
						[3, 17, null, 4782663684317046, false, [
							[7, [20, 6, 26, false, null, [
								[2, "getString"],
								[2, "connecting"]
							]]]
						]],
						[6, 18, null, 711448851962635, false, [
							[1, [2, "updateControls"]],
							[13]
						]],
						[16, 27, null, 8832340574085047, false, [
							[1, [2, "control"]]
						]]
					]
				],
				[0, null, false, null, 4902865429861977, [
						[5, 28, null, 1, false, false, false, 9198181470292062, false, [
							[1, [2, "settings"]]
						]]
					],
					[
						[4, 29, null, 5680499627353368, false, [
							[1, [20, 5, 30, true, null]]
						]],
						[0, 31, null, 3377931305893026, false, [
							[1, [10, [23, "httpRoot"],
								[2, "/cam"]
							]]
						]],
						[0, 32, null, 3730587945339847, false, [
							[3, 1]
						]],
						[1, 33, null, 1084164076428802, false, [
							[1, [10, [10, [10, [10, [10, [2, "ws://"],
												[23, "domain"]
											],
											[2, ":"]
										],
										[20, 4, 34, true, null, [
											[2, "/settings/cp"]
										]]
									],
									[2, "/channel?sk="]
								],
								[20, 4, 34, true, null, [
									[2, "/settings/sk"]
								]]
							]],
							[1, [2, ""]]
						]],
						[-1, 15, null, 8341236966417981, false, [
							[11, "joystickBehaviors"],
							[7, [20, 4, 34, true, null, [
								[2, "/settings/jb"]
							]]]
						]],
						[-1, 15, null, 3874701239659458, false, [
							[11, "usedKeys"],
							[7, [20, 4, 34, true, null, [
								[2, "/settings/kb"]
							]]]
						]],
						[-1, 15, null, 2237650216530537, false, [
							[11, "joystickShapes"],
							[7, [20, 4, 34, true, null, [
								[2, "/settings/js"]
							]]]
						]],
						[-1, 15, null, 1560373268980744, false, [
							[11, "hideJoysticks"],
							[7, [18, [12, [20, 4, 34, true, null, [
										[2, "/settings/hj"]
									]],
									[2, "1"]
								],
								[0, 1],
								[0, 0]
							]]
						]],
						[-1, 15, null, 5829327055862493, false, [
							[11, "showDebugInfo"],
							[7, [18, [12, [20, 4, 34, true, null, [
										[2, "/settings/di"]
									]],
									[2, "1"]
								],
								[0, 1],
								[0, 0]
							]]
						]],
						[-1, 15, null, 3241194042397787, false, [
							[11, "joystickCurrentPanel"],
							[7, [18, [10, [12, [23, "joystickCurrentPanel"],
										[0, 1]
									],
									[12, [19, 35, [
											[23, "joystickShapes"],
											[0, 2]
										]],
										[2, "--"]
									]
								],
								[0, 0],
								[23, "joystickCurrentPanel"]
							]]
						]],
						[16, 27, null, 8563908780899107, false, [
							[1, [2, "joystickCurrentPanel"]]
						]],
						[-1, 15, null, 4683708751786568, false, [
							[11, "lang"],
							[7, [20, 4, 34, true, null, [
								[2, "/settings/lng"]
							]]]
						]],
						[6, 18, null, 8755842637044578, false, [
							[1, [2, "initStrings"]],
							[13]
						]],
						[-1, 15, null, 5692852652436586, false, [
							[11, "pictureWidth"],
							[7, [20, 4, 34, true, null, [
								[2, "/settings/prw"]
							]]]
						]],
						[-1, 15, null, 9575580046923895, false, [
							[11, "pictureHeight"],
							[7, [20, 4, 34, true, null, [
								[2, "/settings/prh"]
							]]]
						]],
						[6, 18, null, 8443364246870102, false, [
							[1, [2, "updatePictureSize"]],
							[13]
						]],
						[6, 18, null, 6082294609219255, false, [
							[1, [2, "updateJoysticks"]],
							[13]
						]]
					],
					[
						[0, null, false, null, 6421036770095711, [
								[-1, 36, null, 0, false, false, false, 6308764619156149, false, [
									[7, [20, 4, 34, true, null, [
										[2, "/settings/bnp"]
									]]],
									[8, 1],
									[7, [2, ""]]
								]]
							],
							[
								[18, 37, null, 1730791319309162, false, [
									[1, [10, [23, "httpRoot"],
										[20, 4, 34, true, null, [
											[2, "/settings/bnp"]
										]]
									]]
								]],
								[18, 38, null, 2228293442115794, false, [
									[3, 1]
								]],
								[18, 39, null, 1790085642925725, false, [
									[10, 0],
									[7, [19, 40, [
										[20, 4, 34, true, null, [
											[2, "/settings/bnw"]
										]]
									]]]
								]],
								[18, 39, null, 9682749512634055, false, [
									[10, 1],
									[7, [19, 40, [
										[20, 4, 34, true, null, [
											[2, "/settings/bnh"]
										]]
									]]]
								]],
								[18, 39, null, 5724077157378131, false, [
									[10, 2],
									[7, [20, 4, 34, true, null, [
										[2, "/settings/bnu"]
									]]]
								]],
								[6, 18, null, 9883666451153792, false, [
									[1, [2, "updateBannerSize"]],
									[13]
								]]
							]
						]
					]
				],
				[0, null, false, null, 9033832524629884, [
						[5, 41, null, 1, false, false, false, 3462633416071871, false, [
							[1, [2, "settings"]]
						]]
					],
					[
						[3, 17, null, 3798256259248534, false, [
							[7, [20, 6, 26, false, null, [
								[2, "getString"],
								[2, "error_while_reading_settings"]
							]]]
						]]
					]
				],
				[0, null, false, null, 4109045238366216, [
						[1, 42, null, 1, false, false, false, 2394146740534977, false]
					],
					[
						[3, 17, null, 3147055759957843, false, [
							[7, [4, [20, 6, 26, false, null, [
									[2, "getString"],
									[2, "web_socket_error"]
								]],
								[20, 1, 43, true, null]
							]]
						]]
					]
				],
				[0, null, false, null, 4776877332340822, [
						[1, 44, null, 1, false, false, false, 7228520271205155, false]
					],
					[
						[1, 45, null, 4446913606627775, false, [
							[1, [2, "jv:x=0;y=0;z=0;w=0;a=0;b=0;c=0;d=0;"]]
						]],
						[1, 45, null, 9635561069359935, false, [
							[1, [2, "kp:000"]]
						]],
						[3, 17, null, 9797913978896868, false, [
							[7, [2, ""]]
						]],
						[19, 17, null, 4807254179740765, false, [
							[7, [2, ""]]
						]]
					]
				],
				[0, [true, "Alignment"], false, null, 6307706493409065, [
						[-1, 46, null, 0, false, false, false, 6307706493409065, false, [
							[1, [2, "Alignment"]]
						]]
					],
					[],
					[
						[0, null, false, null, 9556852339956495, [
								[6, 47, null, 2, false, false, false, 9923504695283858, false, [
									[1, [2, "updateJoysticks"]]
								]]
							],
							[
								[6, 18, null, 2162887332013509, false, [
									[1, [2, "updateControls"]],
									[13]
								]]
							],
							[
								[0, null, false, null, 2470736120150318, [
										[-1, 48, null, 0, false, false, false, 4004894759469613, false, [
											[11, "showJoysticks"],
											[8, 0],
											[7, [0, 1]]
										]]
									],
									[],
									[
										[0, null, false, null, 2311431746583287, [
												[-1, 48, null, 0, false, false, false, 6415338479535585, false, [
													[11, "joystickCurrentPanel"],
													[8, 0],
													[7, [0, 0]]
												]]
											],
											[],
											[
												[0, null, false, null, 7259927442477105, [
														[-1, 36, null, 0, false, false, false, 9322572857966843, false, [
															[7, [19, 49, [
																[23, "joystickShapes"],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "v"]]
														]]
													],
													[
														[10, 20, null, 6743547945231962, false, [
															[0, [0, 0]]
														]]
													]
												],
												[0, null, false, null, 2306309860541178, [
														[-1, 36, null, 0, false, false, false, 1850485092887555, false, [
															[7, [19, 49, [
																[23, "joystickShapes"],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "c"]]
														]]
													],
													[
														[10, 20, null, 9755906064542496, false, [
															[0, [0, 1]]
														]]
													]
												],
												[0, null, false, null, 6126701388010426, [
														[-1, 36, null, 0, false, false, false, 4603365000772514, false, [
															[7, [19, 49, [
																[23, "joystickShapes"],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "q"]]
														]]
													],
													[
														[10, 20, null, 124500325760297, false, [
															[0, [0, 2]]
														]]
													]
												],
												[0, null, false, null, 7315468483543779, [
														[-1, 36, null, 0, false, false, false, 2410295327859226, false, [
															[7, [19, 49, [
																[23, "joystickShapes"],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "a"]]
														]]
													],
													[
														[10, 20, null, 3767904845086814, false, [
															[0, [0, 3]]
														]]
													]
												],
												[0, null, false, null, 1951818725935477, [
														[-1, 36, null, 0, false, false, false, 9076580777085793, false, [
															[7, [19, 49, [
																[23, "joystickShapes"],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "h"]]
														]]
													],
													[
														[10, 20, null, 8248168003955179, false, [
															[0, [0, 4]]
														]]
													]
												],
												[0, null, false, null, 4088551430426975, [
														[-1, 36, null, 0, false, false, false, 5701851213004932, false, [
															[7, [19, 49, [
																[23, "joystickShapes"],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "t"]]
														]]
													],
													[
														[10, 20, null, 1417476098510963, false, [
															[0, [0, 5]]
														]]
													]
												],
												[0, null, false, null, 4385438019907672, [
														[-1, 36, null, 0, false, false, false, 6815614866078866, false, [
															[7, [19, 49, [
																[23, "joystickShapes"],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "l"]]
														]]
													],
													[
														[10, 20, null, 8411415939930503, false, [
															[0, [0, 6]]
														]]
													]
												],
												[0, null, false, null, 7961863486251657, [
														[-1, 36, null, 0, false, false, false, 755420323651793, false, [
															[7, [19, 49, [
																[23, "joystickShapes"],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "-"]]
														]]
													],
													[
														[10, 21, null, 8740633875115846, false, [
															[3, 0]
														]]
													]
												],
												[0, null, false, null, 4887182656625799, [
														[-1, 50, null, 0, false, false, false, 2777848512009143, false]
													],
													[
														[10, 21, null, 4950915173103304, false, [
															[3, 1]
														]]
													]
												],
												[0, null, false, null, 3052834427366634, [
														[-1, 36, null, 0, false, false, false, 588748577227586, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 2]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "v"]]
														]]
													],
													[
														[11, 20, null, 991829121955076, false, [
															[0, [0, 0]]
														]]
													]
												],
												[0, null, false, null, 1332389059160107, [
														[-1, 36, null, 0, false, false, false, 3077524482910818, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 2]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "c"]]
														]]
													],
													[
														[11, 20, null, 9907227452664703, false, [
															[0, [0, 1]]
														]]
													]
												],
												[0, null, false, null, 869274093539319, [
														[-1, 36, null, 0, false, false, false, 9208177520693874, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 2]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "q"]]
														]]
													],
													[
														[11, 20, null, 5220296167031373, false, [
															[0, [0, 2]]
														]]
													]
												],
												[0, null, false, null, 8367219236894681, [
														[-1, 36, null, 0, false, false, false, 4444185057301407, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 2]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "a"]]
														]]
													],
													[
														[11, 20, null, 1490370702127033, false, [
															[0, [0, 3]]
														]]
													]
												],
												[0, null, false, null, 5021685997028746, [
														[-1, 36, null, 0, false, false, false, 2701725361603199, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 2]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "h"]]
														]]
													],
													[
														[11, 20, null, 5119774178727313, false, [
															[0, [0, 4]]
														]]
													]
												],
												[0, null, false, null, 7711754146637676, [
														[-1, 36, null, 0, false, false, false, 9965963281177645, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 2]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "t"]]
														]]
													],
													[
														[11, 20, null, 5176781672438689, false, [
															[0, [0, 5]]
														]]
													]
												],
												[0, null, false, null, 6296339110842758, [
														[-1, 36, null, 0, false, false, false, 8218041331287345, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 2]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "l"]]
														]]
													],
													[
														[11, 20, null, 1060195909892481, false, [
															[0, [0, 6]]
														]]
													]
												],
												[0, null, false, null, 83531520995859, [
														[-1, 36, null, 0, false, false, false, 1537221274735854, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 2]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "-"]]
														]]
													],
													[
														[11, 21, null, 5949866044810997, false, [
															[3, 0]
														]]
													]
												],
												[0, null, false, null, 3082453963093856, [
														[-1, 50, null, 0, false, false, false, 564696852815417, false]
													],
													[
														[11, 21, null, 1255800314131982, false, [
															[3, 1]
														]]
													]
												]
											]
										],
										[0, null, false, null, 8485441644021405, [
												[-1, 50, null, 0, false, false, false, 8931202422118063, false]
											],
											[],
											[
												[0, null, false, null, 4077120296551922, [
														[-1, 36, null, 0, false, false, false, 5772119543514222, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 3]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "v"]]
														]]
													],
													[
														[10, 20, null, 262956147423086, false, [
															[0, [0, 0]]
														]]
													]
												],
												[0, null, false, null, 5017067218786893, [
														[-1, 36, null, 0, false, false, false, 6513455807884666, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 3]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "c"]]
														]]
													],
													[
														[10, 20, null, 6416678591020069, false, [
															[0, [0, 1]]
														]]
													]
												],
												[0, null, false, null, 5661593422313555, [
														[-1, 36, null, 0, false, false, false, 9355339944882518, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 3]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "q"]]
														]]
													],
													[
														[10, 20, null, 1925201030968892, false, [
															[0, [0, 2]]
														]]
													]
												],
												[0, null, false, null, 2045737882426598, [
														[-1, 36, null, 0, false, false, false, 2945218960143807, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 3]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "a"]]
														]]
													],
													[
														[10, 20, null, 1305403044345841, false, [
															[0, [0, 3]]
														]]
													]
												],
												[0, null, false, null, 344606052255423, [
														[-1, 36, null, 0, false, false, false, 2776079200284899, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 3]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "h"]]
														]]
													],
													[
														[10, 20, null, 5173170274111749, false, [
															[0, [0, 4]]
														]]
													]
												],
												[0, null, false, null, 4745672297123242, [
														[-1, 36, null, 0, false, false, false, 7840764724522697, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 3]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "t"]]
														]]
													],
													[
														[10, 20, null, 4105905788450294, false, [
															[0, [0, 5]]
														]]
													]
												],
												[0, null, false, null, 1546272153823831, [
														[-1, 36, null, 0, false, false, false, 524954704313949, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 3]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "l"]]
														]]
													],
													[
														[10, 20, null, 8898789008759926, false, [
															[0, [0, 6]]
														]]
													]
												],
												[0, null, false, null, 4518944516788695, [
														[-1, 36, null, 0, false, false, false, 8183336145915392, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 3]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "-"]]
														]]
													],
													[
														[10, 21, null, 3462843421167943, false, [
															[3, 0]
														]]
													]
												],
												[0, null, false, null, 8746186684462889, [
														[-1, 50, null, 0, false, false, false, 6520444005580216, false]
													],
													[
														[10, 21, null, 2454521365634271, false, [
															[3, 1]
														]]
													]
												],
												[0, null, false, null, 7706817950209533, [
														[-1, 36, null, 0, false, false, false, 383291885148775, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 4]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "v"]]
														]]
													],
													[
														[11, 20, null, 5168744314308559, false, [
															[0, [0, 0]]
														]]
													]
												],
												[0, null, false, null, 8647521306943056, [
														[-1, 36, null, 0, false, false, false, 117684783736383, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 4]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "c"]]
														]]
													],
													[
														[11, 20, null, 8443965597911774, false, [
															[0, [0, 1]]
														]]
													]
												],
												[0, null, false, null, 8012182782664364, [
														[-1, 36, null, 0, false, false, false, 3004286907937782, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 4]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "q"]]
														]]
													],
													[
														[11, 20, null, 874675791552099, false, [
															[0, [0, 2]]
														]]
													]
												],
												[0, null, false, null, 370650383691096, [
														[-1, 36, null, 0, false, false, false, 1953093324252266, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 4]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "a"]]
														]]
													],
													[
														[11, 20, null, 2346505288619969, false, [
															[0, [0, 3]]
														]]
													]
												],
												[0, null, false, null, 205297886294832, [
														[-1, 36, null, 0, false, false, false, 816363077390811, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 4]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "h"]]
														]]
													],
													[
														[11, 20, null, 1938007975122855, false, [
															[0, [0, 4]]
														]]
													]
												],
												[0, null, false, null, 5696834300703586, [
														[-1, 36, null, 0, false, false, false, 7659580456870595, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 4]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "t"]]
														]]
													],
													[
														[11, 20, null, 7660990177561835, false, [
															[0, [0, 5]]
														]]
													]
												],
												[0, null, false, null, 8330773800727901, [
														[-1, 36, null, 0, false, false, false, 7422929620957997, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 4]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "l"]]
														]]
													],
													[
														[11, 20, null, 5686142246593981, false, [
															[0, [0, 6]]
														]]
													]
												],
												[0, null, false, null, 1644198608101705, [
														[-1, 36, null, 0, false, false, false, 8722648555960045, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickShapes"],
																	[0, 4]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "-"]]
														]]
													],
													[
														[11, 21, null, 5013264374107021, false, [
															[3, 0]
														]]
													]
												],
												[0, null, false, null, 589549030569083, [
														[-1, 50, null, 0, false, false, false, 673911739935482, false]
													],
													[
														[11, 21, null, 9428285646666233, false, [
															[3, 1]
														]]
													]
												]
											]
										]
									]
								],
								[0, null, false, null, 6574176846900601, [
										[-1, 50, null, 0, false, false, false, 5756604097391194, false]
									],
									[
										[10, 21, null, 8643402560199737, false, [
											[3, 0]
										]],
										[11, 21, null, 2840803641869869, false, [
											[3, 0]
										]]
									]
								]
							]
						],
						[0, null, false, null, 7653629854138248, [
								[6, 47, null, 2, false, false, false, 2946603303265244, false, [
									[1, [2, "updateControls"]]
								]]
							],
							[
								[14, 51, null, 9828052376818159, false, [
									[0, [5, [19, 52, [
											[0, 0]
										]],
										[0, 30]
									]],
									[0, [4, [19, 53, [
											[0, 0]
										]],
										[0, 30]
									]]
								]],
								[15, 51, null, 4691984820368347, false, [
									[0, [5, [19, 52, [
											[0, 0]
										]],
										[0, 30]
									]],
									[0, [4, [4, [19, 53, [
												[0, 0]
											]],
											[0, 30]
										],
										[0, 120]
									]]
								]],
								[17, 51, null, 6578348000146128, false, [
									[0, [5, [19, 52, [
											[0, 0]
										]],
										[0, 30]
									]],
									[0, [5, [5, [5, [19, 54, [
													[0, 0]
												]],
												[20, 10, 55, false, null]
											],
											[20, 17, 55, false, null]
										],
										[0, 30]
									]]
								]],
								[17, 20, null, 502353772064611, false, [
									[0, [23, "joystickCurrentPanel"]]
								]]
							],
							[
								[0, null, false, null, 3325675374407581, [
										[-1, 48, null, 0, false, false, false, 311002389898355, false, [
											[11, "showJoysticks"],
											[8, 0],
											[7, [0, 1]]
										]]
									],
									[
										[15, 21, null, 434847374327061, false, [
											[3, 1]
										]],
										[17, 21, null, 1124453311996555, false, [
											[3, 1]
										]]
									],
									[
										[0, null, false, null, 3406869816688723, [
												[-1, 48, null, 0, false, false, false, 4406019715768859, false, [
													[11, "control"],
													[8, 0],
													[7, [2, "left-handed"]]
												]]
											],
											[
												[10, 51, null, 9681463879801257, false, [
													[0, [5, [19, 52, [
															[0, 0]
														]],
														[7, [20, 10, 56, false, null],
															[0, 2]
														]
													]],
													[0, [5, [19, 54, [
															[0, 0]
														]],
														[7, [20, 10, 55, false, null],
															[0, 2]
														]
													]]
												]],
												[11, 51, null, 6220717948664814, false, [
													[0, [4, [19, 57, [
															[0, 0]
														]],
														[7, [20, 11, 56, false, null],
															[0, 2]
														]
													]],
													[0, [5, [19, 54, [
															[0, 0]
														]],
														[7, [20, 11, 55, false, null],
															[0, 2]
														]
													]]
												]],
												[15, 20, null, 3123966874828627, false, [
													[0, [0, 0]]
												]]
											]
										],
										[0, null, false, null, 8833473331204709, [
												[-1, 50, null, 0, false, false, false, 8191811347584731, false]
											],
											[
												[10, 51, null, 7082851528549659, false, [
													[0, [4, [19, 57, [
															[0, 0]
														]],
														[7, [20, 10, 56, false, null],
															[0, 2]
														]
													]],
													[0, [5, [19, 54, [
															[0, 0]
														]],
														[7, [20, 10, 55, false, null],
															[0, 2]
														]
													]]
												]],
												[11, 51, null, 4741460236922111, false, [
													[0, [5, [19, 52, [
															[0, 0]
														]],
														[7, [20, 11, 56, false, null],
															[0, 2]
														]
													]],
													[0, [5, [19, 54, [
															[0, 0]
														]],
														[7, [20, 11, 55, false, null],
															[0, 2]
														]
													]]
												]],
												[15, 20, null, 1473383189226129, false, [
													[0, [0, 1]]
												]]
											]
										],
										[0, null, false, null, 2202025916115224, [
												[-1, 48, null, 0, false, false, false, 2162487896978612, false, [
													[11, "joystickShapes"],
													[8, 0],
													[7, [2, "----"]]
												]]
											],
											[
												[17, 21, null, 4079488711147601, false, [
													[3, 0]
												]],
												[15, 21, null, 7232410462956003, false, [
													[3, 0]
												]]
											]
										],
										[0, null, false, null, 769375310779687, [
												[-1, 50, null, 0, false, false, false, 6055865767479393, false]
											],
											[
												[15, 21, null, 7360486952526212, false, [
													[3, 1]
												]]
											],
											[
												[0, null, false, null, 294835269832736, [
														[-1, 36, null, 0, false, false, false, 1651872845577164, false, [
															[7, [18, [11, [12, [19, 49, [
																			[23, "joystickShapes"],
																			[0, 2]
																		]],
																		[2, "--"]
																	],
																	[12, [19, 35, [
																			[23, "joystickShapes"],
																			[0, 2]
																		]],
																		[2, "--"]
																	]
																],
																[0, 1],
																[0, 0]
															]],
															[8, 0],
															[7, [0, 1]]
														]]
													],
													[
														[17, 21, null, 6494408576290458, false, [
															[3, 0]
														]]
													]
												],
												[0, null, false, null, 593025944442571, [
														[-1, 50, null, 0, false, false, false, 5566815524331624, false]
													],
													[
														[17, 21, null, 4684988868530845, false, [
															[3, 1]
														]]
													]
												]
											]
										]
									]
								],
								[0, null, false, null, 2806306207403339, [
										[-1, 50, null, 0, false, false, false, 6653511935638018, false]
									],
									[
										[15, 21, null, 6554916026027041, false, [
											[3, 0]
										]],
										[17, 21, null, 356665786921676, false, [
											[3, 0]
										]]
									]
								]
							]
						],
						[0, null, false, null, 5948326616220129, [
								[2, 58, null, 1, false, false, false, 200096778546639, false]
							],
							[
								[-1, 59, null, 5326119728777443, false, [
									[0, [1, 0.5]]
								]],
								[6, 18, null, 297272532822491, false, [
									[1, [2, "updatePictureSize"]],
									[13]
								]],
								[6, 18, null, 3430286164025999, false, [
									[1, [2, "updateControls"]],
									[13]
								]],
								[6, 18, null, 7905163513247329, false, [
									[1, [2, "updateBannerSize"]],
									[13]
								]]
							]
						],
						[0, null, false, null, 7806004828741104, [
								[6, 47, null, 2, false, false, false, 7452947371865661, false, [
									[1, [2, "updateBannerSize"]]
								]]
							],
							[],
							[
								[0, null, false, null, 748119436667929, [
										[18, 60, null, 0, false, false, false, 1184784377527621, false, [
											[10, 0],
											[8, 4],
											[7, [0, 0]]
										]],
										[18, 60, null, 0, false, false, false, 5802137145391736, false, [
											[10, 1],
											[8, 4],
											[7, [0, 0]]
										]]
									],
									[
										[18, 61, null, 9458488773430626, false, [
											[0, [6, [6, [21, 18, false, null, 0],
													[7, [5, [19, 52, [
																[0, 0]
															]],
															[19, 57, [
																[0, 0]
															]]
														],
														[19, 62]
													]
												],
												[20, 2, 63, false, null]
											]],
											[0, [6, [6, [21, 18, false, null, 1],
													[7, [5, [19, 54, [
																[0, 0]
															]],
															[19, 53, [
																[0, 0]
															]]
														],
														[19, 64]
													]
												],
												[20, 2, 63, false, null]
											]]
										]],
										[18, 65, null, 3135879172665419, false, [
											[0, [7, [5, [19, 66],
													[20, 18, 67, false, null]
												],
												[0, 2]
											]],
											[0, [19, 53, [
												[0, 0]
											]]]
										]]
									]
								]
							]
						],
						[0, null, false, null, 9410735097177219, [
								[6, 47, null, 2, false, false, false, 8740699436960895, false, [
									[1, [2, "updatePictureSize"]]
								]]
							],
							[
								[-1, 15, null, 7669653839481018, false, [
									[11, "ratioX"],
									[7, [7, [19, 68, [
											[5, [19, 52, [
													[0, 0]
												]],
												[19, 57, [
													[0, 0]
												]]
											]
										]],
										[19, 68, [
											[23, "pictureWidth"]
										]]
									]]
								]],
								[-1, 15, null, 1329054999039278, false, [
									[11, "ratioY"],
									[7, [7, [19, 68, [
											[5, [19, 54, [
													[0, 0]
												]],
												[19, 53, [
													[0, 0]
												]]
											]
										]],
										[19, 68, [
											[23, "pictureHeight"]
										]]
									]]
								]]
							],
							[
								[0, null, false, null, 5977018579629346, [
										[-1, 36, null, 0, false, false, false, 9259705843548434, false, [
											[7, [23, "ratioX"]],
											[8, 2],
											[7, [23, "ratioY"]]
										]]
									],
									[
										[0, 69, null, 666715443599214, false, [
											[0, [5, [19, 52, [
													[0, 0]
												]],
												[19, 57, [
													[0, 0]
												]]
											]],
											[0, [6, [19, 68, [
													[23, "pictureHeight"]
												]],
												[23, "ratioX"]
											]]
										]],
										[0, 70, null, 6634807890329514, false, [
											[0, [19, 57, [
												[0, 0]
											]]],
											[0, [7, [5, [19, 71],
													[20, 0, 72, false, null]
												],
												[0, 2]
											]]
										]]
									]
								],
								[0, null, false, null, 8639285496216246, [
										[-1, 50, null, 0, false, false, false, 3355136689022072, false]
									],
									[
										[0, 69, null, 954069060335638, false, [
											[0, [6, [19, 68, [
													[23, "pictureWidth"]
												]],
												[19, 68, [
													[23, "ratioY"]
												]]
											]],
											[0, [5, [19, 54, [
													[0, 0]
												]],
												[19, 53, [
													[0, 0]
												]]
											]]
										]],
										[0, 70, null, 3790912076302654, false, [
											[0, [7, [5, [19, 66],
													[20, 0, 73, false, null]
												],
												[0, 2]
											]],
											[0, [19, 53, [
												[0, 0]
											]]]
										]]
									]
								]
							]
						]
					]
				],
				[0, [true, "Keyboard"], false, null, 3104443543604468, [
						[-1, 46, null, 0, false, false, false, 3104443543604468, false, [
							[1, [2, "Keyboard"]]
						]]
					],
					[],
					[
						[0, null, false, null, 2362024051999534, [
								[6, 47, null, 2, false, false, false, 3758590718933115, false, [
									[1, [2, "checkKeys"]]
								]]
							],
							[
								[-1, 15, null, 4999193286126406, false, [
									[11, "pressedKeys"],
									[7, [2, ""]]
								]]
							],
							[
								[0, null, false, null, 4604168279561667, [
										[-1, 74, null, 0, true, false, false, 3459270091636068, false, [
											[1, [2, "keyChecker"]],
											[0, [0, 0]],
											[0, [5, [7, [19, 75, [
														[23, "usedKeys"]
													]],
													[0, 3]
												],
												[0, 1]
											]]
										]]
									],
									[],
									[
										[0, null, false, null, 1734034806043203, [
												[20, 76, null, 0, false, false, false, 8385125233047933, false, [
													[0, [19, 40, [
														[19, 77, [
															[23, "usedKeys"],
															[6, [19, 78],
																[0, 3]
															],
															[0, 3]
														]]
													]]]
												]]
											],
											[
												[-1, 15, null, 4594162541612522, false, [
													[11, "pressedKeys"],
													[7, [10, [23, "pressedKeys"],
														[19, 77, [
															[23, "usedKeys"],
															[6, [19, 78],
																[0, 3]
															],
															[0, 3]
														]]
													]]
												]]
											]
										]
									]
								]
							]
						],
						[0, null, false, null, 2919703460911434, [
								[6, 47, null, 2, false, false, false, 6911664112046346, false, [
									[1, [2, "sendPressedKeys"]]
								]]
							],
							[],
							[
								[0, null, false, null, 8184625357511258, [
										[-1, 48, null, 0, false, false, false, 1764901947890882, false, [
											[11, "pressedKeys"],
											[8, 1],
											[7, [23, "oldPressedKeys"]]
										]]
									],
									[
										[1, 45, null, 6761327752231831, false, [
											[1, [10, [2, "kp:"],
												[23, "pressedKeys"]
											]]
										]],
										[-1, 15, null, 5370693678367176, false, [
											[11, "oldPressedKeys"],
											[7, [23, "pressedKeys"]]
										]],
										[6, 18, null, 7990973344622326, false, [
											[1, [2, "showKeys"]],
											[13]
										]]
									]
								],
								[0, null, false, null, 5567073208990034, [
										[-1, 48, null, 0, false, false, false, 975204624221976, false, [
											[11, "showJoysticks"],
											[8, 0],
											[7, [0, 1]]
										]],
										[-1, 48, null, 0, false, false, false, 5183095008201587, false, [
											[11, "hideJoysticks"],
											[8, 0],
											[7, [0, 1]]
										]],
										[-1, 48, null, 0, false, false, false, 496432052604791, false, [
											[11, "pressedKeys"],
											[8, 1],
											[7, [2, ""]]
										]]
									],
									[
										[-1, 15, null, 7282743318645989, false, [
											[11, "showJoysticks"],
											[7, [0, 0]]
										]],
										[6, 18, null, 3578154113919828, false, [
											[1, [2, "updateJoysticks"]],
											[13]
										]],
										[6, 18, null, 5921394016397385, false, [
											[1, [2, "updateControls"]],
											[13]
										]]
									]
								]
							]
						],
						[0, null, false, null, 767487017083609, [
								[6, 47, null, 2, false, false, false, 5485753439761617, false, [
									[1, [2, "showKeys"]]
								]]
							],
							[
								[19, 17, null, 2505467498480182, false, [
									[7, [2, ""]]
								]]
							],
							[
								[0, null, false, null, 1602297019128228, [
										[-1, 74, null, 0, true, false, false, 1352992590716975, false, [
											[1, [2, "keyShower"]],
											[0, [0, 0]],
											[0, [5, [7, [19, 75, [
														[23, "pressedKeys"]
													]],
													[0, 3]
												],
												[0, 1]
											]]
										]]
									],
									[],
									[
										[0, null, false, null, 3155699204360004, [
												[-1, 36, null, 0, false, false, false, 7883291072125451, false, [
													[7, [19, 40, [
														[19, 77, [
															[23, "pressedKeys"],
															[6, [19, 78],
																[0, 3]
															],
															[0, 3]
														]]
													]]],
													[8, 4],
													[7, [0, 0]]
												]]
											],
											[
												[19, 17, null, 8345338939616042, false, [
													[7, [10, [18, [12, [20, 19, 79, true, null],
																[2, ""]
															],
															[2, ""],
															[10, [20, 19, 79, true, null],
																[2, ", "]
															]
														],
														[19, 80, [
															[19, 40, [
																[19, 77, [
																	[23, "pressedKeys"],
																	[6, [19, 78],
																		[0, 3]
																	],
																	[0, 3]
																]]
															]]
														]]
													]]
												]]
											]
										]
									]
								]
							]
						]
					]
				],
				[0, [true, "Touching"], false, null, 3755647968920593, [
						[-1, 46, null, 0, false, false, false, 3755647968920593, false, [
							[1, [2, "Touching"]]
						]]
					],
					[],
					[
						[0, null, false, null, 9488571855042725, [
								[13, 81, null, 1, false, false, false, 1011690215698408, false]
							],
							[],
							[
								[0, null, false, null, 8627782987759432, [
										[13, 82, null, 0, false, false, false, 5092987933052231, false, [
											[4, 10]
										]],
										[-1, 48, null, 0, false, false, false, 1279889821012756, false, [
											[11, "touchId1"],
											[8, 2],
											[7, [0, 0]]
										]],
										[-1, 48, null, 0, false, false, false, 4867416628488395, false, [
											[11, "showJoysticks"],
											[8, 0],
											[7, [0, 1]]
										]]
									],
									[
										[-1, 15, null, 385780277253999, false, [
											[11, "touchId1"],
											[7, [20, 13, 83, false, null]]
										]]
									]
								],
								[0, null, false, null, 2010059556699685, [
										[13, 82, null, 0, false, false, false, 8252083220785678, false, [
											[4, 11]
										]],
										[-1, 48, null, 0, false, false, false, 4165447930747758, false, [
											[11, "touchId2"],
											[8, 2],
											[7, [0, 0]]
										]],
										[-1, 48, null, 0, false, false, false, 2475007597043275, false, [
											[11, "showJoysticks"],
											[8, 0],
											[7, [0, 1]]
										]]
									],
									[
										[-1, 15, null, 3069773189404767, false, [
											[11, "touchId2"],
											[7, [20, 13, 83, false, null]]
										]]
									]
								],
								[0, null, false, null, 8847573202879449, [
										[-1, 48, null, 0, false, false, false, 5768807625698131, false, [
											[11, "showJoysticks"],
											[8, 0],
											[7, [0, 0]]
										]]
									],
									[
										[-1, 15, null, 143648351548994, false, [
											[11, "showJoysticks"],
											[7, [0, 1]]
										]],
										[6, 18, null, 1239311904173554, false, [
											[1, [2, "updateJoysticks"]],
											[13]
										]],
										[6, 18, null, 1512079308666276, false, [
											[1, [2, "updateControls"]],
											[13]
										]]
									]
								]
							]
						],
						[0, null, false, null, 3755104098343682, [
								[13, 84, null, 1, false, false, false, 5314802085741222, false]
							],
							[],
							[
								[0, null, false, null, 8011729468973743, [
										[-1, 36, null, 0, false, false, false, 2630160081376461, false, [
											[7, [20, 13, 83, false, null]],
											[8, 0],
											[7, [23, "touchId1"]]
										]]
									],
									[
										[6, 18, null, 9607248969987882, false, [
											[1, [2, "releaseTouchId"]],
											[13, [7, [0, 1]]]
										]]
									]
								],
								[0, null, false, null, 7548520686606349, [
										[-1, 36, null, 0, false, false, false, 4002580339369126, false, [
											[7, [20, 13, 83, false, null]],
											[8, 0],
											[7, [23, "touchId2"]]
										]]
									],
									[
										[6, 18, null, 4392259832912043, false, [
											[1, [2, "releaseTouchId"]],
											[13, [7, [0, 2]]]
										]]
									]
								]
							]
						],
						[0, null, false, null, 1181742766314271, [
								[6, 47, null, 2, false, false, false, 4028619411550372, false, [
									[1, [2, "releaseTouchId"]]
								]]
							],
							[],
							[
								[0, null, false, null, 8709705945559459, [
										[6, 85, null, 0, false, false, false, 8734494670469624, false, [
											[0, [0, 0]],
											[8, 0],
											[7, [0, 1]]
										]]
									],
									[
										[-1, 15, null, 5344546622839321, false, [
											[11, "touchId1"],
											[7, [0, -1]]
										]]
									],
									[
										[0, null, false, null, 3409402818711475, [
												[-1, 48, null, 0, false, false, false, 6053642027931756, false, [
													[11, "joystickCurrentPanel"],
													[8, 0],
													[7, [0, 0]]
												]]
											],
											[],
											[
												[0, null, false, null, 227657696578641, [
														[-1, 36, null, 0, false, false, false, 7095689561887566, false, [
															[7, [19, 49, [
																[23, "joystickBehaviors"],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "0"]]
														]]
													],
													[
														[-1, 15, null, 7046076005542966, false, [
															[11, "x"],
															[7, [0, 0]]
														]]
													]
												],
												[0, null, false, null, 9582593481611607, [
														[-1, 36, null, 0, false, false, false, 9547144494177393, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickBehaviors"],
																	[0, 2]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "0"]]
														]]
													],
													[
														[-1, 15, null, 9694610662140156, false, [
															[11, "y"],
															[7, [0, 0]]
														]]
													]
												]
											]
										],
										[0, null, false, null, 4843746895699922, [
												[-1, 50, null, 0, false, false, false, 5212370782402334, false]
											],
											[],
											[
												[0, null, false, null, 768967766213193, [
														[-1, 36, null, 0, false, false, false, 1365947835102928, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickBehaviors"],
																	[0, 5]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "0"]]
														]]
													],
													[
														[-1, 15, null, 3399117150903155, false, [
															[11, "a"],
															[7, [0, 0]]
														]]
													]
												],
												[0, null, false, null, 8760348020475568, [
														[-1, 36, null, 0, false, false, false, 5036484344714282, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickBehaviors"],
																	[0, 6]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "0"]]
														]]
													],
													[
														[-1, 15, null, 8812806041002939, false, [
															[11, "b"],
															[7, [0, 0]]
														]]
													]
												]
											]
										]
									]
								],
								[0, null, false, null, 4438189786454149, [
										[6, 85, null, 0, false, false, false, 9281325940950812, false, [
											[0, [0, 0]],
											[8, 0],
											[7, [0, 2]]
										]]
									],
									[
										[-1, 15, null, 9610423752287305, false, [
											[11, "touchId2"],
											[7, [0, -1]]
										]]
									],
									[
										[0, null, false, null, 3011442393198059, [
												[-1, 48, null, 0, false, false, false, 1663356231238745, false, [
													[11, "joystickCurrentPanel"],
													[8, 0],
													[7, [0, 0]]
												]]
											],
											[],
											[
												[0, null, false, null, 6226471189085127, [
														[-1, 36, null, 0, false, false, false, 7262281948090899, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickBehaviors"],
																	[0, 3]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "0"]]
														]]
													],
													[
														[-1, 15, null, 2833714405366755, false, [
															[11, "w"],
															[7, [0, 0]]
														]]
													]
												],
												[0, null, false, null, 5208045756591523, [
														[-1, 36, null, 0, false, false, false, 7567276645945844, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickBehaviors"],
																	[0, 4]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "0"]]
														]]
													],
													[
														[-1, 15, null, 6637692618878522, false, [
															[11, "z"],
															[7, [0, 0]]
														]]
													]
												]
											]
										],
										[0, null, false, null, 6897654363549974, [
												[-1, 50, null, 0, false, false, false, 8410694743413275, false]
											],
											[],
											[
												[0, null, false, null, 9377509718988971, [
														[-1, 36, null, 0, false, false, false, 9429947022993086, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickBehaviors"],
																	[0, 7]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "0"]]
														]]
													],
													[
														[-1, 15, null, 1797024691835491, false, [
															[11, "c"],
															[7, [0, 0]]
														]]
													]
												],
												[0, null, false, null, 8172344269340459, [
														[-1, 36, null, 0, false, false, false, 6484726608657636, false, [
															[7, [19, 35, [
																[19, 49, [
																	[23, "joystickBehaviors"],
																	[0, 8]
																]],
																[0, 1]
															]]],
															[8, 0],
															[7, [2, "0"]]
														]]
													],
													[
														[-1, 15, null, 633355918800976, false, [
															[11, "d"],
															[7, [0, 0]]
														]]
													]
												]
											]
										]
									]
								],
								[0, null, true, null, 1513746633177805, [
										[-1, 48, null, 0, false, false, false, 2684040264859736, false, [
											[11, "touchId2"],
											[8, 2],
											[7, [0, 0]]
										]],
										[-1, 48, null, 0, false, false, false, 8147368867937214, false, [
											[11, "touchId1"],
											[8, 2],
											[7, [0, 0]]
										]]
									],
									[
										[6, 18, null, 8860039289589638, false, [
											[1, [2, "sendJoystickValues"]],
											[13]
										]]
									]
								]
							]
						],
						[0, null, false, null, 1434140479834404, [
								[-1, 86, null, 0, false, false, false, 1635553651335432, false]
							],
							[
								[6, 18, null, 4785969403714059, false, [
									[1, [2, "calculateJoystickValues"]],
									[13]
								]],
								[6, 18, null, 3528050705892775, false, [
									[1, [2, "sendJoystickValues"]],
									[13]
								]],
								[6, 18, null, 317644408137373, false, [
									[1, [2, "checkKeys"]],
									[13]
								]],
								[6, 18, null, 3942906403082778, false, [
									[1, [2, "sendPressedKeys"]],
									[13]
								]],
								[6, 18, null, 4945109371656173, false, [
									[1, [2, "sendTestMessage"]],
									[13]
								]]
							]
						],
						[0, null, false, null, 1991613631421243, [
								[6, 47, null, 2, false, false, false, 1246998567739284, false, [
									[1, [2, "sendJoystickValues"]]
								]]
							],
							[],
							[
								[0, null, true, null, 4039794592525342, [
										[-1, 48, null, 0, false, false, false, 8642039247733646, false, [
											[11, "x"],
											[8, 1],
											[7, [23, "oldX"]]
										]],
										[-1, 48, null, 0, false, false, false, 1845238237889551, false, [
											[11, "y"],
											[8, 1],
											[7, [23, "oldY"]]
										]],
										[-1, 48, null, 0, false, false, false, 9070189500504901, false, [
											[11, "z"],
											[8, 1],
											[7, [23, "oldZ"]]
										]],
										[-1, 48, null, 0, false, false, false, 4191534899072924, false, [
											[11, "w"],
											[8, 1],
											[7, [23, "oldW"]]
										]],
										[-1, 48, null, 0, false, false, false, 8506206911501139, false, [
											[11, "a"],
											[8, 1],
											[7, [23, "oldA"]]
										]],
										[-1, 48, null, 0, false, false, false, 3108277589981669, false, [
											[11, "b"],
											[8, 1],
											[7, [23, "oldB"]]
										]],
										[-1, 48, null, 0, false, false, false, 2043559754473418, false, [
											[11, "c"],
											[8, 1],
											[7, [23, "oldC"]]
										]],
										[-1, 48, null, 0, false, false, false, 2327610985070926, false, [
											[11, "d"],
											[8, 1],
											[7, [23, "oldD"]]
										]]
									],
									[
										[19, 17, null, 5428448565486166, false, [
											[7, [10, [10, [10, [10, [10, [10, [10, [18, [13, [23, "x"],
																				[23, "oldX"]
																			],
																			[10, [10, [2, "x="],
																					[23, "x"]
																				],
																				[2, ";"]
																			],
																			[2, ""]
																		],
																		[18, [13, [23, "y"],
																				[23, "oldY"]
																			],
																			[10, [10, [2, "y="],
																					[23, "y"]
																				],
																				[2, ";"]
																			],
																			[2, ""]
																		]
																	],
																	[18, [13, [23, "w"],
																			[23, "oldW"]
																		],
																		[10, [10, [2, "w="],
																				[23, "w"]
																			],
																			[2, ";"]
																		],
																		[2, ""]
																	]
																],
																[18, [13, [23, "z"],
																		[23, "oldZ"]
																	],
																	[10, [10, [2, "z="],
																			[23, "z"]
																		],
																		[2, ";"]
																	],
																	[2, ""]
																]
															],
															[18, [13, [23, "a"],
																	[23, "oldA"]
																],
																[10, [10, [2, "a="],
																		[23, "a"]
																	],
																	[2, ";"]
																],
																[2, ""]
															]
														],
														[18, [13, [23, "b"],
																[23, "oldB"]
															],
															[10, [10, [2, "b="],
																	[23, "b"]
																],
																[2, ";"]
															],
															[2, ""]
														]
													],
													[18, [13, [23, "c"],
															[23, "oldC"]
														],
														[10, [10, [2, "c="],
																[23, "c"]
															],
															[2, ";"]
														],
														[2, ""]
													]
												],
												[18, [13, [23, "d"],
														[23, "oldD"]
													],
													[10, [10, [2, "d="],
															[23, "d"]
														],
														[2, ";"]
													],
													[2, ""]
												]
											]]
										]],
										[1, 45, null, 3262906518975548, false, [
											[1, [10, [10, [10, [10, [10, [10, [10, [10, [2, "jv:"],
																			[18, [13, [23, "x"],
																					[23, "oldX"]
																				],
																				[10, [10, [2, "x="],
																						[23, "x"]
																					],
																					[2, ";"]
																				],
																				[2, ""]
																			]
																		],
																		[18, [13, [23, "y"],
																				[23, "oldY"]
																			],
																			[10, [10, [2, "y="],
																					[23, "y"]
																				],
																				[2, ";"]
																			],
																			[2, ""]
																		]
																	],
																	[18, [13, [23, "w"],
																			[23, "oldW"]
																		],
																		[10, [10, [2, "w="],
																				[23, "w"]
																			],
																			[2, ";"]
																		],
																		[2, ""]
																	]
																],
																[18, [13, [23, "z"],
																		[23, "oldZ"]
																	],
																	[10, [10, [2, "z="],
																			[23, "z"]
																		],
																		[2, ";"]
																	],
																	[2, ""]
																]
															],
															[18, [13, [23, "a"],
																	[23, "oldA"]
																],
																[10, [10, [2, "a="],
																		[23, "a"]
																	],
																	[2, ";"]
																],
																[2, ""]
															]
														],
														[18, [13, [23, "b"],
																[23, "oldB"]
															],
															[10, [10, [2, "b="],
																	[23, "b"]
																],
																[2, ";"]
															],
															[2, ""]
														]
													],
													[18, [13, [23, "c"],
															[23, "oldC"]
														],
														[10, [10, [2, "c="],
																[23, "c"]
															],
															[2, ";"]
														],
														[2, ""]
													]
												],
												[18, [13, [23, "d"],
														[23, "oldD"]
													],
													[10, [10, [2, "d="],
															[23, "d"]
														],
														[2, ";"]
													],
													[2, ""]
												]
											]]
										]],
										[-1, 15, null, 9277489860467713, false, [
											[11, "oldX"],
											[7, [23, "x"]]
										]],
										[-1, 15, null, 6755927900612214, false, [
											[11, "oldY"],
											[7, [23, "y"]]
										]],
										[-1, 15, null, 8842023812043039, false, [
											[11, "oldZ"],
											[7, [23, "z"]]
										]],
										[-1, 15, null, 3644366533415158, false, [
											[11, "oldW"],
											[7, [23, "w"]]
										]],
										[-1, 15, null, 743874066195801, false, [
											[11, "oldA"],
											[7, [23, "a"]]
										]],
										[-1, 15, null, 4150647080261803, false, [
											[11, "oldB"],
											[7, [23, "b"]]
										]],
										[-1, 15, null, 8101916200256538, false, [
											[11, "oldC"],
											[7, [23, "c"]]
										]],
										[-1, 15, null, 7660648063301215, false, [
											[11, "oldD"],
											[7, [23, "d"]]
										]]
									]
								]
							]
						],
						[0, null, false, null, 1558771741164457, [
								[6, 47, null, 2, false, false, false, 4466389832975078, false, [
									[1, [2, "calculateJoystickValues"]]
								]]
							],
							[],
							[
								[0, null, false, null, 8207094995853903, [
										[-1, 48, null, 0, false, false, false, 7361691312687741, false, [
											[11, "touchId1"],
											[8, 5],
											[7, [0, 0]]
										]]
									],
									[
										[-1, 15, null, 4682274763956947, false, [
											[11, "tempHorzCoord"],
											[7, [6, [6, [5, [20, 10, 87, false, null],
														[20, 13, 88, false, null, [
															[23, "touchId1"]
														]]
													],
													[1, 0.4444444444444444]
												],
												[0, -1]
											]]
										]],
										[-1, 15, null, 2345270574049896, false, [
											[11, "tempVertCoord"],
											[7, [6, [5, [20, 10, 89, false, null],
													[20, 13, 90, false, null, [
														[23, "touchId1"]
													]]
												],
												[1, 0.4444444444444444]
											]]
										]]
									],
									[
										[0, null, false, null, 4578455888916453, [
												[-1, 48, null, 0, false, false, false, 4204521043736887, false, [
													[11, "joystickCurrentPanel"],
													[8, 0],
													[7, [0, 0]]
												]],
												[-1, 36, null, 0, false, false, false, 7222171571394387, false, [
													[7, [19, 49, [
														[23, "joystickShapes"],
														[0, 1]
													]]],
													[8, 1],
													[7, [2, "-"]]
												]]
											],
											[
												[6, 18, null, 4642626216438512, false, [
													[1, [2, "calcJoystickAxis"]],
													[13, [7, [19, 49, [
														[23, "joystickShapes"],
														[0, 1]
													]]]]
												]],
												[-1, 15, null, 22819261104255, false, [
													[11, "x"],
													[7, [23, "tempHorzCoord"]]
												]],
												[-1, 15, null, 2908116946874909, false, [
													[11, "y"],
													[7, [23, "tempVertCoord"]]
												]]
											]
										],
										[0, null, false, null, 6441937356240463, [
												[-1, 48, null, 0, false, false, false, 993964018524741, false, [
													[11, "joystickCurrentPanel"],
													[8, 0],
													[7, [0, 1]]
												]],
												[-1, 36, null, 0, false, false, false, 3697995301089982, false, [
													[7, [19, 35, [
														[19, 49, [
															[23, "joystickShapes"],
															[0, 3]
														]],
														[0, 1]
													]]],
													[8, 1],
													[7, [2, "-"]]
												]]
											],
											[
												[6, 18, null, 3208880378966962, false, [
													[1, [2, "calcJoystickAxis"]],
													[13, [7, [19, 35, [
														[19, 49, [
															[23, "joystickShapes"],
															[0, 3]
														]],
														[0, 1]
													]]]]
												]],
												[-1, 15, null, 3577600316799852, false, [
													[11, "a"],
													[7, [23, "tempHorzCoord"]]
												]],
												[-1, 15, null, 3982807252357474, false, [
													[11, "b"],
													[7, [23, "tempVertCoord"]]
												]]
											]
										]
									]
								],
								[0, null, false, null, 4548858377075039, [
										[-1, 48, null, 0, false, false, false, 2532115859105588, false, [
											[11, "touchId2"],
											[8, 5],
											[7, [0, 0]]
										]]
									],
									[
										[-1, 15, null, 8493698201961098, false, [
											[11, "tempHorzCoord"],
											[7, [6, [6, [5, [20, 11, 87, false, null],
														[20, 13, 88, false, null, [
															[23, "touchId2"]
														]]
													],
													[1, 0.4444444444444444]
												],
												[0, -1]
											]]
										]],
										[-1, 15, null, 282393821817588, false, [
											[11, "tempVertCoord"],
											[7, [6, [5, [20, 11, 89, false, null],
													[20, 13, 90, false, null, [
														[23, "touchId2"]
													]]
												],
												[1, 0.4444444444444444]
											]]
										]]
									],
									[
										[0, null, false, null, 4754813042662641, [
												[-1, 48, null, 0, false, false, false, 3855894830031374, false, [
													[11, "joystickCurrentPanel"],
													[8, 0],
													[7, [0, 0]]
												]],
												[-1, 36, null, 0, false, false, false, 3286542852752268, false, [
													[7, [19, 35, [
														[19, 49, [
															[23, "joystickShapes"],
															[0, 2]
														]],
														[0, 1]
													]]],
													[8, 1],
													[7, [2, "-"]]
												]]
											],
											[
												[6, 18, null, 6796179079055578, false, [
													[1, [2, "calcJoystickAxis"]],
													[13, [7, [19, 35, [
														[19, 49, [
															[23, "joystickShapes"],
															[0, 2]
														]],
														[0, 1]
													]]]]
												]],
												[-1, 15, null, 7541812908589645, false, [
													[11, "w"],
													[7, [23, "tempHorzCoord"]]
												]],
												[-1, 15, null, 888759849089105, false, [
													[11, "z"],
													[7, [23, "tempVertCoord"]]
												]]
											]
										],
										[0, null, false, null, 7353869687368677, [
												[-1, 48, null, 0, false, false, false, 146345799108657, false, [
													[11, "joystickCurrentPanel"],
													[8, 0],
													[7, [0, 1]]
												]],
												[-1, 36, null, 0, false, false, false, 3639647951854102, false, [
													[7, [19, 35, [
														[19, 49, [
															[23, "joystickShapes"],
															[0, 4]
														]],
														[0, 1]
													]]],
													[8, 1],
													[7, [2, "-"]]
												]]
											],
											[
												[6, 18, null, 7812073129338662, false, [
													[1, [2, "calcJoystickAxis"]],
													[13, [7, [19, 35, [
														[19, 49, [
															[23, "joystickShapes"],
															[0, 4]
														]],
														[0, 1]
													]]]]
												]],
												[-1, 15, null, 6631553558575509, false, [
													[11, "c"],
													[7, [23, "tempHorzCoord"]]
												]],
												[-1, 15, null, 3516865199118335, false, [
													[11, "d"],
													[7, [23, "tempVertCoord"]]
												]]
											]
										]
									]
								]
							]
						],
						[0, null, false, null, 3955580804458954, [
								[6, 47, null, 2, false, false, false, 9087309149259076, false, [
									[1, [2, "calcJoystickAxis"]]
								]]
							],
							[],
							[
								[0, null, false, null, 7466526027846731, [
										[-1, 36, null, 0, false, false, false, 9655498063858185, false, [
											[7, [20, 6, 91, false, null, [
												[0, 0]
											]]],
											[8, 0],
											[7, [2, "v"]]
										]]
									],
									[
										[-1, 15, null, 3587106198319731, false, [
											[11, "tempVertCoord"],
											[7, [18, [14, [23, "tempVertCoord"],
													[0, -100]
												],
												[0, -100],
												[18, [16, [23, "tempVertCoord"],
														[0, 100]
													],
													[0, 100],
													[23, "tempVertCoord"]
												]
											]]
										]],
										[-1, 15, null, 4423966158650427, false, [
											[11, "tempHorzCoord"],
											[7, [0, 0]]
										]]
									]
								],
								[0, null, false, null, 2390254904364893, [
										[-1, 36, null, 0, false, false, false, 9503095574436548, false, [
											[7, [20, 6, 91, false, null, [
												[0, 0]
											]]],
											[8, 0],
											[7, [2, "h"]]
										]]
									],
									[
										[-1, 15, null, 9700277854097371, false, [
											[11, "tempVertCoord"],
											[7, [0, 0]]
										]],
										[-1, 15, null, 1432128358434489, false, [
											[11, "tempHorzCoord"],
											[7, [18, [14, [23, "tempHorzCoord"],
													[0, -100]
												],
												[0, -100],
												[18, [16, [23, "tempHorzCoord"],
														[0, 100]
													],
													[0, 100],
													[23, "tempHorzCoord"]
												]
											]]
										]]
									]
								],
								[0, null, false, null, 9717869971426183, [
										[-1, 36, null, 0, false, false, false, 9896855398970168, false, [
											[7, [20, 6, 91, false, null, [
												[0, 0]
											]]],
											[8, 0],
											[7, [2, "c"]]
										]],
										[-1, 36, null, 0, false, false, false, 9432509567110806, false, [
											[7, [19, 92, [
												[4, [6, [23, "tempHorzCoord"],
														[23, "tempHorzCoord"]
													],
													[6, [23, "tempVertCoord"],
														[23, "tempVertCoord"]
													]
												]
											]]],
											[8, 4],
											[7, [0, 100]]
										]]
									],
									[
										[-1, 15, null, 2493245368559766, false, [
											[11, "tmpAngle"],
											[7, [4, [19, 93, [
													[23, "tempHorzCoord"],
													[23, "tempVertCoord"],
													[0, 0],
													[0, 0]
												]],
												[0, 180]
											]]
										]],
										[-1, 15, null, 5158417230830373, false, [
											[11, "tempHorzCoord"],
											[7, [6, [19, 94, [
													[23, "tmpAngle"]
												]],
												[0, 100]
											]]
										]],
										[-1, 15, null, 3564775634077845, false, [
											[11, "tempVertCoord"],
											[7, [6, [19, 95, [
													[23, "tmpAngle"]
												]],
												[0, 100]
											]]
										]]
									]
								],
								[0, null, false, null, 6789459369566225, [
										[-1, 36, null, 0, false, false, false, 2263951294866649, false, [
											[7, [20, 6, 91, false, null, [
												[0, 0]
											]]],
											[8, 0],
											[7, [2, "q"]]
										]]
									],
									[
										[-1, 15, null, 5554738080654058, false, [
											[11, "tempHorzCoord"],
											[7, [18, [14, [23, "tempHorzCoord"],
													[0, -100]
												],
												[0, -100],
												[18, [16, [23, "tempHorzCoord"],
														[0, 100]
													],
													[0, 100],
													[23, "tempHorzCoord"]
												]
											]]
										]],
										[-1, 15, null, 764550930555915, false, [
											[11, "tempVertCoord"],
											[7, [18, [14, [23, "tempVertCoord"],
													[0, -100]
												],
												[0, -100],
												[18, [16, [23, "tempVertCoord"],
														[0, 100]
													],
													[0, 100],
													[23, "tempVertCoord"]
												]
											]]
										]]
									]
								],
								[0, null, false, null, 7080677113124913, [
										[-1, 36, null, 0, false, false, false, 1177604545295369, false, [
											[7, [20, 6, 91, false, null, [
												[0, 0]
											]]],
											[8, 0],
											[7, [2, "t"]]
										]]
									],
									[
										[-1, 15, null, 6476569119117486, false, [
											[11, "tempHorzCoord"],
											[7, [18, [10, [16, [23, "tempVertCoord"],
														[0, -40]
													],
													[14, [23, "tempVertCoord"],
														[0, 40]
													]
												],
												[18, [10, [17, [23, "tempHorzCoord"],
															[0, -100]
														],
														[14, [23, "tempHorzCoord"],
															[0, -40]
														]
													],
													[0, -100],
													[18, [10, [15, [23, "tempHorzCoord"],
																[0, 100]
															],
															[16, [23, "tempHorzCoord"],
																[0, 40]
															]
														],
														[0, 100],
														[0, 0]
													]
												],
												[0, 0]
											]]
										]],
										[-1, 15, null, 310429058327402, false, [
											[11, "tempVertCoord"],
											[7, [0, 0]]
										]]
									]
								],
								[0, null, false, null, 2872602215099846, [
										[-1, 36, null, 0, false, false, false, 8638441020123057, false, [
											[7, [20, 6, 91, false, null, [
												[0, 0]
											]]],
											[8, 0],
											[7, [2, "l"]]
										]]
									],
									[
										[-1, 15, null, 1873969356869015, false, [
											[11, "tempHorzCoord"],
											[7, [0, 0]]
										]],
										[-1, 15, null, 797687711882314, false, [
											[11, "tempVertCoord"],
											[7, [18, [10, [16, [23, "tempHorzCoord"],
														[0, -40]
													],
													[14, [23, "tempHorzCoord"],
														[0, 40]
													]
												],
												[18, [10, [17, [23, "tempVertCoord"],
															[0, -100]
														],
														[14, [23, "tempVertCoord"],
															[0, -40]
														]
													],
													[0, -100],
													[18, [10, [15, [23, "tempVertCoord"],
																[0, 100]
															],
															[16, [23, "tempVertCoord"],
																[0, 40]
															]
														],
														[0, 100],
														[0, 0]
													]
												],
												[0, 0]
											]]
										]]
									]
								],
								[0, null, false, null, 2500203680229887, [
										[-1, 36, null, 0, false, false, false, 269150104053967, false, [
											[7, [20, 6, 91, false, null, [
												[0, 0]
											]]],
											[8, 0],
											[7, [2, "a"]]
										]]
									],
									[
										[-1, 15, null, 8137558651868449, false, [
											[11, "tempHorzCoord"],
											[7, [18, [10, [16, [23, "tempVertCoord"],
														[0, -40]
													],
													[14, [23, "tempVertCoord"],
														[0, 40]
													]
												],
												[18, [10, [17, [23, "tempHorzCoord"],
															[0, -100]
														],
														[14, [23, "tempHorzCoord"],
															[0, -40]
														]
													],
													[0, -100],
													[18, [10, [15, [23, "tempHorzCoord"],
																[0, 100]
															],
															[16, [23, "tempHorzCoord"],
																[0, 40]
															]
														],
														[0, 100],
														[0, 0]
													]
												],
												[0, 0]
											]]
										]],
										[-1, 15, null, 5937675861367609, false, [
											[11, "tempVertCoord"],
											[7, [18, [10, [16, [23, "tempHorzCoord"],
														[0, -40]
													],
													[14, [23, "tempHorzCoord"],
														[0, 40]
													]
												],
												[18, [10, [17, [23, "tempVertCoord"],
															[0, -100]
														],
														[14, [23, "tempVertCoord"],
															[0, -40]
														]
													],
													[0, -100],
													[18, [10, [15, [23, "tempVertCoord"],
																[0, 100]
															],
															[16, [23, "tempVertCoord"],
																[0, 40]
															]
														],
														[0, 100],
														[0, 0]
													]
												],
												[0, 0]
											]]
										]]
									]
								],
								[0, null, false, null, 4272434060936301, [
										[-1, 36, null, 0, false, false, false, 9370247906072583, false, [
											[7, [20, 6, 91, false, null, [
												[0, 0]
											]]],
											[8, 1],
											[7, [2, "-"]]
										]]
									],
									[
										[-1, 15, null, 167547117356053, false, [
											[11, "tempHorzCoord"],
											[7, [19, 96, [
												[23, "tempHorzCoord"]
											]]]
										]],
										[-1, 15, null, 5786679513468836, false, [
											[11, "tempVertCoord"],
											[7, [19, 96, [
												[23, "tempVertCoord"]
											]]]
										]]
									]
								]
							]
						]
					]
				],
				[1, "tempVertCoord", 0, 0, false, false, 4090562878914851, false],
				[0, null, false, null, 2438201865925009, [
						[1, 97, null, 1, false, false, false, 7926782459142222, false]
					],
					[
						[12, 29, null, 9949131624166032, false, [
							[1, [20, 1, 98, true, null]]
						]]
					],
					[
						[0, null, false, null, 8396440169332549, [
								[-1, 36, null, 0, false, false, false, 1088105242368397, false, [
									[7, [20, 12, 34, true, null, [
										[2, "/msg/name"]
									]]],
									[8, 0],
									[7, [2, "updatePictureSize"]]
								]]
							],
							[
								[-1, 15, null, 6060284163155245, false, [
									[11, "pictureWidth"],
									[7, [20, 12, 34, true, null, [
										[2, "/msg/prw"]
									]]]
								]],
								[-1, 15, null, 3117349303879451, false, [
									[11, "pictureHeight"],
									[7, [20, 12, 34, true, null, [
										[2, "/msg/prh"]
									]]]
								]],
								[6, 18, null, 3102727059718175, false, [
									[1, [2, "updatePictureSize"]],
									[13]
								]]
							]
						],
						[0, null, false, null, 4073489475963364, [
								[-1, 36, null, 0, false, false, false, 6563802938090068, false, [
									[7, [20, 12, 34, true, null, [
										[2, "/msg/name"]
									]]],
									[8, 0],
									[7, [2, "updateJoysticks"]]
								]]
							],
							[
								[-1, 15, null, 1560894653696282, false, [
									[11, "usedKeys"],
									[7, [20, 12, 34, true, null, [
										[2, "/msg/kb"]
									]]]
								]],
								[-1, 15, null, 5758495670264298, false, [
									[11, "joystickBehaviors"],
									[7, [20, 12, 34, true, null, [
										[2, "/msg/jb"]
									]]]
								]],
								[-1, 15, null, 4667596402758101, false, [
									[11, "joystickShapes"],
									[7, [20, 12, 34, true, null, [
										[2, "/msg/js"]
									]]]
								]],
								[-1, 15, null, 9606907117927992, false, [
									[11, "hideJoysticks"],
									[7, [18, [12, [20, 12, 34, true, null, [
												[2, "/msg/hj"]
											]],
											[2, "1"]
										],
										[0, 1],
										[0, 0]
									]]
								]],
								[-1, 15, null, 6947106422876336, false, [
									[11, "showDebugInfo"],
									[7, [18, [12, [20, 12, 34, true, null, [
												[2, "/msg/di"]
											]],
											[2, "1"]
										],
										[0, 1],
										[0, 0]
									]]
								]],
								[-1, 15, null, 8596369750324514, false, [
									[11, "joystickCurrentPanel"],
									[7, [18, [10, [10, [12, [23, "joystickCurrentPanel"],
													[0, 1]
												],
												[12, [19, 35, [
														[23, "joystickShapes"],
														[0, 2]
													]],
													[2, "--"]
												]
											],
											[13, [19, 49, [
													[23, "joystickShapes"],
													[0, 2]
												]],
												[2, "--"]
											]
										],
										[0, 0],
										[18, [10, [10, [12, [23, "joystickCurrentPanel"],
														[0, 0]
													],
													[12, [19, 49, [
															[23, "joystickShapes"],
															[0, 2]
														]],
														[2, "--"]
													]
												],
												[13, [19, 35, [
														[23, "joystickShapes"],
														[0, 2]
													]],
													[2, "--"]
												]
											],
											[0, 1],
											[23, "joystickCurrentPanel"]
										]
									]]
								]],
								[6, 18, null, 5838475503885928, false, [
									[1, [2, "updateJoysticks"]],
									[13]
								]]
							]
						],
						[0, null, false, null, 1216189018121421, [
								[-1, 36, null, 0, false, false, false, 3995575014260222, false, [
									[7, [20, 12, 34, true, null, [
										[2, "/msg/name"]
									]]],
									[8, 0],
									[7, [2, "connectionWasBroken"]]
								]]
							],
							[
								[3, 17, null, 1420920878078573, false, [
									[7, [10, [10, [20, 6, 26, false, null, [
												[2, "getString"],
												[2, "connection_was_broken"]
											]],
											[19, 99]
										],
										[20, 12, 34, true, null, [
											[2, "/msg/reason"]
										]]
									]]
								]]
							]
						]
					]
				],
				[1, "tempHorzCoord", 0, 0, false, false, 9613984836982555, false],
				[0, null, false, null, 2702864872055365, [
						[1, 100, null, 1, false, false, false, 6735888847434811, false]
					],
					[
						[-1, 15, null, 6923616859401223, false, [
							[11, "usedKeys"],
							[7, [2, ""]]
						]],
						[-1, 15, null, 43742754830142, false, [
							[11, "joystickShapes"],
							[7, [2, "----"]]
						]],
						[-1, 15, null, 9873250437963849, false, [
							[11, "joystickBehaviors"],
							[7, [2, "00000000"]]
						]],
						[6, 18, null, 9946709949107481, false, [
							[1, [2, "updateJoysticks"]],
							[13]
						]]
					]
				],
				[0, null, false, null, 5111163269811759, [
						[13, 101, null, 1, false, false, false, 9277245579691286, false, [
							[4, 14]
						]]
					],
					[],
					[
						[0, null, false, null, 7926233334833548, [
								[2, 102, null, 0, false, false, false, 8347201837034139, false]
							],
							[
								[2, 103, null, 8382633955949006, false]
							]
						],
						[0, null, false, null, 8380114808028167, [
								[-1, 50, null, 0, false, false, false, 6834766967333789, false]
							],
							[
								[2, 104, null, 5163316185177619, false, [
									[1, [2, "var el = document.documentElement;\nif (el && el.requestFullscreen)\n\tel.requestFullscreen();\nelse if (el && el.webkitRequestFullScreen)\n\tel.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT);\nelse if (el && el.mozRequestFullScreen)\n\tel.mozRequestFullScreen();\nelse if (el && el.msRequestFullscreen)\n\tel.msRequestFullscreen();"]]
								]]
							]
						]
					]
				],
				[0, null, false, null, 6059721778127922, [
						[6, 47, null, 2, false, false, false, 6104062439660485, false, [
							[1, [2, "sendTestMessage"]]
						]]
					],
					[],
					[
						[0, null, false, null, 3977886509027553, [
								[-1, 36, null, 0, false, false, false, 2664120772878257, false, [
									[7, [19, 105]],
									[8, 5],
									[7, [4, [23, "lastTestMessageTime"],
										[0, 1]
									]]
								]]
							],
							[
								[-1, 15, null, 4781990177346349, false, [
									[11, "testCount"],
									[7, [18, [17, [23, "testCount"],
											[0, 100]
										],
										[0, 0],
										[4, [23, "testCount"],
											[0, 1]
										]
									]]
								]],
								[-1, 15, null, 6486591019426636, false, [
									[11, "lastTestMessageTime"],
									[7, [19, 105]]
								]],
								[1, 45, null, 2784092926439971, false, [
									[1, [10, [2, "tst:"],
										[23, "testCount"]
									]]
								]]
							]
						]
					]
				],
				[0, null, false, null, 3905405988213697, [
						[13, 101, null, 1, false, false, false, 6306791799917688, false, [
							[4, 17]
						]],
						[-1, 48, null, 0, false, false, false, 8704776469902218, false, [
							[11, "touchId1"],
							[8, 2],
							[7, [0, 0]]
						]],
						[-1, 48, null, 0, false, false, false, 751864476401579, false, [
							[11, "touchId2"],
							[8, 2],
							[7, [0, 0]]
						]],
						[17, 106, null, 0, false, false, false, 335803536211796, false]
					],
					[],
					[
						[0, null, false, null, 9543808496869325, [
								[-1, 48, null, 0, false, false, false, 7107637162578779, false, [
									[11, "joystickCurrentPanel"],
									[8, 0],
									[7, [0, 0]]
								]]
							],
							[
								[-1, 15, null, 6375196636447039, false, [
									[11, "joystickCurrentPanel"],
									[7, [0, 1]]
								]],
								[6, 18, null, 3009657802622575, false, [
									[1, [2, "updateJoysticks"]],
									[13]
								]],
								[16, 107, null, 1773992956073398, false, [
									[1, [2, "joystickCurrentPanel"]],
									[7, [19, 80, [
										[23, "joystickCurrentPanel"]
									]]]
								]]
							]
						],
						[0, null, false, null, 8192205579257373, [
								[-1, 50, null, 0, false, false, false, 6524610709173782, false]
							],
							[
								[-1, 15, null, 9521943299785045, false, [
									[11, "joystickCurrentPanel"],
									[7, [0, 0]]
								]],
								[6, 18, null, 885888118541799, false, [
									[1, [2, "updateJoysticks"]],
									[13]
								]],
								[16, 107, null, 2019720830000426, false, [
									[1, [2, "joystickCurrentPanel"]],
									[7, [19, 80, [
										[23, "joystickCurrentPanel"]
									]]]
								]]
							]
						]
					]
				],
				[0, null, false, null, 1634669989071704, [
						[13, 101, null, 1, false, false, false, 5611512689813249, false, [
							[4, 15]
						]],
						[-1, 48, null, 0, false, false, false, 5153555433826852, false, [
							[11, "touchId1"],
							[8, 2],
							[7, [0, 0]]
						]],
						[-1, 48, null, 0, false, false, false, 653359799244264, false, [
							[11, "touchId2"],
							[8, 2],
							[7, [0, 0]]
						]],
						[15, 106, null, 0, false, false, false, 2636512746227173, false]
					],
					[],
					[
						[0, null, false, null, 3628935746868778, [
								[-1, 48, null, 0, false, false, false, 5139298655225265, false, [
									[11, "control"],
									[8, 0],
									[7, [2, "left-handed"]]
								]]
							],
							[
								[-1, 15, null, 7580234443560664, false, [
									[11, "control"],
									[7, [2, "right-handed"]]
								]],
								[6, 18, null, 6979313670265242, false, [
									[1, [2, "updateControls"]],
									[13]
								]],
								[16, 107, null, 4578307219602722, false, [
									[1, [2, "control"]],
									[7, [23, "control"]]
								]]
							]
						],
						[0, null, false, null, 8034558801106765, [
								[-1, 50, null, 0, false, false, false, 8588819710550418, false]
							],
							[
								[-1, 15, null, 4134867702158811, false, [
									[11, "control"],
									[7, [2, "left-handed"]]
								]],
								[6, 18, null, 6330340475923476, false, [
									[1, [2, "updateControls"]],
									[13]
								]],
								[16, 107, null, 5183457892094676, false, [
									[1, [2, "control"]],
									[7, [23, "control"]]
								]]
							]
						]
					]
				],
				[0, null, false, null, 6396808836176294, [
						[16, 108, null, 1, false, false, false, 9213111394481516, false, [
							[1, [2, "control"]]
						]]
					],
					[
						[16, 109, null, 9952506941478479, false, [
							[1, [2, "control"]]
						]]
					]
				],
				[0, null, false, null, 6295266921281767, [
						[16, 110, null, 1, false, false, false, 2395559073213498, false, [
							[1, [2, "control"]]
						]]
					],
					[
						[-1, 15, null, 7382716438368559, false, [
							[11, "control"],
							[7, [18, [12, [20, 16, 111, false, null],
									[2, "right-handed"]
								],
								[2, "right-handed"],
								[2, "left-handed"]
							]]
						]],
						[6, 18, null, 1775030752827821, false, [
							[1, [2, "updateControls"]],
							[13]
						]]
					]
				],
				[0, null, false, null, 5686153554822906, [
						[16, 108, null, 1, false, false, false, 8547196817620323, false, [
							[1, [2, "joystickCurrentPanel"]]
						]]
					],
					[
						[16, 109, null, 2049743756435353, false, [
							[1, [2, "joystickCurrentPanel"]]
						]]
					]
				],
				[0, null, false, null, 9806538329642803, [
						[16, 110, null, 1, false, false, false, 5321782043743996, false, [
							[1, [2, "joystickCurrentPanel"]]
						]]
					],
					[
						[-1, 15, null, 3844375782305168, false, [
							[11, "joystickCurrentPanel"],
							[7, [18, [10, [12, [19, 40, [
											[20, 16, 111, false, null]
										]],
										[0, 1]
									],
									[12, [19, 35, [
											[23, "joystickShapes"],
											[0, 2]
										]],
										[2, "--"]
									]
								],
								[0, 0],
								[19, 40, [
									[20, 16, 111, false, null]
								]]
							]]
						]],
						[6, 18, null, 8826854738318326, false, [
							[1, [2, "updateJoysticks"]],
							[13]
						]]
					],
					[
						[0, null, false, null, 8171818877064707, [
								[16, 112, null, 0, false, false, false, 9072896526239258, false, [
									[8, 0],
									[7, [2, "1"]]
								]],
								[-1, 36, null, 0, false, false, false, 4504868911651547, false, [
									[7, [18, [12, [19, 35, [
												[23, "joystickShapes"],
												[0, 2]
											]],
											[2, "--"]
										],
										[0, 1],
										[0, 0]
									]],
									[8, 0],
									[7, [0, 1]]
								]]
							],
							[
								[16, 107, null, 3267468894102383, false, [
									[1, [2, "joystickCurrentPanel"]],
									[7, [2, "0"]]
								]]
							]
						]
					]
				],
				[0, null, false, null, 1501307806954036, [
						[13, 101, null, 1, false, false, false, 5666166994826372, false, [
							[4, 18]
						]]
					],
					[],
					[
						[0, null, false, null, 2483009191622273, [
								[18, 60, null, 0, false, false, false, 3480511834999426, false, [
									[10, 2],
									[8, 1],
									[7, [2, ""]]
								]]
							],
							[
								[2, 113, null, 1688236531539321, false, [
									[1, [21, 18, true, null, 2]],
									[1, [2, "NewWindow"]]
								]]
							]
						]
					]
				]
			]],
			["Functions", [
				[0, null, false, null, 6458737241587084, [
						[6, 47, null, 2, false, false, false, 7155339024319891, false, [
							[1, [2, "parseBrowserURL"]]
						]]
					],
					[
						[-1, 15, null, 6180656811411567, false, [
							[11, "portStr"],
							[7, [20, 2, 114, true, null]]
						]],
						[-1, 15, null, 6451843715842954, false, [
							[11, "portStr"],
							[7, [18, [13, [20, 2, 115, true, null],
									[2, ""]
								],
								[18, [12, [19, 35, [
											[23, "portStr"],
											[19, 75, [
												[20, 2, 115, true, null]
											]]
										]],
										[20, 2, 115, true, null]
									],
									[19, 49, [
										[23, "portStr"],
										[5, [19, 75, [
												[23, "portStr"]
											]],
											[19, 75, [
												[20, 2, 115, true, null]
											]]
										]
									]],
									[23, "portStr"]
								],
								[23, "portStr"]
							]]
						]],
						[-1, 15, null, 8673091124178902, false, [
							[11, "portStr"],
							[7, [18, [13, [20, 2, 116, true, null],
									[2, ""]
								],
								[18, [12, [19, 35, [
											[23, "portStr"],
											[19, 75, [
												[20, 2, 116, true, null]
											]]
										]],
										[20, 2, 116, true, null]
									],
									[19, 49, [
										[23, "portStr"],
										[5, [19, 75, [
												[23, "portStr"]
											]],
											[19, 75, [
												[20, 2, 116, true, null]
											]]
										]
									]],
									[23, "portStr"]
								],
								[23, "portStr"]
							]]
						]],
						[-1, 15, null, 8535122169347461, false, [
							[11, "httpRoot"],
							[7, [23, "portStr"]]
						]],
						[-1, 15, null, 6684498092437571, false, [
							[11, "portStr"],
							[7, [18, [10, [12, [19, 49, [
											[23, "portStr"],
											[4, [19, 75, [
													[20, 2, 117, true, null]
												]],
												[0, 2]
											]
										]],
										[20, 2, 117, true, null]
									],
									[2, "//"]
								],
								[19, 35, [
									[23, "portStr"],
									[5, [5, [19, 75, [
												[23, "portStr"]
											]],
											[19, 75, [
												[20, 2, 117, true, null]
											]]
										],
										[0, 2]
									]
								]],
								[23, "portStr"]
							]]
						]],
						[-1, 15, null, 5410260717360893, false, [
							[11, "portStr"],
							[7, [18, [17, [19, 118, [
										[23, "portStr"],
										[2, ":"]
									]],
									[0, 0]
								],
								[19, 35, [
									[23, "portStr"],
									[5, [5, [19, 75, [
												[23, "portStr"]
											]],
											[19, 118, [
												[23, "portStr"],
												[2, ":"]
											]]
										],
										[0, 1]
									]
								]],
								[2, "80"]
							]]
						]],
						[-1, 15, null, 8736436044950856, false, [
							[11, "port"],
							[7, [18, [12, [19, 40, [
										[23, "portStr"]
									]],
									[0, 0]
								],
								[0, 80],
								[19, 40, [
									[23, "portStr"]
								]]
							]]
						]],
						[-1, 15, null, 9796730061302627, false, [
							[11, "portStr"],
							[7, [18, [12, [23, "port"],
									[0, 80]
								],
								[2, ""],
								[10, [2, ":"],
									[19, 80, [
										[23, "port"]
									]]
								]
							]]
						]]
					]
				],
				[0, null, false, null, 4172954767617174, [
						[6, 47, null, 2, false, false, false, 6285716670754196, false, [
							[1, [2, "getString"]]
						]]
					],
					[
						[6, 119, null, 3042158802184612, false, [
							[7, [18, [12, [20, 8, 120, false, null, [
										[20, 6, 91, false, null, [
											[0, 0]
										]]
									]],
									[0, 0]
								],
								[20, 7, 120, false, null, [
									[20, 6, 91, false, null, [
										[0, 0]
									]]
								]],
								[20, 8, 120, false, null, [
									[20, 6, 91, false, null, [
										[0, 0]
									]]
								]]
							]]
						]]
					]
				],
				[0, null, false, null, 5122447963822262, [
						[6, 47, null, 2, false, false, false, 4554522045904712, false, [
							[1, [2, "initStrings"]]
						]]
					],
					[
						[7, 121, null, 7785635560897549, false, [
							[1, [2, "{\"c2dictionary\":true,\"data\":{\"error_while_reading_settings\":\"Error while reading application settings.\",\"web_socket_error\":\"WebSocket error: \",\"connection_was_broken\":\"Connection was broken by the server. Reason: \",\"connecting\":\"Connecting...\"}}"]]
						]],
						[8, 122, null, 8147845266169606, false]
					],
					[
						[0, null, false, null, 8181254618261045, [
								[-1, 48, null, 0, false, false, false, 6439569847141251, false, [
									[11, "lang"],
									[8, 0],
									[7, [2, "ru"]]
								]]
							],
							[
								[8, 121, null, 5709773902911013, false, [
									[1, [2, "{\"c2dictionary\":true,\"data\":{\"error_while_reading_settings\":\"Ошибка во время загрузки настроек приложения.\",\"web_socket_error\":\"Ошибка WebSocket: \",\"connection_was_broken\":\"Соединение разорвано сервером. Причина: \",\"connecting\":\"Подключение...\"}}"]]
								]]
							]
						],
						[0, null, false, null, 8798903648614944, [
								[-1, 48, null, 0, false, false, false, 9889537079156873, false, [
									[11, "lang"],
									[8, 0],
									[7, [2, "kk"]]
								]]
							],
							[
								[8, 121, null, 5922525164825145, false, [
									[1, [2, "{\"c2dictionary\":true,\"data\":{\"error_while_reading_settings\":\"Бағдарламаның параметрлерін жүктеу кезіндегі қате.\",\"web_socket_error\":\"WebSocket қатесі: \",\"connection_was_broken\":\"Байланысу сервермен үзілді. Себебі: \",\"connecting\":\"Подключение...\"}}"]]
								]]
							]
						]
					]
				],
				[0, null, false, null, 6133080345356746, [
						[6, 47, null, 2, false, false, false, 2382658979923797, false, [
							[1, [2, "setLangByBrowserSettings"]]
						]]
					],
					[],
					[
						[0, null, false, null, 5669493280010352, [
								[-1, 36, null, 0, false, false, false, 4129088454620966, false, [
									[7, [19, 123, [
										[20, 2, 124, true, null]
									]]],
									[8, 0],
									[7, [2, "ru"]]
								]]
							],
							[
								[-1, 15, null, 8361412489752878, false, [
									[11, "lang"],
									[7, [2, "ru"]]
								]]
							]
						],
						[0, null, false, null, 1884582450464234, [
								[-1, 36, null, 0, false, false, false, 3585348402865751, false, [
									[7, [19, 123, [
										[20, 2, 124, true, null]
									]]],
									[8, 0],
									[7, [2, "kk"]]
								]]
							],
							[
								[-1, 15, null, 6364465410826865, false, [
									[11, "lang"],
									[7, [2, "kk"]]
								]]
							]
						]
					]
				]
			]]
		],
		[], "media/", false, 1080, 1080, 3, true, true, true, "1.0.0.0", true, false, 0, 0, 21, false, true, 1, true, "RoboCam", 0, []
	]
}