﻿{
	"version": 1480518047,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-2.1.1.min.js",
		"images/joystick1-sheet0.png",
		"images/buttonfullscreen-sheet0.png",
		"images/hands-sheet0.png",
		"images/hands-sheet1.png",
		"images/currentjoystick-sheet0.png",
		"images/currentjoystick-sheet1.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png",
		"client.css"
	]
}