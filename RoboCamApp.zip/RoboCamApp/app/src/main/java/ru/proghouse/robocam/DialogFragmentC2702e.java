package ru.proghouse.robocam;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;

@TargetApi(11)
@SuppressWarnings("ALL")
public class DialogFragmentC2702e extends DialogFragment {
    /* renamed from: a */
    public static DialogFragmentC2702e m56a(String str, boolean z) {
        DialogFragmentC2702e eVar = new DialogFragmentC2702e();
        Bundle bundle = new Bundle();
        bundle.putString("message", str);
        bundle.putBoolean("finish_activity", z);
        eVar.setArguments(bundle);
        return eVar;
    }

    @Override
    public Dialog onCreateDialog(Bundle bundle) {
        final Activity activity = getActivity();
        final boolean z = getArguments().getBoolean("finish_activity");
        return new AlertDialog.Builder(activity).setMessage(getArguments().getString("message")).setPositiveButton(17039370, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (z) {
                    activity.finish();
                }
            }
        }).create();
    }
}
