package ru.proghouse.robocam;

import android.hardware.Camera;
import android.os.Build;
import android.util.Size;

@SuppressWarnings("ALL")
public final class C2706h {

    /* renamed from: a */
    public int f7566a;

    /* renamed from: b */
    public int f7567b;

    public C2706h(Object obj) {
        this.f7566a = 0;
        this.f7567b = 0;
        if (Build.VERSION.SDK_INT < 23 && Camera.Size.class.isAssignableFrom(obj.getClass())) {
            this.f7566a = ((Camera.Size) obj).width;
            this.f7567b = ((Camera.Size) obj).height;
        } else if (Build.VERSION.SDK_INT >= 23 && Size.class.isAssignableFrom(obj.getClass())) {
            this.f7566a = ((Size) obj).getWidth();
            this.f7567b = ((Size) obj).getHeight();
        }
    }
}
