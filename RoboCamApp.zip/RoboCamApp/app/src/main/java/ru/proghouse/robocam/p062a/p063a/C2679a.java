package ru.proghouse.robocam.p062a.p063a;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.os.Build;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import ru.proghouse.robocam.C2709k;
import ru.proghouse.robocam.C2713n;
import ru.proghouse.robocam.R;
import ru.proghouse.robocam.p062a.AbstractC2677a;
import ru.proghouse.robocam.p062a.C2684b;
import ru.proghouse.robocam.p062a.C2695c;
import ru.proghouse.robocam.p062a.C2696d;

@SuppressWarnings("ALL")
public class C2679a extends AbstractC2677a {

    /* renamed from: a */
    static final String[] f7418a = {"x", "y", "w", "z", "a", "b", "c", "d"};

    /* renamed from: b */
    private volatile int f7419b = 1;

    /* renamed from: c */
    private volatile String f7420c = "";

    /* renamed from: d */
    private volatile String f7421d = "";

    /* renamed from: e */
    private volatile String f7422e = "";

    /* renamed from: f */
    private volatile String f7423f = "";

    /* renamed from: g */
    private volatile String f7424g = "US-ASCII";

    /* renamed from: h */
    private List<C2684b> f7425h = new ArrayList();

    /* renamed from: i */
    private volatile boolean f7426i = false;

    /* renamed from: j */
    private HashSet<Integer> f7427j = new HashSet<>();

    /* renamed from: k */
    private volatile long f7428k = 0;

    /* renamed from: l */
    private volatile boolean f7429l = true;

    /* renamed from: m */
    private volatile int f7430m = 0;

    /* renamed from: n */
    private volatile BluetoothSocket f7431n = null;

    /* renamed from: o */
    private volatile BluetoothDevice f7432o = null;

    /* renamed from: p */
    private final Object f7433p = new Object();

    /* renamed from: q */
    private final Object f7434q = new Object();

    /* renamed from: r */
    private final Object f7435r = new Object();

    /* renamed from: s */
    private boolean f7436s = false;

    /* renamed from: t */
    private Hashtable<String, Integer> f7437t = new Hashtable<>();

    /* renamed from: u */
    private HashSet<Integer> f7438u = new HashSet<>();

    /* renamed from: v */
    private HashSet<Integer> f7439v = new HashSet<>();

    /* renamed from: w */
    private int[] f7440w = new int[8];

    @SuppressWarnings("ALL")
    public class RunnableC2681a implements Runnable {
        private RunnableC2681a() {
        }

        /* renamed from: a */
        public void m275a() {
            Hashtable<String, Integer> hashtable;
            HashSet<Integer> hashSet;
            while (C2679a.this.f7430m != 2 && C2679a.this.f7431n != null) {
                synchronized (C2679a.this.f7435r) {
                    if (C2679a.this.f7437t.size() > 0) {
                        hashtable = (Hashtable) C2679a.this.f7437t.clone();
                        C2679a.this.f7437t.clear();
                    } else {
                        hashtable = null;
                    }
                    if (C2679a.this.f7436s) {
                        hashSet = (HashSet) C2679a.this.f7438u.clone();
                        C2679a.this.f7436s = false;
                    } else {
                        hashSet = null;
                    }
                }
                m274a(hashtable, hashSet);
            }
        }

        /* renamed from: a */
        public void m274a(Hashtable<String, Integer> hashtable, HashSet<Integer> hashSet) {
            if (!(C2679a.this.f7430m == 2 || C2679a.this.f7431n == null)) {
                ByteArrayOutputStream byteArrayOutputStream = null;
                if (hashtable != null) {
                    for (int i = 0; i < 4; i++) {
                        if (hashtable.containsKey(C2679a.f7418a[i * 2]) || hashtable.containsKey(C2679a.f7418a[(i * 2) + 1])) {
                            int intValue = hashtable.containsKey(C2679a.f7418a[i * 2]) ? hashtable.get(C2679a.f7418a[i * 2]).intValue() : C2679a.this.f7440w[i * 2];
                            int intValue2 = hashtable.containsKey(C2679a.f7418a[(i * 2) + 1]) ? hashtable.get(C2679a.f7418a[(i * 2) + 1]).intValue() : C2679a.this.f7440w[(i * 2) + 1];
                            if (intValue != C2679a.this.f7440w[i * 2]) {
                                if (byteArrayOutputStream == null) {
                                    byteArrayOutputStream = new ByteArrayOutputStream();
                                    C2696d.m76a((OutputStream) byteArrayOutputStream, 2);
                                } else {
                                    byteArrayOutputStream = byteArrayOutputStream;
                                }
                                C2696d.m76a((OutputStream) byteArrayOutputStream, i * 2);
                                C2696d.m78a((OutputStream) byteArrayOutputStream, (byte) intValue);
                                C2679a.this.f7440w[i * 2] = intValue;
                            } else {
                                byteArrayOutputStream = byteArrayOutputStream;
                            }
                            if (intValue2 != C2679a.this.f7440w[(i * 2) + 1]) {
                                if (byteArrayOutputStream == null) {
                                    byteArrayOutputStream = new ByteArrayOutputStream();
                                    C2696d.m76a((OutputStream) byteArrayOutputStream, 2);
                                }
                                C2696d.m76a((OutputStream) byteArrayOutputStream, (i * 2) + 1);
                                C2696d.m78a((OutputStream) byteArrayOutputStream, (byte) intValue2);
                                C2679a.this.f7440w[(i * 2) + 1] = intValue2;
                            }
                        } else {
                            byteArrayOutputStream = byteArrayOutputStream;
                        }
                    }
                }
                if (hashSet != null) {
                    HashSet hashSet2 = new HashSet();
                    HashSet hashSet3 = new HashSet();
                    synchronized (C2679a.this.f7427j) {
                        Iterator<Integer> it = hashSet.iterator();
                        while (it.hasNext()) {
                            Integer next = it.next();
                            if (C2679a.this.f7427j.contains(next) && !C2679a.this.f7439v.contains(next)) {
                                hashSet3.add(next);
                            }
                        }
                        Iterator it2 = C2679a.this.f7439v.iterator();
                        while (it2.hasNext()) {
                            Integer num = (Integer) it2.next();
                            if (!hashSet.contains(num)) {
                                hashSet2.add(num);
                            }
                        }
                        C2679a.this.f7439v.clear();
                        C2679a.this.f7439v.addAll(hashSet);
                    }
                    if (hashSet2.size() > 0 || hashSet3.size() > 0) {
                        if (byteArrayOutputStream == null) {
                            byteArrayOutputStream = new ByteArrayOutputStream();
                            C2696d.m76a((OutputStream) byteArrayOutputStream, 2);
                        }
                        Iterator it3 = hashSet3.iterator();
                        while (it3.hasNext()) {
                            C2696d.m76a((OutputStream) byteArrayOutputStream, 255);
                            C2696d.m76a((OutputStream) byteArrayOutputStream, ((Integer) it3.next()).intValue());
                        }
                        Iterator it4 = hashSet2.iterator();
                        while (it4.hasNext()) {
                            C2696d.m76a((OutputStream) byteArrayOutputStream, 254);
                            C2696d.m76a((OutputStream) byteArrayOutputStream, ((Integer) it4.next()).intValue());
                        }
                    }
                }
                if (byteArrayOutputStream != null) {
                    if (C2679a.this.m316a(byteArrayOutputStream, 1000) != null) {
                    }
                }
            }
        }

        @Override
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public void run() {
            while (true) {
                try {
                    synchronized (C2679a.this.f7434q) {
                        if (C2679a.this.f7430m != 2 && C2679a.this.f7431n != null) {
                            C2679a.this.f7434q.wait(100L);
                            if (C2679a.this.f7430m == 2 || C2679a.this.f7431n == null) {
                                break;
                            }
                        } else {
                            break;
                        }
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                m275a();
            }
        }
    }

    @SuppressWarnings("ALL")
    private class RunnableC2682b implements Runnable {

        /* renamed from: a */
        C2679a f7442a;

        /* renamed from: c */
        private int f7444c = 0;

        /* renamed from: d */
        private Object f7445d = null;

        public RunnableC2682b(C2679a aVar) {
            this.f7442a = null;
            this.f7442a = aVar;
        }

        /* renamed from: a */
        private void m273a() {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            C2696d.m76a((OutputStream) byteArrayOutputStream, 0);
            int nextInt = new Random().nextInt(254);
            C2696d.m76a((OutputStream) byteArrayOutputStream, nextInt);
            C2696d.m76a((OutputStream) byteArrayOutputStream, 1);
            byte[] a = C2679a.this.m316a(byteArrayOutputStream, 1000);
            if (a == null || a.length != 4) {
                this.f7444c = R.string.robot_error_unknown_device;
                return;
            }
            int a2 = C2696d.m71a(a, 0);
            if (a2 != 0 && a2 != 1) {
                this.f7444c = R.string.robot_error_wrong_reply;
            } else if (a2 == 1) {
                this.f7444c = R.string.robot_error_internal_error;
            } else if (C2696d.m71a(a, 1) != nextInt + 1) {
                this.f7444c = R.string.robot_error_wrong_reply;
            } else {
                int a3 = C2696d.m71a(a, 2);
                if (a3 < 1 || a3 > 1) {
                    this.f7444c = R.string.robot_error_usupported_protocol;
                    return;
                }
                int a4 = C2696d.m71a(a, 3);
                if (a4 == 0 || a4 == 1) {
                    C2679a.this.f7419b = a3;
                    C2679a.this.f7424g = a4 == 1 ? "UTF-8" : "US-ASCII";
                    return;
                }
                this.f7444c = R.string.robot_error_usupported_charset;
            }
        }

        /* renamed from: b */
        private void m272b() {
            if (C2679a.this.f7422e != null && !C2679a.this.f7422e.equals("") && C2679a.this.f7423f != null && !C2679a.this.f7423f.equals("")) {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                C2696d.m76a((OutputStream) byteArrayOutputStream, 1);
                C2696d.m65b(byteArrayOutputStream, this.f7442a.f7422e == null ? "" : this.f7442a.f7422e, C2679a.this.f7424g);
                byte[] a = C2679a.this.m316a(byteArrayOutputStream, 1000);
                if (a == null || a.length < 2) {
                    this.f7444c = R.string.robot_error_wrong_reply;
                    return;
                }
                int a2 = C2696d.m71a(a, 0);
                if (a2 != 0 && a2 != 1) {
                    this.f7444c = R.string.robot_error_wrong_reply;
                } else if (a2 == 1) {
                    this.f7444c = R.string.robot_error_internal_error;
                } else {
                    String a3 = C2696d.m69a(a, 1, a.length - 1, C2679a.this.f7424g);
                    if (a3 == null) {
                        a3 = "";
                    }
                    if (!a3.equals(C2679a.this.f7423f)) {
                        this.f7444c = R.string.robot_error_wrong_response_on_callsign;
                    }
                }
            }
        }

        @Override
        public void run() {
            boolean z = true;
            int i = 0;
            while (true) {
                try {
                    this.f7442a.f7431n = this.f7442a.f7432o.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));
                    if (C2679a.this.f7430m == 2) {
                        break;
                    }
                    try {
                        this.f7442a.f7431n.connect();
                    } catch (IOException e) {
                        this.f7442a.f7431n.close();
                        if (i >= 7) {
                            throw e;
                        }
                        z = false;
                    }
                    if (z) {
                        this.f7444c = 0;
                        m273a();
                        if (this.f7444c == 0 && C2679a.this.f7422e != null && !C2679a.this.f7422e.equals("") && C2679a.this.f7423f != null && !C2679a.this.f7423f.equals("")) {
                            m272b();
                        }
                        if (i >= 7 || this.f7444c == R.string.robot_error_unknown_device || this.f7444c == R.string.robot_error_internal_error || this.f7444c == R.string.robot_error_wrong_reply || this.f7444c == R.string.robot_error_usupported_protocol || this.f7444c == R.string.robot_error_usupported_charset || this.f7444c == R.string.robot_error_wrong_response_on_callsign || this.f7444c == 0) {
                            break;
                        }
                    }
                    Thread.sleep(3000L);
                    i++;
                } catch (Exception e2) {
                    if (C2679a.this.f7430m != 2) {
                        e2.printStackTrace();
                        this.f7442a.m324e((int) R.string.robot_connection_error);
                        this.f7442a.m279u();
                        return;
                    }
                    return;
                }
            }
            if (C2679a.this.f7430m == 2) {
                return;
            }
            if (this.f7444c == 0) {
                synchronized (C2679a.this.f7427j) {
                    C2679a.this.f7439v.clear();
                }
                C2679a.this.m287o();
                C2679a.this.m276x();
                this.f7442a.m321r();
                C2679a.this.f7430m = 3;
                C2709k.m37c();
                C2679a.this.m277w();
                return;
            }
            C2679a.this.f7430m = 0;
            if (this.f7445d == null) {
                this.f7442a.m324e(this.f7444c);
            } else {
                this.f7442a.m331a(this.f7444c, this.f7445d);
            }
            this.f7442a.m279u();
        }
    }

    @SuppressWarnings("ALL")
    public class RunnableC2683c implements Runnable {
        private RunnableC2683c() {
        }

        @Override
        public void run() {
            int i = 0;
            while (true) {
                try {
                    Thread.sleep(100L);
                    i += 100;
                    if (C2679a.this.f7430m != 2 && C2679a.this.f7431n != null) {
                        if (i >= 1000) {
                            if (!C2679a.this.m278v()) {
                                C2679a.this.mo176m();
                                return;
                            }
                            i = 0;
                        }
                    } else {
                        return;
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    return;
                }
            }
        }
    }

    public C2679a() {
        this.f7425h.add(new C2684b());
        this.f7425h.add(new C2684b());
        this.f7425h.add(new C2684b());
        this.f7425h.add(new C2684b());
        m287o();
    }

    /* renamed from: a */
    public byte[] m316a(ByteArrayOutputStream byteArrayOutputStream, int i) {
        byte[] bArr;
        int b;
        int i2 = 0;
        OutputStream outputStream = null;
        try {
            outputStream = this.f7431n.getOutputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        byte[] bArr2 = new byte[byteArrayOutputStream.size() + 2];
        C2696d.m62c(bArr2, 0, byteArrayOutputStream.size());
        System.arraycopy(byteArrayOutputStream.toByteArray(), 0, bArr2, 2, byteArrayOutputStream.size());
        synchronized (this.f7433p) {
            try {
                outputStream.write(bArr2);
            } catch (IOException e) {
                e.printStackTrace();
            }
            InputStream inputStream = null;
            try {
                inputStream = this.f7431n.getInputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }
            int i3 = 0;
            int i4 = 0;
            while (true) {
                try {
                    if (!(i3 * 20 < i && (i4 = inputStream.available()) <= 0)) break;
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    Thread.sleep(20L);
                    i3++;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            if (i4 > 0 && (b = C2696d.m68b(inputStream)) > 0) {
                bArr = new byte[b];
                int i5 = 0;
                while (true) {
                    try {
                        i2 = inputStream.read(bArr, i2, b);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    if (i2 == b) {
                        break;
                    } else if (i2 <= 0) {
                        if (i5 * 20 >= i) {
                            bArr = null;
                            break;
                        }
                        try {
                            Thread.sleep(20L);
                            i5++;
                        } catch (InterruptedException e2) {
                            e2.printStackTrace();
                        }
                    } else {
                        b -= i2;
                    }
                }
            } else {
                bArr = null;
            }
        }
        return bArr;
    }

    /* renamed from: b */
    private void m308b(int i) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        C2696d.m76a((OutputStream) byteArrayOutputStream, i);
        m316a(byteArrayOutputStream, 1000);
    }

    /* renamed from: o */
    public void m287o() {
        for (int i = 0; i < this.f7440w.length; i++) {
            this.f7440w[i] = 0;
        }
    }

    /* renamed from: p */
    private void m285p() {
        for (int i = 0; i < this.f7425h.size(); i++) {
            this.f7425h.get(i).m269a(false);
        }
    }

    /* renamed from: u */
    public void m279u() {
        if (this.f7431n != null) {
            try {
                if (this.f7430m == 3 || this.f7430m == 2) {
                    if (Build.VERSION.SDK_INT < 14) {
                        m308b(255);
                    } else if (this.f7431n.isConnected()) {
                        m308b(255);
                    }
                }
            } catch (Throwable th) {
                th.printStackTrace();
            }
            try {
                this.f7431n.close();
            } catch (Throwable th2) {
                th2.printStackTrace();
            }
        }
        this.f7431n = null;
        this.f7430m = 0;
    }

    /* renamed from: v */
    public boolean m278v() {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        C2696d.m76a((OutputStream) byteArrayOutputStream, 3);
        byte[] a = m316a(byteArrayOutputStream, 1000);
        if (a == null || a.length != 1) {
            return false;
        }
        return C2696d.m71a(a, 0) == 0;
    }

    /* renamed from: w */
    public void m277w() {
        new Thread(new RunnableC2683c()).start();
    }

    /* renamed from: x */
    public void m276x() {
        new Thread(new RunnableC2681a()).start();
    }

    @Override
    /* renamed from: a */
    public String mo225a() {
        if (this.f7432o != null) {
            return this.f7432o.getName();
        }
        return null;
    }

    /* renamed from: a */
    public void m318a(int i) {
        this.f7430m = 2;
        C2709k.m37c();
        if (this.f7431n != null) {
            m279u();
        }
        if (i == 0) {
            m320s();
        } else {
            m323f(i);
        }
    }

    @Override
    /* renamed from: a */
    public void mo224a(BluetoothDevice bluetoothDevice) {
        if (this.f7430m == 0 || this.f7430m == 2) {
            this.f7432o = bluetoothDevice;
            this.f7430m = 1;
            new Thread(new RunnableC2682b(this)).start();
        }
    }

    @Override
    /* renamed from: a */
    public void mo222a(Context context, File file, Document document) {
        if (!document.getDocumentElement().getNodeName().equals("Custom")) {
            try {
                throw new Exception(context.getString(R.string.unknown_driver_name, document.getDocumentElement().getNodeName()));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        this.f7421d = file.getName();
        this.f7428k = file.lastModified();
        this.f7420c = document.getDocumentElement().getAttribute("Name");
        this.f7422e = document.getDocumentElement().getAttribute("Callsign");
        this.f7423f = document.getDocumentElement().getAttribute("Response");
        if (C2713n.m12a(document.getDocumentElement().getAttribute("Charset"), 0) == 1) {
            this.f7424g = "UTF-8";
        } else {
            this.f7424g = "US-ASCII";
        }
        this.f7429l = C2713n.m10a(document.getDocumentElement().getAttribute("HideJoysticks"), true);
        m325a(C2713n.m10a(document.getDocumentElement().getAttribute("ShowDebugInfo"), true));
        m285p();
        NodeList elementsByTagName = document.getElementsByTagName("Joystick");
        for (int i = 0; i < elementsByTagName.getLength(); i++) {
            Element element = (Element) elementsByTagName.item(i);
            int a = C2713n.m12a(element.getAttribute("Index"), -1);
            if (a >= 0 && a < this.f7425h.size()) {
                C2684b bVar = this.f7425h.get(a);
                bVar.m269a(C2713n.m10a(element.getAttribute("Visible"), false));
                bVar.m270a(C2713n.m11a(element.getAttribute("Shape"), "c"));
                bVar.m271a(0, C2713n.m12a(element.getAttribute("Behavior0"), 0));
                bVar.m271a(1, C2713n.m12a(element.getAttribute("Behavior1"), 0));
            }
        }
        synchronized (this.f7427j) {
            this.f7426i = false;
            this.f7427j.clear();
            NodeList elementsByTagName2 = document.getElementsByTagName("KeyGroup");
            for (int i2 = 0; i2 < elementsByTagName2.getLength(); i2++) {
                Element element2 = (Element) elementsByTagName2.item(i2);
                this.f7426i = C2713n.m10a(element2.getAttribute("Active"), false);
                C2695c.m85a(element2, this.f7427j, "Key");
            }
        }
    }

    @Override
    /* renamed from: a */
    public void mo221a(HashSet<Integer> hashSet) {
        synchronized (this.f7435r) {
            this.f7438u = hashSet;
            this.f7436s = true;
        }
        synchronized (this.f7434q) {
            this.f7434q.notifyAll();
        }
    }

    @Override
    /* renamed from: a */
    public void mo220a(Hashtable<String, Integer> hashtable) {
        synchronized (this.f7435r) {
            Enumeration<String> keys = hashtable.keys();
            while (keys.hasMoreElements()) {
                String nextElement = keys.nextElement();
                this.f7437t.put(nextElement, hashtable.get(nextElement));
            }
        }
        synchronized (this.f7434q) {
            this.f7434q.notifyAll();
        }
    }

    @Override
    /* renamed from: b */
    public String mo206b() {
        Iterator<C2684b> it = null;
        String str = "";
        while (this.f7425h.iterator().hasNext()) {
            str = str + it.next().m267e();
        }
        return str;
    }

    @Override
    /* renamed from: c */
    public String mo199c() {
        Iterator<C2684b> it = null;
        String str = "";
        while (this.f7425h.iterator().hasNext()) {
            str = str + it.next().m268d();
        }
        return str;
    }

    @Override
    /* renamed from: d */
    public String mo195d() {
        HashSet hashSet = new HashSet();
        if (this.f7426i) {
            synchronized (this.f7427j) {
                hashSet.addAll(this.f7427j);
            }
        }
        String str = "";
        if (hashSet.size() <= 0) {
            return str;
        }
        char[] cArr = {'0'};
        Iterator it = hashSet.iterator();
        while (it.hasNext()) {
            String num = ((Integer) it.next()).toString();
            if (num.length() < 3) {
                num = new String(cArr, 0, 3 - num.length()) + num;
            }
            str = str + num;
        }
        return str;
    }

    @Override
    /* renamed from: e */
    public boolean mo192e() {
        return this.f7429l;
    }

    @Override
    /* renamed from: f */
    public String mo190f() {
        return "Custom";
    }

    @Override
    /* renamed from: g */
    public String mo188g() {
        return this.f7421d;
    }

    @Override
    /* renamed from: h */
    public String mo186h() {
        return this.f7420c;
    }

    @Override
    /* renamed from: i */
    public boolean mo184i() {
        return this.f7430m == 0;
    }

    @Override
    /* renamed from: j */
    public boolean mo182j() {
        return this.f7430m == 3;
    }

    @Override
    /* renamed from: k */
    public long mo180k() {
        return this.f7428k;
    }

    @Override
    /* renamed from: l */
    public boolean mo178l() {
        return true;
    }

    @Override
    /* renamed from: m */
    public void mo176m() {
        m318a(0);
    }

    @Override
    /* renamed from: n */
    public void mo174n() {
        if (this.f7431n != null) {
            try {
                if (this.f7430m == 3 || this.f7430m == 2) {
                    m308b(255);
                }
            } catch (Throwable th) {
                th.printStackTrace();
            }
        }
    }
}
