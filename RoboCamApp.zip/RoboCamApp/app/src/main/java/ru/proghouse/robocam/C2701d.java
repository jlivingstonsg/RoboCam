package ru.proghouse.robocam;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import java.util.List;

@SuppressWarnings("ALL")
public class C2701d extends ArrayAdapter {

    /* renamed from: a */
    private Activity f7551a;

    /* renamed from: b */
    private Spinner f7552b;

    /* renamed from: c */
    private int f7553c;

    /* renamed from: d */
    private int f7554d;

    /* renamed from: e */
    private List<String> f7555e;

    /* renamed from: f */
    private int f7556f;

    public C2701d(Activity activity, Spinner spinner, int i, List<String> list, int i2) {
        super(activity, i, list);
        this.f7551a = activity;
        this.f7552b = spinner;
        this.f7553c = i;
        this.f7555e = list;
        this.f7556f = i2;
    }

    /* renamed from: a */
    public Activity m59a() {
        return this.f7551a;
    }

    /* renamed from: a */
    public void m58a(int i) {
        this.f7556f = i;
    }

    /* renamed from: b */
    public List<String> m57b() {
        return this.f7555e;
    }

    @Override
    public View getDropDownView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.f7551a.getLayoutInflater().inflate(this.f7554d, viewGroup, false);
        }
        TextView textView = (TextView) view.findViewById(16908308);
        if (textView != null) {
            textView.setText(this.f7555e.get(i));
        } else {
            TextView textView2 = (TextView) view.findViewById(R.id.textView1);
            TextView textView3 = (TextView) view.findViewById(R.id.textView2);
            if (textView3 == null) {
                textView2.setText(this.f7555e.get(i));
                if (this.f7552b == null || this.f7552b.getSelectedItemPosition() != i) {
                    textView2.setBackgroundColor(-1);
                } else {
                    textView2.setBackgroundColor(-3355444);
                }
            } else {
                textView2.setText(this.f7556f);
                textView3.setText(this.f7555e.get(i));
            }
        }
        return view;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.f7551a.getLayoutInflater().inflate(this.f7553c, viewGroup, false);
        }
        TextView textView = (TextView) view.findViewById(16908308);
        if (textView != null) {
            textView.setText(this.f7555e.get(i));
        } else {
            TextView textView2 = (TextView) view.findViewById(R.id.textView1);
            TextView textView3 = (TextView) view.findViewById(R.id.textView2);
            if (textView3 == null) {
                textView2.setText(this.f7555e.get(i));
            } else {
                textView2.setText(this.f7556f);
                textView3.setText(this.f7555e.get(i));
            }
        }
        return view;
    }

    @Override
    public void setDropDownViewResource(int i) {
        this.f7554d = i;
        super.setDropDownViewResource(i);
    }
}
