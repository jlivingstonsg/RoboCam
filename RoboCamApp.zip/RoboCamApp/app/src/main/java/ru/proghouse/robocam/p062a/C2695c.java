package ru.proghouse.robocam.p062a;

import java.util.HashSet;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

@SuppressWarnings("ALL")
public class C2695c {

    /* renamed from: a */
    private boolean f7545a = false;

    /* renamed from: b */
    private String f7546b = "";

    /* renamed from: c */
    private HashSet<Integer> f7547c = new HashSet<>();

    /* renamed from: a */
    public static void m85a(Element element, HashSet<Integer> hashSet, String str) {
        NodeList elementsByTagName = element.getElementsByTagName(str);
        for (int i = 0; i < elementsByTagName.getLength(); i++) {
            Integer valueOf = Integer.valueOf(((Element) elementsByTagName.item(i)).getTextContent());
            if (valueOf.intValue() > 0 && valueOf.intValue() <= 255) {
                hashSet.add(valueOf);
            }
        }
    }

    /* renamed from: a */
    public void m84a(boolean z) {
        this.f7545a = z;
    }

    /* renamed from: b */
    public void m83b(String str) {
        this.f7546b = str;
    }

    /* renamed from: j */
    public boolean m82j() {
        return this.f7545a;
    }

    /* renamed from: k */
    public String m81k() {
        return this.f7546b;
    }

    /* renamed from: l */
    public HashSet<Integer> m80l() {
        return this.f7547c;
    }
}
