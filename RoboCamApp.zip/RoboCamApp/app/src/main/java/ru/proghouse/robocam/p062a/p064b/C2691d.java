package ru.proghouse.robocam.p062a.p064b;

@SuppressWarnings("ALL")
public class C2691d {

    /* renamed from: a */
    private int f7495a;

    /* renamed from: b */
    private int f7496b;

    /* renamed from: c */
    private int f7497c;

    /* renamed from: d */
    private int f7498d;

    /* renamed from: e */
    private float f7499e = 0.0f;

    /* renamed from: f */
    private float f7500f = 0.0f;

    /* renamed from: g */
    private boolean f7501g = false;

    public C2691d(int i, int i2, int i3, int i4) {
        this.f7495a = 0;
        this.f7496b = 0;
        this.f7497c = 126;
        this.f7498d = 0;
        this.f7495a = i;
        this.f7496b = i2;
        this.f7497c = i3;
        this.f7498d = i4;
    }

    /* renamed from: a */
    public int m146a() {
        return this.f7495a;
    }

    /* renamed from: a */
    public void m145a(float f) {
        this.f7499e = f;
        if (!this.f7501g) {
            this.f7500f = f;
            this.f7501g = true;
        }
    }

    /* renamed from: b */
    public int m144b() {
        return this.f7496b;
    }

    /* renamed from: c */
    public String m143c() {
        return new Integer(this.f7495a).toString() + ":" + new Integer(this.f7496b).toString();
    }
}
