package ru.proghouse.robocam.p062a;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.widget.Toast;
import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import ru.proghouse.robocam.C2714o;
import ru.proghouse.robocam.HttpServer;
import ru.proghouse.robocam.R;
import ru.proghouse.robocam.p062a.p063a.C2679a;
import ru.proghouse.robocam.p062a.p064b.C2687c;

@SuppressWarnings("ALL")
public abstract class AbstractC2677a {

    /* renamed from: a */
    private static List<String> f7413a = new ArrayList();

    /* renamed from: b */
    private static List<Class<? extends AbstractC2677a>> f7414b = new ArrayList();

    /* renamed from: c */
    private static volatile AbstractC2677a f7415c = new C2687c();

    /* renamed from: d */
    private AbstractC2678a f7416d = null;

    /* renamed from: e */
    private boolean f7417e = true;

    @SuppressWarnings("ALL")
    public interface AbstractC2678a {
        /* renamed from: a */
        void mo317a(int i, Object... objArr);

        /* renamed from: c */
        void mo305c(int i);

        /* renamed from: d */
        void mo302d(int i);

        /* renamed from: j */
        void mo294j();

        /* renamed from: k */
        void mo292k();
    }

    static {
        m328a("EV3", C2687c.class);
        m328a("Custom", C2679a.class);
    }

    /* renamed from: a */
    public static AbstractC2677a m330a(Context context, String str) {
        int indexOf = f7413a.indexOf(str);
        if (indexOf >= 0) {
            try {
                return (AbstractC2677a) f7414b.get(indexOf).getConstructor(new Class[0]).newInstance(new Object[0]);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            }
        }
        try {
            throw new Exception(String.format(context.getString(R.string.unknown_driver_name), str));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /* renamed from: a */
    public static void m329a(Context context, boolean z) {
        String string = context.getSharedPreferences("RoboCamSettings", 0).getString("current_robot_settings", "");
        File a = C2714o.m6a(context);
        try {
            if (string.equals("")) {
                string = "researcher.xml";
                C2687c.m223a(context);
            }
            File file = new File(a, string);
            Document parse = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(file);
            parse.getDocumentElement().normalize();
            String nodeName = parse.getDocumentElement().getNodeName();
            if ((!m322q().mo190f().equals(nodeName) || !m322q().mo188g().equals(file.getName()) || m322q().mo180k() != file.lastModified()) && z) {
                AbstractC2677a a2 = m330a(context, nodeName);
                a2.mo222a(context, file, parse);
                m326a(a2);
            }
        } catch (Throwable th) {
            Toast.makeText(context, context.getString(R.string.error_while_opening_settings_file, string, th.getMessage()), 1).show();
        }
    }

    /* renamed from: a */
    protected static void m328a(String str, Class<? extends AbstractC2677a> cls) {
        if (!f7413a.contains(str)) {
            f7413a.add(str);
            f7414b.add(cls);
        }
    }

    /* renamed from: a */
    public static void m326a(AbstractC2677a aVar) {
        if (f7415c != aVar) {
            if (f7415c != null && !f7415c.mo184i()) {
                f7415c.mo176m();
            }
            aVar.f7416d = f7415c.f7416d;
            f7415c.f7416d = null;
            f7415c = aVar;
        }
    }

    /* renamed from: q */
    public static AbstractC2677a m322q() {
        return f7415c;
    }

    /* renamed from: a */
    public abstract String mo225a();

    /* renamed from: a */
    public void m331a(int i, Object... objArr) {
        synchronized (HttpServer.f7135a) {
            if (this.f7416d != null) {
                this.f7416d.mo317a(i, objArr);
            }
        }
    }

    /* renamed from: a */
    public abstract void mo224a(BluetoothDevice bluetoothDevice);

    /* renamed from: a */
    public abstract void mo222a(Context context, File file, Document document);

    /* renamed from: a */
    public abstract void mo221a(HashSet<Integer> hashSet);

    /* renamed from: a */
    public abstract void mo220a(Hashtable<String, Integer> hashtable);

    /* renamed from: a */
    public void m327a(AbstractC2678a aVar) {
        synchronized (HttpServer.f7135a) {
            this.f7416d = aVar;
        }
    }

    /* renamed from: a */
    public void m325a(boolean z) {
        this.f7417e = z;
    }

    /* renamed from: a_ */
    public int mo207a_(int i) {
        switch (i) {
            case 0:
                return R.string.robot_is_disconnected;
            case 1:
                return R.string.robot_is_connecting;
            case 2:
                return R.string.robot_bonded_devices_not_found;
            case 3:
                return R.string.robot_is_connected_to;
            case 4:
                return R.string.robot_is_connecting_to;
            default:
                return 0;
        }
    }

    /* renamed from: b */
    public abstract String mo206b();

    /* renamed from: c */
    public abstract String mo199c();

    /* renamed from: d */
    public abstract String mo195d();

    /* renamed from: e */
    public void m324e(int i) {
        synchronized (HttpServer.f7135a) {
            if (this.f7416d != null) {
                this.f7416d.mo305c(i);
            }
        }
    }

    /* renamed from: e */
    public abstract boolean mo192e();

    /* renamed from: f */
    public abstract String mo190f();

    /* renamed from: f */
    public void m323f(int i) {
        synchronized (HttpServer.f7135a) {
            if (this.f7416d != null) {
                this.f7416d.mo302d(i);
            }
        }
    }

    /* renamed from: g */
    public abstract String mo188g();

    /* renamed from: h */
    public abstract String mo186h();

    /* renamed from: i */
    public abstract boolean mo184i();

    /* renamed from: j */
    public abstract boolean mo182j();

    /* renamed from: k */
    public abstract long mo180k();

    /* renamed from: l */
    public abstract boolean mo178l();

    /* renamed from: m */
    public abstract void mo176m();

    /* renamed from: n */
    public abstract void mo174n();

    /* renamed from: r */
    public void m321r() {
        synchronized (HttpServer.f7135a) {
            if (this.f7416d != null) {
                this.f7416d.mo294j();
            }
        }
    }

    /* renamed from: s */
    public void m320s() {
        synchronized (HttpServer.f7135a) {
            if (this.f7416d != null) {
                this.f7416d.mo292k();
            }
        }
    }

    /* renamed from: t */
    public boolean m319t() {
        return this.f7417e;
    }
}
