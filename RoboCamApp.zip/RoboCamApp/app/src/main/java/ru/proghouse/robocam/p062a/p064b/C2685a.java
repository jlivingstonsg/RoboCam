package ru.proghouse.robocam.p062a.p064b;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import ru.proghouse.robocam.p062a.C2696d;

@SuppressWarnings("ALL")
public class C2685a {

    /* renamed from: b */
    private static Object f7451b = new Object();

    /* renamed from: c */
    private static int f7452c = 0;

    /* renamed from: a */
    ByteArrayOutputStream f7453a;

    /* renamed from: d */
    private boolean f7454d = false;

    public C2685a() {
        this.f7453a = null;
        this.f7453a = new ByteArrayOutputStream();
    }

    /* renamed from: c */
    private void m255c(int i, int i2) {
        C2696d.m76a((OutputStream) this.f7453a, i & 255);
        C2696d.m76a((OutputStream) this.f7453a, ((i >> 8) & 3) | ((i2 << 2) & 252));
    }

    /* renamed from: d */
    private void m252d(int i, int i2) {
        C2696d.m76a((OutputStream) this.f7453a, i);
        C2696d.m76a((OutputStream) this.f7453a, i2);
    }

    /* renamed from: o */
    private void m230o(int i) {
        C2696d.m76a((OutputStream) this.f7453a, i);
    }

    /* renamed from: s */
    private static int m226s() {
        int i;
        synchronized (f7451b) {
            f7452c++;
            if (f7452c > 65535) {
                f7452c = 0;
            }
            i = f7452c;
        }
        return i;
    }

    /* renamed from: a */
    public int m266a() {
        return this.f7453a.size();
    }

    /* renamed from: a */
    public int m264a(int i, int i2) {
        int s = m226s();
        C2696d.m67b(this.f7453a, s);
        C2696d.m76a((OutputStream) this.f7453a, i);
        C2696d.m76a((OutputStream) this.f7453a, i2);
        return s;
    }

    /* renamed from: a */
    public int m263a(int i, int i2, int i3) {
        int s = m226s();
        C2696d.m67b(this.f7453a, s);
        C2696d.m76a((OutputStream) this.f7453a, i);
        m255c(i2, i3);
        return s;
    }

    /* renamed from: a */
    public void m265a(int i) {
        if (i <= 31) {
            m259b(i);
        } else if (i <= 255) {
            m256c(i);
        } else if (i <= 65535) {
            m253d(i);
        } else {
            m262a(i);
        }
    }

    /* renamed from: a */
    public void m262a(long j) {
        C2696d.m76a((OutputStream) this.f7453a, 227);
        C2696d.m75a(this.f7453a, j);
    }

    /* renamed from: a */
    public void m261a(String str) {
        C2696d.m76a((OutputStream) this.f7453a, (int) 132);
        C2696d.m66b(this.f7453a, str);
    }

    /* renamed from: b */
    public void m259b(int i) {
        C2696d.m76a((OutputStream) this.f7453a, i | 96);
    }

    /* renamed from: b */
    public void m258b(int i, int i2) {
        byte[] byteArray = this.f7453a.toByteArray();
        C2696d.m61d(byteArray, i, i2);
        this.f7453a.reset();
        try {
            this.f7453a.write(byteArray);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /* renamed from: b */
    public byte[] m260b() {
        byte[] bArr = new byte[this.f7453a.size() + 2];
        C2696d.m62c(bArr, 0, this.f7453a.size());
        System.arraycopy(this.f7453a.toByteArray(), 0, bArr, 2, this.f7453a.size());
        return bArr;
    }

    /* renamed from: c */
    public void m257c() {
        m230o(2);
    }

    /* renamed from: c */
    public void m256c(int i) {
        C2696d.m76a((OutputStream) this.f7453a, 225);
        C2696d.m76a((OutputStream) this.f7453a, i);
    }

    /* renamed from: d */
    public void m254d() {
        m230o(3);
    }

    /* renamed from: d */
    public void m253d(int i) {
        C2696d.m76a((OutputStream) this.f7453a, 226);
        C2696d.m67b(this.f7453a, i);
    }

    /* renamed from: e */
    public void m251e() {
        m230o(22);
    }

    /* renamed from: e */
    public void m250e(int i) {
        C2696d.m76a((OutputStream) this.f7453a, i | 64);
    }

    /* renamed from: f */
    public void m249f() {
        m230o(24);
    }

    /* renamed from: f */
    public void m248f(int i) {
        C2696d.m76a((OutputStream) this.f7453a, 193);
        C2696d.m76a((OutputStream) this.f7453a, i);
    }

    /* renamed from: g */
    public void m247g() {
        m230o(26);
    }

    /* renamed from: g */
    public void m246g(int i) {
        if (i >= 0 || i <= 31) {
            C2696d.m76a((OutputStream) this.f7453a, i);
            return;
        }
        throw new IllegalArgumentException("The value should be in the range of 0 to 31.");
    }

    /* renamed from: h */
    public void m245h() {
        m230o(48);
    }

    /* renamed from: h */
    public void m244h(int i) {
        if (i >= -128 || i <= 127) {
            C2696d.m76a((OutputStream) this.f7453a, 129);
            C2696d.m78a((OutputStream) this.f7453a, (byte) i);
            return;
        }
        throw new IllegalArgumentException("The value should be in the range of -128 to 127.");
    }

    /* renamed from: i */
    public void m243i() {
        m230o(58);
    }

    /* renamed from: i */
    public void m242i(int i) {
        if (i >= -32768 || i <= 32767) {
            C2696d.m76a((OutputStream) this.f7453a, 130);
            C2696d.m72a((OutputStream) this.f7453a, (short) i);
            return;
        }
        throw new IllegalArgumentException("The value should be in the range of -32768 to 32767.");
    }

    /* renamed from: j */
    public void m241j() {
        m230o(122);
    }

    /* renamed from: j */
    public void m240j(int i) {
        C2696d.m76a((OutputStream) this.f7453a, (int)  131);
        C2696d.m76a((OutputStream) this.f7453a, i & 255);
        C2696d.m76a((OutputStream) this.f7453a, (i >> 8) & 255);
        C2696d.m76a((OutputStream) this.f7453a, (i >> 16) & 255);
        C2696d.m76a((OutputStream) this.f7453a, (i >> 24) & 255);
    }

    /* renamed from: k */
    public void m239k() {
        m230o(163);
    }

    /* renamed from: k */
    public void m238k(int i) {
        m252d(130, i);
    }

    /* renamed from: l */
    public void m237l() {
        m230o(164);
    }

    /* renamed from: l */
    public void m236l(int i) {
        m252d(153, i);
    }

    /* renamed from: m */
    public void m235m() {
        m230o(166);
    }

    /* renamed from: m */
    public void m234m(int i) {
        m252d(129, i);
    }

    /* renamed from: n */
    public void m233n() {
        m230o(170);
    }

    /* renamed from: n */
    public void m232n(int i) {
        m252d(192, i);
    }

    /* renamed from: o */
    public void m231o() {
        m230o(174);
    }

    /* renamed from: p */
    public void m229p() {
        m230o(178);
    }

    /* renamed from: q */
    public void m228q() {
        m230o(180);
    }

    /* renamed from: r */
    public void m227r() {
        m230o(221);
    }
}
