package ru.proghouse.robocam;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import java.util.HashSet;
import ru.proghouse.robocam.p062a.p064b.C2693f;

@SuppressWarnings("ALL")
public class C2704f extends LinearLayout {

    /* renamed from: a */
    HashSet<Integer> f7560a = null;

    /* renamed from: b */
    String f7561b;

    /* renamed from: c */
    private TextView f7562c;

    /* renamed from: d */
    private TextView f7563d;

    public C2704f(Context context) {
        super(context);
    }

    @TargetApi(11)
    public C2704f(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    /* renamed from: a */
    public static C2704f m53a(Activity activity, LinearLayout linearLayout, HashSet<Integer> hashSet, int i, String str) {
        C2704f fVar = Build.VERSION.SDK_INT >= 11 ? new C2704f(new ContextThemeWrapper(activity, (int) R.style.KeyCodeControl), null, R.style.KeyCodeControl) : new C2704f(activity);
        fVar.f7560a = hashSet;
        fVar.f7561b = str;
        fVar.setPadding(0, 0, 0, 0);
        fVar.setOrientation(0);
        fVar.setWeightSum(1.0f);
        linearLayout.addView(fVar);
        LinearLayout linearLayout2 = new LinearLayout(activity);
        linearLayout2.setOrientation(1);
        linearLayout2.setLayoutParams(new LayoutParams(0, -2, 1.0f));
        fVar.addView(linearLayout2);
        fVar.f7562c = C2712m.m24a(activity, linearLayout2, i);
        fVar.f7563d = C2712m.m22a(activity, linearLayout2, C2693f.m133a(activity, fVar.f7560a));
        RelativeLayout relativeLayout = new RelativeLayout(activity);
        relativeLayout.setLayoutParams(new RelativeLayout.LayoutParams(-2, -1));
        fVar.addView(relativeLayout);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(15);
        ImageView imageView = new ImageView(activity);
        imageView.setBackgroundResource(R.drawable.overflow);
        imageView.setLayoutParams(layoutParams);
        relativeLayout.addView(imageView);
        return fVar;
    }

    /* renamed from: a */
    public void m55a(Activity activity) {
        this.f7563d.setText(C2693f.m133a(activity, this.f7560a));
    }

    /* renamed from: a */
    public void m54a(Activity activity, int i) {
        Intent intent = new Intent(activity, SelectKeyActivity.class);
        intent.putExtra("android.intent.extra.remote_intent_token", this.f7561b);
        intent.putExtra("android.intent.extra.TEXT", getTitle());
        intent.putExtra("android.intent.extra.STREAM", C2693f.m131a(this.f7560a));
        activity.startActivityForResult(intent, i);
    }

    /* renamed from: a */
    public void m52a(Activity activity, HashSet<Integer> hashSet) {
        if (hashSet == null) {
            this.f7560a = null;
        } else {
            if (this.f7560a == null) {
                this.f7560a = new HashSet<>();
            } else {
                this.f7560a.clear();
            }
            this.f7560a.addAll(hashSet);
        }
        m55a(activity);
    }

    /* renamed from: a */
    public void m51a(Activity activity, int[] iArr) {
        if (iArr == null) {
            this.f7560a = null;
        } else {
            if (this.f7560a == null) {
                this.f7560a = new HashSet<>();
            }
            C2693f.m130a(iArr, this.f7560a);
        }
        m55a(activity);
    }

    /* renamed from: b */
    public void m50b(Activity activity) {
        this.f7560a = null;
        m55a(activity);
    }

    public String getTitle() {
        return this.f7562c.getText().toString();
    }
}
