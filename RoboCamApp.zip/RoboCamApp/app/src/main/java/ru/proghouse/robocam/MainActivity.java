package ru.proghouse.robocam;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Point;
import android.graphics.SurfaceTexture;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.os.PowerManager;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Display;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
//import com.google.android.gms.ads.AbstractC0741a;
//import com.google.android.gms.ads.AdView;
//import com.google.android.gms.ads.C0759c;
//import com.google.android.gms.ads.C0777h;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import ru.proghouse.robocam.C2709k;
import ru.proghouse.robocam.p062a.AbstractC2677a;
import ru.proghouse.robocam.p062a.p064b.C2687c;

@SuppressWarnings("ALL")
public class MainActivity extends AppCompatActivity implements SurfaceHolder.Callback, AbstractC2677a.AbstractC2678a, C2709k.AbstractC2710a {

    /* renamed from: o */
    private static int f7233o = 10;

    /* renamed from: p */
    private static int f7234p = 11;

    /* renamed from: q */
    private static int f7235q = 12;

    /* renamed from: r */
    private static int f7236r = 13;

    /* renamed from: s */
    private static int f7237s = 14;

    /* renamed from: z */
    private static volatile MainActivity f7238z = null;

    /* renamed from: A */
    private static boolean f7228A = true;

    /* renamed from: N */
    private static volatile int f7229N = 0;

    /* renamed from: O */
    private static volatile String f7230O = null;

    /* renamed from: U */
    private static volatile boolean f7231U = false;

    /* renamed from: n */
    public static double f7232n = 0.0d;

    /* renamed from: t */
    private C2671a f7270t = C2671a.m379a();

    /* renamed from: u */
    private SurfaceView f7271u = null;

    /* renamed from: v */
    private View f7272v = null;

    /* renamed from: w */
    private TextureView.SurfaceTextureListener f7273w = null;

    /* renamed from: x */
    private RelativeLayout f7274x = null;

    /* renamed from: y */
    private MainActivity f7275y = null;

    /* renamed from: B */
    private TextView f7239B = null;

    /* renamed from: C */
    private ImageView f7240C = null;

    /* renamed from: D */
    private TextView f7241D = null;

    /* renamed from: E */
    private ImageView f7242E = null;

    /* renamed from: F */
    private Animation f7243F = null;

    /* renamed from: G */
    private Animation f7244G = null;

    /* renamed from: H */
    private ImageButton f7245H = null;

    /* renamed from: I */
    private ImageButton f7246I = null;

    /* renamed from: J */
    private ImageButton f7247J = null;

    /* renamed from: K */
    private BroadcastReceiver f7248K = null;

    /* renamed from: L */
    private BroadcastReceiver f7249L = null;

    /* renamed from: M */
    private ListView f7250M = null;

    /* renamed from: P */
    private volatile RunnableC2658c f7251P = null;

    /* renamed from: Q */
    private volatile RunnableC2657b f7252Q = null;

    /* renamed from: R */
    private TextView f7253R = null;

    /* renamed from: S */
    private volatile String f7254S = null;

    /* renamed from: T */
    private ImageView f7255T = null;

    /* renamed from: V */
    private WebView f7256V = null;

    /* renamed from: W */
    private String f7257W = null;

    /* renamed from: X */
    private String f7258X = "";

    /* renamed from: Y */
    private boolean f7259Y = false;

    /* renamed from: Z */
//    private AdView f7260Z = null;

    /* renamed from: aa */
    private volatile boolean f7261aa = false;

    /* renamed from: ab */
    private Thread f7262ab = null;

    /* renamed from: ac */
    private volatile boolean f7263ac = false;

    /* renamed from: ad */
    private volatile int f7264ad = 0;

    /* renamed from: ae */
    private volatile int f7265ae = 0;

    /* renamed from: af */
    private volatile int f7266af = 0;

    /* renamed from: ag */
    private boolean f7267ag = false;

    /* renamed from: ah */
    private SharedPreferences.Editor f7268ah = null;

    /* renamed from: ai */
    private String f7269ai = null;


    static int a(ru.proghouse.robocam.MainActivity a, int i) {
        a.f7264ad = i;
        return i;
    }

    static String a(ru.proghouse.robocam.MainActivity a) {
        return a.f7257W;
    }

    static String a(ru.proghouse.robocam.MainActivity a, String s0) {
        a.f7269ai = s0;
        return s0;
    }



    @SuppressWarnings("ALL")
    public class RunnableC2655a implements Runnable {

        /* renamed from: a */
        List<Locale> f7288a;

        RunnableC2655a(List<Locale> list) {
            this.f7288a = list;
        }

        @Override
        public void run() {
            boolean z;
            File[] listFiles;
            String attribute;
            Document parse = null;
            boolean z2 = true;
            if (!MainActivity.f7231U) {
                try {
                    boolean unused = MainActivity.f7231U = true;
                    File b = C2714o.m0b(MainActivity.this.f7275y);
                    File file = new File(b, "nv.xml");
                    MainActivity.this.m466a("http://www.proghouse.ru/robocam/v.xml", file);
                    DocumentBuilder newDocumentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
                    Document parse2 = newDocumentBuilder.parse(file);
                    File file2 = new File(b, "v.xml");
                    Element[] elementArr = {null};
                    String[] strArr = {null};
                    String[] strArr2 = {null};
                    if (!file2.exists()) {
                        z = true;
                    } else {
                        parse = newDocumentBuilder.parse(file2);
                        z = !parse2.getDocumentElement().getAttribute("number").equals(parse.getDocumentElement().getAttribute("number"));
                    }
                    if (z || !MainActivity.m465a(parse, this.f7288a, elementArr, strArr, strArr2)) {
                        z2 = z;
                    } else if (new File(b, "v" + strArr[0] + "-" + strArr2[0] + ".xml").exists()) {
                        z2 = false;
                    }
                    if (z2) {
                        File file3 = new File(b, parse2.getDocumentElement().getAttribute("number"));
                        file3.mkdirs();
                        if (MainActivity.m465a(parse2, this.f7288a, elementArr, strArr, strArr2)) {
                            String attribute2 = elementArr[0].getAttribute("path");
                            NodeList childNodes = elementArr[0].getChildNodes();
                            for (int i = 0; i < childNodes.getLength(); i++) {
                                if (childNodes.item(i).getNodeName().equals("file") && (attribute = ((Element) childNodes.item(i)).getAttribute("path")) != null && !attribute.isEmpty()) {
                                    File file4 = new File(file3, attribute);
                                    file4.getParentFile().mkdirs();
                                    MainActivity.this.m466a("http://www.proghouse.ru/robocam/" + (attribute2 != null ? attribute2 : "") + attribute, file4);
                                }
                            }
                        }
                        if (HttpServer.m556c() == 0) {
                            for (File file5 : b.listFiles()) {
                                if (file5.isFile() && !file5.getName().equals(file.getName())) {
                                    file5.delete();
                                } else if (file5.isDirectory() && !file5.getName().equals(file3.getName())) {
                                    C2714o.m4a(file5);
                                }
                            }
                        }
                        File file6 = new File(b, "v" + strArr[0] + "-" + strArr2[0] + ".xml");
                        file6.delete();
                        file2.delete();
                        C2714o.m3a(file, file6);
                        file.renameTo(file2);
                    }
                } catch (Throwable th) {
                    th.getMessage();
                    th.printStackTrace();
                }
                boolean unused2 = MainActivity.f7231U = false;
            }
            try {
                if (MainActivity.f7238z != null) {
                    for (int i2 = 0; i2 < 7; i2++) {
                        if (!MainActivity.f7238z.f7261aa) {
                            MainActivity.f7238z.f7274x.post(new Runnable() {
                                @Override
                                public void run() {
                                    MainActivity.f7238z.m421u();
                                }
                            });
                            Thread.sleep(1000L);
                        } else {
                            return;
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @SuppressWarnings("ALL")
    public class RunnableC2657b implements Runnable {

        /* renamed from: a */
        public volatile MainActivity f7291a;

        public RunnableC2657b(MainActivity mainActivity) {
            this.f7291a = null;
            this.f7291a = mainActivity;
        }

        @Override
        public void run() {
            try {
                Thread.sleep(1000L);
                if (this.f7291a != null) {
                    this.f7291a.m469G();
                }
            } catch (Throwable th) {
                th.printStackTrace();
            }
        }
    }

    @SuppressWarnings("ALL")
    class RunnableC2658c implements Runnable {

        /* renamed from: a */
        public volatile MainActivity f7293a;

        public RunnableC2658c(MainActivity mainActivity) {
            this.f7293a = null;
            this.f7293a = mainActivity;
        }

        @Override
        public void run() {
            try {
                Thread.sleep(10000L);
                if (this.f7293a != null && MainActivity.f7229N == 1) {
                    int unused = MainActivity.f7229N = 0;
                    this.f7293a.m469G();
                }
            } catch (Throwable th) {
                th.printStackTrace();
            }
        }
    }

    /* renamed from: A */
    private void m475A() {
        this.f7241D.setVisibility(0);
        this.f7242E.setVisibility(0);
        this.f7250M.setVisibility(4);
    }

    /* renamed from: B */
    private void m474B() {
        this.f7241D.setVisibility(4);
        this.f7242E.setVisibility(4);
        this.f7250M.setVisibility(4);
    }

    /* renamed from: C */
    public void m473C() {
        this.f7274x.post(new Runnable() {
            @Override
            public void run() {
                MainActivity.this.m471E();
            }
        });
    }

    /* renamed from: D */
    private void m472D() {
        float f;
        float f2;
        C2706h c = this.f7270t.m357c();
        if (c != null) {
            ViewGroup.LayoutParams layoutParams = Build.VERSION.SDK_INT >= 23 ? this.f7272v.getLayoutParams() : this.f7271u.getLayoutParams();
            if (getResources().getConfiguration().orientation != 2) {
                f = c.f7567b;
                f2 = c.f7566a;
            } else {
                f = c.f7566a;
                f2 = c.f7567b;
            }
            float width = this.f7274x.getWidth() / f;
            float height = this.f7274x.getHeight() / f2;
            if (width < height) {
                layoutParams.width = this.f7274x.getWidth();
                layoutParams.height = (int) (f2 * width);
            } else {
                layoutParams.width = (int) (f * height);
                layoutParams.height = this.f7274x.getHeight();
            }
            if (Build.VERSION.SDK_INT >= 23) {
                this.f7272v.setLayoutParams(layoutParams);
            } else {
                this.f7271u.setLayoutParams(layoutParams);
            }
        }
    }

    /* renamed from: E */
    public void m471E() {
        boolean z = false;
        try {
            if (Build.VERSION.SDK_INT < 23) {
                this.f7270t.m341n();
            }
            if (f7228A) {
                z = this.f7270t.m378a((Activity) this.f7275y);
            }
            boolean o = this.f7270t.m340o();
            m472D();
            if (Build.VERSION.SDK_INT < 23) {
                this.f7270t.m342m();
            }
            if (z || o) {
                HttpServer.m565a("<msg><name>updatePictureSize</name><prw>" + this.f7270t.m351f() + "</prw><prh>" + this.f7270t.m349g() + "</prh></msg>");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* renamed from: F */
    private String m470F() {
        String str;
        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService("wifi");
        try {
            Method declaredMethod = wifiManager.getClass().getDeclaredMethod("getWifiApState", new Class[0]);
            declaredMethod.setAccessible(true);
            int intValue = ((Integer) declaredMethod.invoke(wifiManager, null)).intValue();
            if (intValue < 10) {
                intValue += 10;
            }
            if (intValue == f7236r) {
                Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
                String str2 = null;
                while (true) {
                    if (!networkInterfaces.hasMoreElements()) {
                        str = str2;
                        break;
                    }
                    Enumeration<InetAddress> inetAddresses = networkInterfaces.nextElement().getInetAddresses();
                    while (true) {
                        if (!inetAddresses.hasMoreElements()) {
                            str = str2;
                            break;
                        }
                        InetAddress nextElement = inetAddresses.nextElement();
                        if (!nextElement.isLoopbackAddress() && nextElement.getAddress().length == 4) {
                            str = nextElement.getHostAddress();
                            if ("192.168.43.1".equals(str)) {
                                break;
                            }
                        }
                    }
                    if (str != null) {
                        break;
                    }
                    str2 = str;
                }
                if (str == null) {
                    Enumeration<NetworkInterface> networkInterfaces2 = NetworkInterface.getNetworkInterfaces();
                    while (true) {
                        if (!networkInterfaces2.hasMoreElements()) {
                            str = str;
                            break;
                        }
                        NetworkInterface nextElement2 = networkInterfaces2.nextElement();
                        if (nextElement2.getName().contains("ap")) {
                            Enumeration<InetAddress> inetAddresses2 = nextElement2.getInetAddresses();
                            while (inetAddresses2.hasMoreElements()) {
                                InetAddress nextElement3 = inetAddresses2.nextElement();
                                if (!nextElement3.isLoopbackAddress() && nextElement3.getAddress().length == 4) {
                                    str = nextElement3.getHostAddress();
                                    break;
                                }
                            }
                        }
                        str = str;
                        if (str != null) {
                            break;
                        }
                    }
                }
                if (str == null) {
                    str = m442i(wifiManager.getDhcpInfo().ipAddress);
                }
            } else {
                str = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            str = null;
        }
        String i = str == null ? m442i(wifiManager.getConnectionInfo().getIpAddress()) : str;
        if (i == null) {
            try {
                Enumeration<NetworkInterface> networkInterfaces3 = NetworkInterface.getNetworkInterfaces();
                while (true) {
                    if (!networkInterfaces3.hasMoreElements()) {
                        i = i;
                        break;
                    }
                    NetworkInterface nextElement4 = networkInterfaces3.nextElement();
                    if (nextElement4.getName().contains("wlan")) {
                        Enumeration<InetAddress> inetAddresses3 = nextElement4.getInetAddresses();
                        while (inetAddresses3.hasMoreElements()) {
                            InetAddress nextElement5 = inetAddresses3.nextElement();
                            if (!nextElement5.isLoopbackAddress() && nextElement5.getAddress().length == 4) {
                                i = nextElement5.getHostAddress();
                                break;
                            }
                        }
                    }
                    i = i;
                    if (i != null) {
                        break;
                    }
                }
            } catch (Exception e2) {
                e2.printStackTrace();
                i = null;
            }
        }
        if (i == null) {
            return i;
        }
        String str3 = "http://" + i;
        return HttpServer.m561b() != 80 ? str3 + ":" + Integer.toString(HttpServer.m561b()) : str3;
    }

    /* renamed from: G */
    public void m469G() {
        try {
            this.f7274x.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        MainActivity.this.f7275y.m437m();
                    } catch (Throwable th) {
                        th.printStackTrace();
                    }
                }
            });
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }

    /* renamed from: a */
    public static List<Locale> m468a(Context context) {
        ArrayList arrayList = new ArrayList();
        if (Build.VERSION.SDK_INT >= 24) {
            LocaleList locales = context.getResources().getConfiguration().getLocales();
            for (int i = 0; i < locales.size(); i++) {
                arrayList.add(locales.get(i));
            }
        } else {
            arrayList.add(context.getResources().getConfiguration().locale);
        }
        return arrayList;
    }

    /* renamed from: a */
    private void m467a(String str) {
        this.f7239B.setText(str);
        this.f7239B.setTextColor(-16777216);
        m414y();
    }

    /* renamed from: a */
    public void m466a(String str, File file) {
        DataInputStream dataInputStream = null;
        try {
            dataInputStream = new DataInputStream(new URL(str).openStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
        byte[] bArr = new byte[1024];
        FileOutputStream fileOutputStream = null;
        try {
            fileOutputStream = new FileOutputStream(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        while (true) {
            int read = 0;
            try {
                read = dataInputStream.read(bArr);
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (read > 0) {
                try {
                    fileOutputStream.write(bArr, 0, read);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                return;
            }
        }
    }

    /* renamed from: a */
    public static boolean m465a(Document document, List<Locale> list, Element[] elementArr, String[] strArr, String[] strArr2) {
        elementArr[0] = null;
        strArr2[0] = "";
        strArr[0] = "";
        NodeList childNodes = document.getDocumentElement().getChildNodes();
        for (int i = 0; i < childNodes.getLength(); i++) {
            if (childNodes.item(i).getNodeName().equals("condition")) {
                String attribute = ((Element) childNodes.item(i)).getAttribute("language");
                String attribute2 = ((Element) childNodes.item(i)).getAttribute("country");
                if (attribute == null) {
                    attribute = "";
                }
                if (attribute2 == null) {
                    attribute2 = "";
                }
                String[] split = attribute.split(",");
                String[] split2 = attribute2.split(",");
                for (Locale locale : list) {
                    if (locale.getCountry() != null && !locale.getCountry().isEmpty()) {
                        int length = split2.length;
                        int i2 = 0;
                        while (true) {
                            if (i2 >= length) {
                                break;
                            }
                            String str = split2[i2];
                            if (str.equals(locale.getCountry())) {
                                elementArr[0] = (Element) childNodes.item(i);
                                strArr[0] = str;
                                break;
                            }
                            i2++;
                        }
                    }
                    if (elementArr[0] != null) {
                        break;
                    }
                    if (locale.getLanguage() != null && !locale.getLanguage().isEmpty()) {
                        int length2 = split.length;
                        int i3 = 0;
                        while (true) {
                            if (i3 >= length2) {
                                break;
                            }
                            String str2 = split[i3];
                            if (str2.equals(locale.getLanguage())) {
                                elementArr[0] = (Element) childNodes.item(i);
                                strArr2[0] = str2;
                                break;
                            }
                            i3++;
                        }
                    }
                    if (elementArr[0] != null) {
                        break;
                    }
                }
            }
            if (elementArr[0] != null) {
                break;
            }
        }
        return elementArr[0] != null;
    }

    /* renamed from: b */
    private void m459b(String str) {
        this.f7241D.setText(str);
        this.f7241D.setTextColor(-16777216);
        m475A();
    }

    /* renamed from: c */
    private void m454c(String str) {
        this.f7241D.setText(str);
        this.f7241D.setTextColor(-65536);
        m475A();
    }

    /* renamed from: f */
    private void m448f(int i) {
        this.f7239B.setText(i);
        this.f7239B.setTextColor(-16777216);
        m414y();
    }

    /* renamed from: g */
    private void m446g(int i) {
        getString(i);
        this.f7241D.setText(i);
        this.f7241D.setTextColor(-16777216);
        m475A();
    }

    /* renamed from: h */
    private void m444h(int i) {
        this.f7241D.setText(i);
        this.f7241D.setTextColor(-65536);
        m475A();
    }

    /* renamed from: i */
    private String m442i(int i) {
        if (ByteOrder.nativeOrder().equals(ByteOrder.LITTLE_ENDIAN)) {
            i = Integer.reverseBytes(i);
        }
        try {
            return InetAddress.getByAddress(BigInteger.valueOf(i).toByteArray()).getHostAddress();
        } catch (UnknownHostException e) {
            e.printStackTrace();
            return null;
        }
    }

    /* renamed from: q */
    public SharedPreferences.Editor m429q() {
        if (this.f7268ah == null) {
            this.f7268ah = getSharedPreferences("RoboCamSettings", 0).edit();
        }
        return this.f7268ah;
    }

    /* renamed from: r */
    public void m427r() {
        if (this.f7268ah == null) {
            return;
        }
        if (Build.VERSION.SDK_INT >= 9) {
            this.f7268ah.apply();
        } else {
            this.f7268ah.commit();
        }
    }

    /* renamed from: s */
    private void m425s() {
        if (Build.VERSION.SDK_INT >= 23) {
            this.f7273w = new TextureView.SurfaceTextureListener() {
                @Override
                public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i2) {
                    if (MainActivity.this.f7270t.m362b()) {
                        MainActivity.this.f7270t.m377a(MainActivity.this.f7275y, surfaceTexture);
                    } else {
                        MainActivity.this.f7270t.m360b(MainActivity.this.f7275y, surfaceTexture);
                    }
                    MainActivity.this.f7265ae = i;
                    MainActivity.this.f7266af = i2;
                    MainActivity.this.f7274x.post(new Runnable() {
                        @Override
                        public void run() {
                            MainActivity.this.f7270t.m375a(MainActivity.this.f7275y, MainActivity.this.f7272v, MainActivity.this.f7265ae, MainActivity.this.f7266af);
                            MainActivity.this.m471E();
                        }
                    });
                }

                @Override
                public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
                    MainActivity.this.f7270t.m373a(surfaceTexture);
                    return true;
                }

                @Override
                public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i2) {
                    MainActivity.this.f7270t.m375a(MainActivity.this.f7275y, MainActivity.this.f7272v, i, i2);
                    MainActivity.this.m471E();
                }

                @Override
                public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
                }
            };
            ((TextureView) this.f7272v).setSurfaceTextureListener(this.f7273w);
        }
    }

    /* renamed from: t */
    private void m423t() {
        try {
            new Thread(new RunnableC2655a(m468a((Context) this))).start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void m421u() {
        boolean b = this.f7261aa;
        label1: {
            boolean b0 = false;
            Throwable a = null;
            if (b) {
                break label1;
            }
            this.f7261aa = true;
            label2: {
                Exception a0 = null;
                label10: {
                    label8: {
                        label9: {
                            java.io.File a1 = null;
                            java.io.File a2 = null;
                            boolean b1 = false;
                            try {
                                a1 = C2714o.m0b((android.content.Context)this);
                                a2 = new java.io.File(a1, "v.xml");
                                b1 = a2.exists();
                            } catch(Exception a3) {
                                a0 = a3;
                                break label9;
                            }
                            if (!b1) {
                                break label1;
                            }
                            org.w3c.dom.Element[] a4 = new org.w3c.dom.Element[1];
                            a4[0] = null;
                            try {
                                String s0 = null;
                                float f = 0.0f;
                                float f0 = 0.0f;
                                org.w3c.dom.Document a5 = javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(a2);
                                java.util.List a6 = ru.proghouse.robocam.MainActivity.m468a((android.content.Context)this);
                                String[] a7 = new String[1];
                                a7[0] = null;
                                String[] a8 = new String[1];
                                a8[0] = null;
                                if (!ru.proghouse.robocam.MainActivity.m465a(a5, a6, a4, a7, a8)) {
                                    b0 = true;
                                    break label2;
                                }
                                java.io.File a9 = new java.io.File(a1, a5.getDocumentElement().getAttribute("number"));
                                Object[] a10 = a4;
                                int i = 0;
                                while(true) {
                                    if (i >= ((org.w3c.dom.Element)a10[0]).getChildNodes().getLength()) {
                                        s0 = null;
                                        f = 0.0f;
                                        f0 = 0.0f;
                                        break;
                                    } else {
                                        org.w3c.dom.Node a11 = null;
                                        boolean b2 = ((org.w3c.dom.Element)a10[0]).getChildNodes().item(i).getNodeName().equals((Object)"device");
                                        label4: {
                                            label5: {
                                                if (!b2) {
                                                    break label5;
                                                }
                                                a11 = ((org.w3c.dom.Element)a10[0]).getChildNodes().item(i);
                                                String s1 = ((org.w3c.dom.Element)(Object)a11).getAttribute("target");
                                                label7: {
                                                    if (s1 == null) {
                                                        break label7;
                                                    }
                                                    if (((org.w3c.dom.Element)(Object)a11).getAttribute("target").isEmpty()) {
                                                        break label7;
                                                    }
                                                    if (!((org.w3c.dom.Element)(Object)a11).getAttribute("target").equals((Object)"server")) {
                                                        break label5;
                                                    }
                                                }
                                                String s2 = ((org.w3c.dom.Element)(Object)a11).getAttribute("screenMin");
                                                label6: {
                                                    if (s2 == null) {
                                                        break label6;
                                                    }
                                                    if (((org.w3c.dom.Element)(Object)a11).getAttribute("screenMin").isEmpty()) {
                                                        break label6;
                                                    }
                                                    if (!(f7232n >= Double.parseDouble(((org.w3c.dom.Element)(Object)a11).getAttribute("screenMin")))) {
                                                        break label5;
                                                    }
                                                }
                                                if (((org.w3c.dom.Element)(Object)a11).getAttribute("sdkMin") == null) {
                                                    break label4;
                                                }
                                                if (((org.w3c.dom.Element)(Object)a11).getAttribute("sdkMin").isEmpty()) {
                                                    break label4;
                                                }
                                                if (android.os.Build.VERSION.SDK_INT >= Integer.parseInt(((org.w3c.dom.Element)(Object)a11).getAttribute("sdkMin"))) {
                                                    break label4;
                                                }
                                            }
                                            i = i + 1;
                                            continue;
                                        }
                                        s0 = ((org.w3c.dom.Element)(Object)a11).getAttribute("path");
                                        this.f7257W = ((org.w3c.dom.Element)(Object)a11).getAttribute("url");
                                        float f1 = Float.parseFloat(((org.w3c.dom.Element)(Object)a11).getAttribute("width"));
                                        float f2 = Float.parseFloat(((org.w3c.dom.Element)(Object)a11).getAttribute("height"));
                                        f = android.util.TypedValue.applyDimension(1, f1, this.getResources().getDisplayMetrics());
                                        f0 = android.util.TypedValue.applyDimension(1, f2, this.getResources().getDisplayMetrics());
                                        this.f7258X = ((org.w3c.dom.Element)(Object)a11).getAttribute("type");
                                        break;
                                    }
                                }
                                if (s0 == null) {
                                    b0 = true;
                                    break label2;
                                }
                                if (!(f > 0.0f)) {
                                    b0 = true;
                                    break label2;
                                }
                                if (!(f0 > 0.0f)) {
                                    b0 = true;
                                    break label2;
                                }
                                boolean b3 = this.f7258X.equals((Object)"replace");
                                label3: {
                                    if (b3) {
                                        break label3;
                                    }
                                    if (!this.f7258X.equals((Object)"offline")) {
                                        b0 = true;
                                        break label2;
                                    }
                                    if (!this.f7259Y) {
                                        b0 = true;
                                        break label2;
                                    }
                                }
                                java.io.File a12 = new java.io.File(a9, s0);
                                if (!a12.exists()) {
                                    b0 = true;
                                    break label2;
                                }
                                String s3 = a12.toURI().toString();
                                this.f7256V.getSettings().setJavaScriptEnabled(true);
                                this.f7256V.loadUrl(s3);
                                android.widget.RelativeLayout.LayoutParams a13 = new android.widget.RelativeLayout.LayoutParams(Math.round(f), Math.round(f0));
                                a13.addRule(14);
                                this.f7256V.setLayoutParams((android.view.ViewGroup.LayoutParams)a13);
                                break label8;
                            } catch(Exception a14) {
                                a0 = a14;
                            }
                        }
                        b0 = true;
                        break label10;
                    }
                    try {
                        this.f7256V.setVisibility(0);
                        b0 = false;
                        break label2;
                    } catch(Exception a15) {
                        a0 = a15;
                    }
                    b0 = false;
                }
                a0.printStackTrace();
            }
            if (!b0) {
                break label1;
            }
            label0: {
                try {
//                    this.f7256V.setVisibility(8);

                } catch(Throwable a17) {
                    a = a17;
                    break label0;
                }
                break label1;
            }
            a.printStackTrace();
        }
    }



//    public void m421u() {
//        Exception e;
//        File b = null;
//        File file = null;
//        float f;
//        float f2;
//        String str = null;
//        boolean z = true;
//        if (!this.f7261aa) {
//            this.f7261aa = true;
//            try {
//                b = C2714o.m0b(this);
//                file = new File(b, "v.xml");
//            } catch (Exception e2) {
//                e = e2;
//            }
//            if (file.exists()) {
//                Element[] elementArr = {null};
//                String[] strArr = {null};
//                String[] strArr2 = {null};
//                Document parse = null;
//                try {
//                    parse = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(file);
//                } catch (IOException ioException) {
//                    ioException.printStackTrace();
//                } catch (SAXException saxException) {
//                    saxException.printStackTrace();
//                } catch (ParserConfigurationException parserConfigurationException) {
//                    parserConfigurationException.printStackTrace();
//                }
//                if (m465a(parse, m468a((Context) this), elementArr, strArr, strArr2)) {
//                    File file2 = new File(b, parse.getDocumentElement().getAttribute("number"));
//                    for (int i = 0; i < elementArr[0].getChildNodes().getLength(); i++) {
//                        if (elementArr[0].getChildNodes().item(i).getNodeName().equals("device")) {
//                            Element element = (Element) elementArr[0].getChildNodes().item(i);
//                            if ((element.getAttribute("target") == null || element.getAttribute("target").isEmpty() || element.getAttribute("target").equals("server")) && ((element.getAttribute("screenMin") == null || element.getAttribute("screenMin").isEmpty() || f7232n >= Double.parseDouble(element.getAttribute("screenMin"))) && (element.getAttribute("sdkMin") == null || element.getAttribute("sdkMin").isEmpty() || Build.VERSION.SDK_INT >= Integer.parseInt(element.getAttribute("sdkMin"))))) {
//                                str = element.getAttribute("path");
//                                this.f7257W = element.getAttribute("url");
//                                float parseFloat = Float.parseFloat(element.getAttribute("width"));
//                                float parseFloat2 = Float.parseFloat(element.getAttribute("height"));
//                                f2 = TypedValue.applyDimension(1, parseFloat, getResources().getDisplayMetrics());
//                                f = TypedValue.applyDimension(1, parseFloat2, getResources().getDisplayMetrics());
//                                this.f7258X = element.getAttribute("type");
//                                break;
//                            }
//                        }
//                    }
//                    f = 0.0f;
//                    f2 = 0.0f;
//                    if (str != null && f2 > 0.0f && f > 0.0f && (this.f7258X.equals("replace") || (this.f7258X.equals("offline") && this.f7259Y))) {
//                        File file3 = new File(file2, str);
//                        if (file3.exists()) {
//                            String uri = file3.toURI().toString();
//                            this.f7256V.getSettings().setJavaScriptEnabled(true);
//                            this.f7256V.loadUrl(uri);
//                            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(Math.round(f2), Math.round(f));
//                            layoutParams.addRule(14);
//                            this.f7256V.setLayoutParams(layoutParams);
//                            try {
//                                this.f7256V.setVisibility(0);
////                                this.f7260Z.setVisibility(8);
//                                z = false;
//                            } catch (Exception e3) {
//                                e = e3;
//                                z = false;
//                                e.printStackTrace();
//                                if (z) {
//                                }
//                            }
//                            if (z) {
//                                try {
//                                    this.f7256V.setVisibility(8);
////                                    this.f7260Z.setVisibility(0);
////                                    C0759c a = new C0759c.C0761a().m5485a();
////                                    this.f7260Z.setAdListener(new AbstractC0741a() {
////                                        @Override
////                                        /* renamed from: a */
////                                        public void mo411a() {
////                                            try {
////                                                MainActivity.this.f7256V.setVisibility(8);
////                                                MainActivity.this.f7260Z.setVisibility(0);
////                                            } catch (Throwable th) {
////                                                th.printStackTrace();
////                                            }
////                                        }
////
////                                        @Override
////                                        /* renamed from: a */
////                                        public void mo410a(int i2) {
////                                            try {
////                                                if (MainActivity.this.f7258X.equals("offline")) {
////                                                    MainActivity.this.f7259Y = true;
////                                                    MainActivity.this.f7261aa = false;
////                                                    MainActivity.this.m421u();
////                                                }
////                                            } catch (Throwable th) {
////                                                th.printStackTrace();
////                                            }
////                                        }
////
////                                        @Override
////                                        /* renamed from: b */
////                                        public void mo409b() {
////                                            try {
////                                                MainActivity.this.f7256V.setVisibility(8);
////                                                MainActivity.this.f7260Z.setVisibility(0);
////                                            } catch (Throwable th) {
////                                                th.printStackTrace();
////                                            }
////                                        }
////                                    });
////                                    this.f7260Z.mo5446a(a);
//                                    return;
//                                } catch (Throwable th) {
//                                    th.printStackTrace();
//                                    return;
//                                }
//                            } else {
//                                return;
//                            }
//                        }
//                    }
//                }
//                if (z) {
//                }
//            }
//        }
//    }

    /* renamed from: v */
    private void m419v() {
        this.f7248K = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                MainActivity.this.m417w();
            }
        };
        registerReceiver(this.f7248K, new IntentFilter("android.bluetooth.adapter.action.STATE_CHANGED"));
        this.f7249L = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                new Thread(MainActivity.this.f7252Q).start();
            }
        };
        registerReceiver(this.f7249L, new IntentFilter("android.net.wifi.WIFI_STATE_CHANGED"));
    }

    /* renamed from: w */
    public void m417w() {
        BluetoothAdapter defaultAdapter = BluetoothAdapter.getDefaultAdapter();
        if (f7229N == 1) {
            if (defaultAdapter.getState() == 10) {
                f7229N = 0;
                m437m();
            } else if (defaultAdapter.getState() == 12) {
                f7229N = 2;
                m437m();
            }
        } else if ((f7229N == 5 || f7229N == 4) && defaultAdapter.getState() == 10) {
            AbstractC2677a.m322q().mo176m();
            f7229N = 0;
            m437m();
        }
    }

    /* renamed from: x */
    private void m415x() {
        this.f7250M.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                BluetoothAdapter.getDefaultAdapter();
                if (MainActivity.f7229N == 2) {
                    AbstractC2677a q = AbstractC2677a.m322q();
                    int unused = MainActivity.f7229N = 4;
                    MainActivity.this.f7269ai = ((BluetoothDevice) MainActivity.this.f7250M.getAdapter().getItem(i)).getName();
                    MainActivity.this.m429q().putString("last_bluetooth_device", MainActivity.this.f7269ai);
                    MainActivity.this.m427r();
                    q.mo224a((BluetoothDevice) MainActivity.this.f7250M.getAdapter().getItem(i));
                    MainActivity.this.m437m();
                }
            }
        });
    }

    /* renamed from: y */
    private void m414y() {
        this.f7239B.setVisibility(0);
        this.f7240C.setVisibility(0);
    }

    /* renamed from: z */
    private void m413z() {
        this.f7239B.setVisibility(4);
        this.f7240C.setVisibility(4);
    }

    @Override
    /* renamed from: a */
    public void mo317a(int i, Object... objArr) {
        if (f7229N == 4) {
            f7229N = 6;
            f7230O = getString(i, objArr);
            m469G();
        }
    }

    @Override
    /* renamed from: c */
    public void mo305c(int i) {
        if (f7229N == 4) {
            f7229N = 6;
            f7230O = getString(i);
            m469G();
        }
    }

    @Override
    /* renamed from: d */
    public void mo302d(int i) {
        f7229N = 6;
        f7230O = getString(i);
        m469G();
    }

    @Override
    /* renamed from: j */
    public void mo294j() {
        if (f7229N == 4) {
            f7229N = 5;
            m469G();
        }
    }

    @Override
    /* renamed from: k */
    public void mo292k() {
        f7229N = 0;
        f7230O = null;
        m469G();
    }

    @Override
    /* renamed from: l */
    public void mo36l() {
        m469G();
    }

    /* renamed from: m */
    public void m437m() {
        try {
            if (!this.f7267ag) {
                switch (HttpServer.m556c()) {
                    case 0:
                        m448f(R.string.server_is_off);
                        this.f7245H.clearAnimation();
                        this.f7245H.setBackgroundResource(R.drawable.start_server_bg);
                        break;
                    case 1:
                        String F = m470F();
                        if (F == null && ((WifiManager) getApplicationContext().getSystemService("wifi")).getWifiState() == 3) {
                            new Thread(this.f7252Q).start();
                        }
                        m467a(getString(R.string.server_is_working) + (F == null ? "" : ":\r\n" + F));
                        this.f7245H.clearAnimation();
                        this.f7245H.setBackgroundResource(R.drawable.server_started_bg);
                        break;
                    case 2:
                        m448f(R.string.server_is_initializing);
                        break;
                    case 3:
                        m448f(R.string.server_is_stopping);
                        break;
                }
            } else {
                m448f(R.string.go_to_the_controllers);
            }
            AbstractC2677a q = AbstractC2677a.m322q();
            if (q.mo184i() && f7229N == 5) {
                f7229N = 0;
            }
            switch (f7229N) {
                case 0:
                    this.f7246I.clearAnimation();
                    this.f7246I.setBackgroundResource(R.drawable.connect_robot);
                    m459b(getString(q.mo207a_(0)) + ("".equals(q.mo186h()) ? "" : ":\r\n" + q.mo186h()));
                    return;
                case 1:
                    this.f7246I.startAnimation(this.f7244G);
                    m446g(q.mo207a_(1));
                    return;
                case 2:
                    this.f7246I.startAnimation(this.f7244G);
                    m474B();
                    ArrayList arrayList = new ArrayList(BluetoothAdapter.getDefaultAdapter().getBondedDevices());
                    if (arrayList.size() > 0) {
                        Collections.sort(arrayList, new Comparator<BluetoothDevice>() {
                            /* renamed from: a */
                            public int compare(BluetoothDevice bluetoothDevice, BluetoothDevice bluetoothDevice2) {
                                if (bluetoothDevice.getName().equals(MainActivity.this.f7269ai) && bluetoothDevice2.getName().equals(MainActivity.this.f7269ai)) {
                                    return 0;
                                }
                                if (bluetoothDevice.getName().equals(MainActivity.this.f7269ai)) {
                                    return -1;
                                }
                                if (bluetoothDevice2.getName().equals(MainActivity.this.f7269ai)) {
                                    return 1;
                                }
                                return bluetoothDevice.getName().compareTo(bluetoothDevice2.getName());
                            }
                        });
                        this.f7250M.setAdapter((ListAdapter) new ArrayAdapter<BluetoothDevice>(this, 17367043, arrayList) {
                            @Override
                            public View getView(int i, View view, ViewGroup viewGroup) {
                                View view2 = super.getView(i, view, viewGroup);
                                ((TextView) view2.findViewById(16908308)).setText(getItem(i).getName());
                                return view2;
                            }
                        });
                        this.f7242E.setVisibility(0);
                        this.f7250M.setVisibility(0);
                        return;
                    }
                    f7229N = 3;
                    m437m();
                    return;
                case 3:
                    this.f7246I.clearAnimation();
                    m444h(q.mo207a_(2));
                    return;
                case 4:
                    this.f7246I.startAnimation(this.f7244G);
                    m459b(String.format(getString(q.mo207a_(4)), q.mo225a()) + ("".equals(q.mo186h()) ? "" : ":\r\n" + q.mo186h()));
                    return;
                case 5:
                    this.f7246I.clearAnimation();
                    this.f7246I.setBackgroundResource(R.drawable.robot_connected_bg);
                    m459b(String.format(getString(q.mo207a_(3)), q.mo225a()) + ("".equals(q.mo186h()) ? "" : ":\r\n" + q.mo186h()));
                    return;
                case 6:
                    this.f7246I.clearAnimation();
                    this.f7246I.setBackgroundResource(R.drawable.connect_robot);
                    m454c(f7230O);
                    return;
                default:
                    return;
            }
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int i, int i2, Intent intent) {
    }

    @Override
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        m473C();
    }

    public void onConnectToRobot(View view) {
        try {
            if (f7229N == 0 || f7229N == 3 || f7229N == 6) {
                if (AbstractC2677a.m322q().mo178l()) {
                    if (BluetoothAdapter.getDefaultAdapter() == null) {
                        m454c(getString(R.string.bluetooth_is_not_supported));
                    } else if (!BluetoothAdapter.getDefaultAdapter().isEnabled()) {
                        f7230O = null;
                        f7229N = 1;
                        m437m();
                        startActivityForResult(new Intent("android.bluetooth.adapter.action.REQUEST_ENABLE"), 1);
                        this.f7251P = new RunnableC2658c(this);
                        new Thread(this.f7251P).start();
                    } else {
                        f7230O = null;
                        f7229N = 2;
                        m437m();
                    }
                }
            } else if (f7229N == 2) {
                f7229N = 0;
                m437m();
            } else if (f7229N == 4 || f7229N == 5) {
                f7229N = 0;
                AbstractC2677a.m322q().mo176m();
                m437m();
            }
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }

    @Override
    protected void onCreate(android.os.Bundle a) {
        super.onCreate(a);
        try {
            this.setContentView(R.layout.activity_main);
            getSupportActionBar().show();
            f7238z = this;
            this.f7275y = this;
            android.content.SharedPreferences a0 = this.getSharedPreferences("RoboCamSettings", 0);
            if (a == null) {
                this.f7269ai = a0.getString("last_bluetooth_device", (String)null);
            } else {
                this.f7269ai = a.getString("last_bluetooth_device");
            }
            this.f7267ag = a0.getBoolean("use_local_controls", false);
            android.view.Display a1 = this.getWindowManager().getDefaultDisplay();
            android.util.DisplayMetrics a2 = new android.util.DisplayMetrics();
            a1.getMetrics(a2);
            int i = a2.widthPixels;
            int i0 = a2.heightPixels;
            int i1 = android.os.Build.VERSION.SDK_INT;
            label2: {
                Exception a3 = null;
                if (i1 < 14) {
                    break label2;
                }
                if (android.os.Build.VERSION.SDK_INT >= 17) {
                    break label2;
                }
                try {
                    int i2 = ((Integer)android.view.Display.class.getMethod("getRawWidth", new Class[0]).invoke((Object)a1, new Object[0])).intValue();
                    i = i2;
                    Integer a4 = (Integer)android.view.Display.class.getMethod("getRawHeight", new Class[0]).invoke((Object)a1, new Object[0]);
                    i = i2;
                    i0 = a4.intValue();
                    i = i2;
                    break label2;
                } catch(Exception a5) {
                    a3 = a5;
                }
                a3.printStackTrace();
            }
            int i3 = android.os.Build.VERSION.SDK_INT;
            label1: {
                android.graphics.Point a6 = null;
                label0: {
                    {
                        Exception a7 = null;
                        if (i3 < 17) {
                            break label1;
                        }
                        try {
                            a6 = new android.graphics.Point();
                            Class[] a8 = new Class[1];
                            a8[0] = android.graphics.Point.class;
                            java.lang.reflect.Method a9 = android.view.Display.class.getMethod("getRealSize", a8);
                            Object[] a10 = new Object[1];
                            a10[0] = a6;
                            a9.invoke((Object)a1, a10);
                            i = a6.x;
                            break label0;
                        } catch(Exception a11) {
                            a7 = a11;
                        }
                        a7.printStackTrace();
                    }
                    break label1;
                }
                i0 = a6.y;
            }
            f7232n = Math.min((double)i / (double)a2.density, (double)i0 / (double)a2.density);
            this.f7256V = (android.webkit.WebView)this.findViewById(R.id.banner);
            this.f7256V.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case 1:
                            if (MainActivity.this.f7257W == null || MainActivity.this.f7257W.isEmpty()) {
                                return false;
                            }
                            MainActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(MainActivity.this.f7257W)));
                            return false;
                        default:
                            return false;
                    }
                }
            });
//            com.google.android.gms.ads.h.a(this.getApplicationContext(), "ca-app-pub-7800876624909705~9648407673");
//            this.Z = (com.google.android.gms.ads.AdView)this.findViewById(2131493072);
            this.f7274x = (android.widget.RelativeLayout)this.findViewById(R.id.parentLayout);
            f7271u = (android.view.SurfaceView)this.findViewById(R.id.surfaceView);
            if (android.os.Build.VERSION.SDK_INT < 23) {
                f7271u.getHolder().addCallback((android.view.SurfaceHolder.Callback)(Object)this);
                f7271u.getHolder().setType(3);
                m472D();
                f7271u.setVisibility((this.f7267ag) ? 8 : 0);
            } else {
                this.f7272v = new android.view.TextureView((android.content.Context)this);
                android.widget.RelativeLayout.LayoutParams a12 = new android.widget.RelativeLayout.LayoutParams(-1, -1);
                a12.addRule(14);
                a12.addRule(15);
                this.f7274x.addView(this.f7272v, 0, (android.view.ViewGroup.LayoutParams)a12);
                f7271u.setVisibility(8);
                m425s();
                this.f7272v.setVisibility((this.f7267ag) ? 8 : 0);
            }
            this.f7264ad = getWindowManager().getDefaultDisplay().getRotation();
            this.f7262ab = new Thread(new Runnable() {
                @Override
                public void run() {
                    while (!MainActivity.this.f7275y.f7263ac) {
                        try {
                            Thread.sleep(1000L);
                            if (MainActivity.this.f7264ad != MainActivity.this.getWindowManager().getDefaultDisplay().getRotation()) {
                                MainActivity.this.m473C();
                                MainActivity.this.f7264ad = MainActivity.this.getWindowManager().getDefaultDisplay().getRotation();
                            }
                        } catch (InterruptedException e3) {
                            e3.printStackTrace();
                        }
                    }
                }
            });
            this.f7239B = (TextView) findViewById(R.id.serverMessage);
            this.f7240C = (ImageView) findViewById(R.id.serverMessageConnector);
            this.f7241D = (TextView) findViewById(R.id.robotMessage);
            this.f7242E = (ImageView) findViewById(R.id.robotMessageConnector);
            this.f7253R = (TextView) findViewById(R.id.testMessage);
            this.f7243F = new AlphaAnimation(1.0f, 0.0f);
            this.f7243F.setDuration(200L);
            this.f7243F.setInterpolator(new LinearInterpolator());
            this.f7243F.setRepeatCount(-1);
            this.f7243F.setRepeatMode(2);
            this.f7244G = new AlphaAnimation(1.0f, 0.0f);
            this.f7244G.setDuration(200L);
            this.f7244G.setInterpolator(new LinearInterpolator());
            this.f7244G.setRepeatCount(-1);
            this.f7244G.setRepeatMode(2);
            this.f7245H = (ImageButton) findViewById(R.id.btnServer);
            this.f7246I = (ImageButton) findViewById(R.id.btnRobot);
            this.f7247J = (ImageButton) findViewById(R.id.btnLocalControls);
            this.f7255T = (ImageView) findViewById(R.id.imageViewBackground);
            this.f7255T.setVisibility(!this.f7267ag ? 0 : 8);
            this.f7250M = (ListView) findViewById(R.id.robotListView);
            if (this.f7267ag) {
                this.f7245H.setVisibility(8);
                this.f7247J.setVisibility(0);
            }
            m419v();
            m413z();
            m474B();
            m415x();
            this.f7252Q = new RunnableC2657b(this);
            C2687c.m223a((Context) this);
            this.f7256V.setVisibility(8);
            m423t();
            this.f7262ab.start();
        } catch(Throwable a14) {
            a14.printStackTrace();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        this.f7263ac = true;
    }

    public void onLocalControlsButtonClick(View view) {
        startActivity(new Intent(this, LocalControllersActivity.class));
    }

    @Override
    protected void onPause() {
        C2709k.m38b(this);
        AbstractC2677a.m322q().m327a((AbstractC2677a.AbstractC2678a) null);
        PowerManager powerManager = (PowerManager) getSystemService("power");
        if (Build.VERSION.SDK_INT >= 20) {
            f7228A = powerManager.isInteractive();
        } else {
            f7228A = powerManager.isScreenOn();
        }
        super.onPause();
    }

    @Override
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != 1) {
            super.onRequestPermissionsResult(i, strArr, iArr);
        } else if (iArr.length != 1 || iArr[0] != 0) {
            C2714o.m8a((Activity) this, (int) R.string.request_camera_permission, false);
        } else if (this.f7270t.m362b()) {
        } else {
            if (this.f7270t.m345j()) {
                C2714o.m8a((Activity) this, (int) R.string.cannot_init_camera, false);
                return;
            }
            this.f7270t.m374a((Activity) this, true);
            if (Build.VERSION.SDK_INT >= 23) {
                this.f7270t.m375a(this.f7275y, this.f7272v, this.f7272v.getWidth(), this.f7272v.getHeight());
            }
        }
    }

    @Override
    protected void onRestoreInstanceState(Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        this.f7269ai = bundle.getString("last_bluetooth_device");
    }

    @Override
    protected void onResume() {
        this.f7267ag = this.getSharedPreferences("RoboCamSettings", 0).getBoolean("use_local_controls", false);
        this.f7245H.setVisibility((f7267ag) ? 8 : 0);
        this.f7247J.setVisibility((f7267ag) ? 0 : 8);
        this.f7255T.setVisibility((f7267ag) ? 0 : 8);
        ru.proghouse.robocam.HttpServer.m566a((android.content.Context)this, false);
        if (f7267ag && ru.proghouse.robocam.HttpServer.m556c() != 0) {
            ru.proghouse.robocam.HttpServer.m560b((android.content.Context)this);
        }
        if (android.os.Build.VERSION.SDK_INT < 23) {
            this.f7271u.setVisibility((f7267ag) ? 8 : 0);
        } else {
            this.f7272v.setVisibility((f7267ag) ? 8 : 0);
        }
        C2709k.m40a(this);
        AbstractC2677a.m322q().m327a(this);
        m437m();
        f7228A = true;
        super.onResume();
        AbstractC2677a.m329a((Context) this, true);
        m469G();
        m473C();
    }

    @Override
    protected void onSaveInstanceState(Bundle bundle) {
        bundle.putString("last_bluetooth_device", this.f7269ai);
        super.onSaveInstanceState(bundle);
    }

    public void onSettingsButtonClick(View view) {
        startActivity(new Intent(this, GlobalSettingsActivity.class));
    }

    public void onStartButtonClick(View view) {
        try {
            if (HttpServer.m556c() == 0) {
                HttpServer.m567a(this);
                this.f7245H.startAnimation(this.f7243F);
            } else if (HttpServer.m556c() == 1) {
                HttpServer.m566a((Context) this, true);
                HttpServer.m560b(this);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onStop() {
        if (f7229N == 1) {
            f7229N = 0;
        }
        super.onStop();
    }

    @Override
    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
        try {
            m473C();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        try {
            if (this.f7270t.m362b()) {
                this.f7270t.m376a(this, surfaceHolder);
            } else {
                this.f7270t.m359b(this, surfaceHolder);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        try {
            this.f7270t.m372a(surfaceHolder);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
