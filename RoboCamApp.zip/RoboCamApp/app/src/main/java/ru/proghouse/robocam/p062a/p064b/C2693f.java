package ru.proghouse.robocam.p062a.p064b;

import android.app.Activity;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import ru.proghouse.robocam.C2705g;
import ru.proghouse.robocam.R;
import ru.proghouse.robocam.p062a.C2695c;

@SuppressWarnings("ALL")
public class C2693f extends C2695c implements AbstractC2686b {

    /* renamed from: y */
    private static List<C2705g> f7510y = null;

    /* renamed from: z */
    private static HashSet<Integer> f7511z = null;

    /* renamed from: c */
    private int f7514c = 0;

    /* renamed from: d */
    private int f7515d = 0;

    /* renamed from: e */
    private int f7516e = 0;

    /* renamed from: f */
    private int f7517f = 0;

    /* renamed from: g */
    private int f7518g = 0;

    /* renamed from: h */
    private int f7519h = 0;

    /* renamed from: i */
    private int f7520i = 100;

    /* renamed from: j */
    private int f7521j = 100;

    /* renamed from: k */
    private long f7522k = System.currentTimeMillis();

    /* renamed from: l */
    private long f7523l = System.currentTimeMillis();

    /* renamed from: m */
    private String f7524m = "";

    /* renamed from: n */
    private boolean f7525n = true;

    /* renamed from: o */
    private HashSet<Integer> f7526o = null;

    /* renamed from: p */
    private int f7527p = 0;

    /* renamed from: q */
    private HashSet<Integer> f7528q = new HashSet<>();

    /* renamed from: r */
    private HashSet<Integer> f7529r = new HashSet<>();

    /* renamed from: s */
    private HashSet<Integer> f7530s = new HashSet<>();

    /* renamed from: t */
    private HashSet<Integer> f7531t = new HashSet<>();

    /* renamed from: u */
    private List<C2694g> f7532u = new ArrayList();

    /* renamed from: v */
    private List<C2694g> f7533v = new ArrayList();

    /* renamed from: w */
    private int f7534w = 0;

    /* renamed from: x */
    private int f7535x = 0;

    /* renamed from: a */
    HashSet<Integer> f7512a = new HashSet<>();

    /* renamed from: b */
    int f7513b = 0;

    /* renamed from: a */
    public static String m133a(Activity activity, HashSet<Integer> hashSet) {
        String str = "";
        if (hashSet != null) {
            for (C2705g gVar : m137a()) {
                str = hashSet.contains(Integer.valueOf(gVar.m49a())) ? str.isEmpty() ? str + gVar.m48b() : str + ", " + gVar.m48b() : str;
            }
        }
        return str.isEmpty() ? activity.getString(R.string.nothing_selected) : str;
    }

    /* renamed from: a */
    public static List<C2705g> m137a() {
        if (f7510y == null) {
            f7510y = new ArrayList();
            m127b(48, 57);
            m127b(65, 90);
            f7510y.addAll(Arrays.asList(new C2705g(192, "(`)"), new C2705g(189, "(-)"), new C2705g(219, "([)"), new C2705g(221, "(])"), new C2705g(220, "(\\)"), new C2705g(186, "(;)"), new C2705g(222, "(')"), new C2705g(188, "(,)"), new C2705g(190, "(.)"), new C2705g(191, "(/)"), new C2705g(27, "Esc"), new C2705g(113, "F2"), new C2705g(115, "F4"), new C2705g(118, "F7"), new C2705g(119, "F8"), new C2705g(120, "F9"), new C2705g(121, "F10"), new C2705g(33, "Page Up"), new C2705g(34, "Page Down"), new C2705g(36, "Home"), new C2705g(35, "End"), new C2705g(45, "Ins"), new C2705g(46, "Del"), new C2705g(8, "Backspace"), new C2705g(9, "Tab"), new C2705g(20, "Caps Lock"), new C2705g(13, "Enter"), new C2705g(16, "Shift"), new C2705g(17, "Ctrl"), new C2705g(18, "Alt"), new C2705g(32, "Space"), new C2705g(37, "Left"), new C2705g(38, "Up"), new C2705g(39, "Right"), new C2705g(40, "Down"), new C2705g(144, "Num Lock"), new C2705g(96, "0 (Numpad)"), new C2705g(97, "1 (Numpad)"), new C2705g(98, "2 (Numpad)"), new C2705g(99, "3 (Numpad)"), new C2705g(100, "4 (Numpad)"), new C2705g(R.styleable.AppCompatTheme_autoCompleteTextViewStyle, "5 (Numpad)"), new C2705g(R.styleable.AppCompatTheme_buttonStyle, "6 (Numpad)"), new C2705g(R.styleable.AppCompatTheme_buttonStyleSmall, "7 (Numpad)"), new C2705g(R.styleable.AppCompatTheme_checkboxStyle, "8 (Numpad)"), new C2705g(R.styleable.AppCompatTheme_checkedTextViewStyle, "9 (Numpad)"), new C2705g(R.styleable.AppCompatTheme_ratingBarStyleSmall, "(.) (Numpad)"), new C2705g(R.styleable.AppCompatTheme_radioButtonStyle, "(+) (Numpad)"), new C2705g(R.styleable.AppCompatTheme_ratingBarStyleIndicator, "(-) (Numpad)"), new C2705g(R.styleable.AppCompatTheme_editTextStyle, "(*) (Numpad)"), new C2705g(12, "Clear"), new C2705g(145, "Scroll Lock"), new C2705g(19, "Pause")));
        }
        return f7510y;
    }

    /* renamed from: a */
    public static void m130a(int[] iArr, HashSet<Integer> hashSet) {
        hashSet.clear();
        for (int i : iArr) {
            hashSet.add(Integer.valueOf(i));
        }
    }

    /* renamed from: a */
    public static int[] m131a(HashSet<Integer> hashSet) {
        int i = 0;
        int[] iArr = new int[hashSet == null ? 0 : hashSet.size()];
        if (hashSet != null) {
            Iterator<Integer> it = hashSet.iterator();
            while (it.hasNext()) {
                i++;
                iArr[i] = it.next().intValue();
            }
        }
        return iArr;
    }

    /* renamed from: b */
    private static void m127b(int i, int i2) {
        byte[] bArr = new byte[1];
        for (byte b = (byte) i; b <= ((byte) i2); b = (byte) (b + 1)) {
            bArr[0] = b;
            f7510y.add(new C2705g(b, new String(bArr)));
        }
    }

    /* renamed from: b */
    public static boolean m128b(int i) {
        if (f7511z == null) {
            f7511z = new HashSet<>();
            for (C2705g gVar : f7510y) {
                f7511z.add(Integer.valueOf(gVar.m49a()));
            }
        }
        return f7511z.contains(Integer.valueOf(i));
    }

    /* renamed from: e */
    private void m117e(HashSet<Integer> hashSet) {
        boolean z;
        int i;
        boolean z2;
        int i2;
        if (m82j()) {
            int i3 = 0;
            int i4 = 0;
            boolean z3 = false;
            boolean z4 = false;
            if (this.f7527p == 0 || this.f7527p == 1 || this.f7527p == 3) {
                Iterator<Integer> it = hashSet.iterator();
                while (it.hasNext()) {
                    int intValue = it.next().intValue();
                    if (this.f7528q.contains(Integer.valueOf(intValue))) {
                        i4 += 100;
                        z3 = true;
                    }
                    if (this.f7529r.contains(Integer.valueOf(intValue))) {
                        i3 -= 100;
                        z4 = true;
                    } else {
                        z4 = z4;
                    }
                    if (this.f7530s.contains(Integer.valueOf(intValue))) {
                        i4 -= 100;
                        z3 = true;
                    } else {
                        i4 = i4;
                    }
                    if (this.f7531t.contains(Integer.valueOf(intValue))) {
                        i3 += 100;
                        z4 = true;
                    } else {
                        i3 = i3;
                    }
                }
                z4 = z4;
                z3 = z3;
                i4 = i4;
                i3 = i3;
            }
            long currentTimeMillis = System.currentTimeMillis();
            if (this.f7534w != 0 && !z4) {
                i3 = this.f7514c;
                z2 = true;
            } else if (((m108j(i3) == m108j(this.f7514c) || (i3 != 0 && this.f7514c == 0)) && this.f7516e > 0 && this.f7516e <= 200) || ((m108j(i3) * m108j(this.f7514c) < 0 || (i3 == 0 && this.f7514c != 0)) && this.f7518g > 0 && this.f7518g <= 200)) {
                int i5 = (m108j(i3) == m108j(this.f7514c) || (i3 != 0 && this.f7514c == 0)) ? this.f7516e : this.f7518g;
                if (currentTimeMillis - this.f7522k >= this.f7520i) {
                    i = i3 > this.f7514c ? Math.min(i3, i5 + this.f7514c) : Math.max(i3, this.f7514c - i5);
                    this.f7522k = currentTimeMillis;
                } else {
                    i = this.f7514c;
                }
                z2 = i3 == i;
                i3 = i;
            } else {
                z2 = true;
            }
            if (this.f7535x != 0 && !z3) {
                i4 = this.f7515d;
                z = z2;
            } else if (((m108j(i4) == m108j(this.f7515d) || (i4 != 0 && this.f7515d == 0)) && this.f7517f > 0 && this.f7517f <= 200) || ((m108j(i4) * m108j(this.f7515d) < 0 || (i4 == 0 && this.f7515d != 0)) && this.f7519h > 0 && this.f7519h <= 200)) {
                int i6 = (m108j(i4) == m108j(this.f7515d) || (i4 != 0 && this.f7515d == 0)) ? this.f7517f : this.f7519h;
                if (currentTimeMillis - this.f7523l >= this.f7521j) {
                    i2 = i4 > this.f7515d ? Math.min(i4, i6 + this.f7515d) : Math.max(i4, this.f7515d - i6);
                    this.f7523l = currentTimeMillis;
                } else {
                    i2 = this.f7515d;
                }
                z = i4 == i2 && z2;
                i4 = i2;
            } else {
                z = z2;
            }
            this.f7514c = i3;
            this.f7515d = i4;
            if (this.f7527p == 0) {
                for (C2694g gVar : this.f7532u) {
                    if (gVar.m94d() == C2687c.f7455a) {
                        gVar.m103a(i3);
                    } else {
                        gVar.m104a(i3);
                    }
                }
                for (C2694g gVar2 : this.f7533v) {
                    if (gVar2.m94d() == C2687c.f7455a) {
                        gVar2.m103a(i4);
                    } else {
                        gVar2.m104a(i4);
                    }
                }
            } else if (this.f7527p == 1 || this.f7527p == 3) {
                if (i4 == 0) {
                    i4 = -i3;
                } else if (i3 == 0) {
                    i3 = i4;
                } else if (i3 < 0) {
                    i3 = m108j(i4) * (Math.abs(i4) - Math.abs(i3));
                } else {
                    i4 = (Math.abs(i4) - Math.abs(i3)) * m108j(i4);
                    i3 = i4;
                }
                for (C2694g gVar3 : this.f7532u) {
                    gVar3.m103a(i3);
                }
                for (C2694g gVar4 : this.f7533v) {
                    gVar4.m103a(i4);
                }
            }
        } else {
            z = true;
        }
        this.f7525n = z;
    }

    /* renamed from: j */
    private static int m108j(int i) {
        if (i > 0) {
            return 1;
        }
        return i < 0 ? -1 : 0;
    }

    /* renamed from: m */
    private boolean m107m() {
        return (this.f7516e > 0 && this.f7516e <= 200) || (this.f7518g > 0 && this.f7518g <= 200);
    }

    /* renamed from: n */
    private boolean m106n() {
        return (this.f7517f > 0 && this.f7517f <= 200) || (this.f7519h > 0 && this.f7519h <= 200);
    }

    @Override
    /* renamed from: a */
    public List<C2694g> mo136a(int i) {
        return i == 0 ? this.f7532u : this.f7533v;
    }

    /* renamed from: a */
    public void m135a(int i, int i2) {
        if (i == 0) {
            this.f7534w = i2;
        } else {
            this.f7535x = i2;
        }
    }

    /* renamed from: a */
    public void m134a(int i, HashSet<Integer> hashSet) {
        this.f7512a.clear();
        if (hashSet != null) {
            Iterator<Integer> it = hashSet.iterator();
            while (it.hasNext()) {
                int intValue = it.next().intValue();
                if (m80l().contains(Integer.valueOf(intValue))) {
                    this.f7512a.add(Integer.valueOf(intValue));
                }
            }
        }
        this.f7513b = i;
    }

    /* renamed from: a */
    public void m132a(String str) {
        if (str == null) {
            m83b("");
        }
        m83b(str);
    }

    /* renamed from: b */
    public String m129b() {
        return m81k();
    }

    /* renamed from: b */
    public boolean m126b(HashSet<Integer> hashSet) {
        if (this.f7513b != 0 && (hashSet == null || !hashSet.contains(Integer.valueOf(this.f7513b)))) {
            return true;
        }
        if (hashSet != null) {
            Iterator<Integer> it = hashSet.iterator();
            while (it.hasNext()) {
                int intValue = it.next().intValue();
                if (m80l().contains(Integer.valueOf(intValue)) && !this.f7512a.contains(Integer.valueOf(intValue))) {
                    return true;
                }
            }
        }
        return false;
    }

    /* renamed from: c */
    public int m123c(HashSet<Integer> hashSet) {
        if (hashSet != null) {
            Iterator<Integer> it = hashSet.iterator();
            while (it.hasNext()) {
                int intValue = it.next().intValue();
                if (m80l().contains(Integer.valueOf(intValue)) && !this.f7512a.contains(Integer.valueOf(intValue))) {
                    return intValue;
                }
            }
        }
        return 0;
    }

    /* renamed from: c */
    public HashSet<Integer> m125c() {
        return this.f7528q;
    }

    /* renamed from: c */
    public void m124c(int i) {
        this.f7527p = i;
    }

    /* renamed from: d */
    public HashSet<Integer> m122d() {
        return this.f7529r;
    }

    /* renamed from: d */
    public void m121d(int i) {
        this.f7516e = Math.min(200, Math.max(0, i));
    }

    /* renamed from: d */
    public boolean m120d(HashSet<Integer> hashSet) {
        Iterator<Integer> it = null;
        String str = "";
        while (hashSet.iterator().hasNext()) {
            str = str + it.next().toString() + ":";
        }
        if (this.f7524m.equals(str) && this.f7525n) {
            return true;
        }
        this.f7526o = (HashSet) hashSet.clone();
        long currentTimeMillis = System.currentTimeMillis();
        if ((m107m() && currentTimeMillis - this.f7522k >= this.f7520i) || (m106n() && currentTimeMillis - this.f7523l >= this.f7521j)) {
            m117e(hashSet);
        }
        this.f7524m = str;
        return this.f7525n;
    }

    /* renamed from: e */
    public HashSet<Integer> m119e() {
        return this.f7530s;
    }

    /* renamed from: e */
    public void m118e(int i) {
        this.f7518g = Math.min(200, Math.max(0, i));
    }

    /* renamed from: f */
    public HashSet<Integer> m116f() {
        return this.f7531t;
    }

    /* renamed from: f */
    public void m115f(int i) {
        this.f7517f = Math.min(200, Math.max(0, i));
    }

    /* renamed from: g */
    public int m114g() {
        return this.f7527p;
    }

    /* renamed from: g */
    public void m113g(int i) {
        this.f7519h = Math.min(200, Math.max(0, i));
    }

    /* renamed from: h */
    public void m111h(int i) {
        this.f7520i = Math.max(100, (i / 100) * 100);
    }

    /* renamed from: h */
    public boolean m112h() {
        if (!this.f7525n) {
            long currentTimeMillis = System.currentTimeMillis();
            if (currentTimeMillis - this.f7522k >= this.f7520i || currentTimeMillis - this.f7523l >= this.f7521j) {
                m117e(this.f7526o);
            }
        }
        return this.f7525n;
    }

    /* renamed from: i */
    public void m110i() {
        this.f7512a.clear();
        this.f7513b = 0;
    }

    /* renamed from: i */
    public void m109i(int i) {
        this.f7521j = Math.max(100, (i / 100) * 100);
    }
}
