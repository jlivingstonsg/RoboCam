package ru.proghouse.robocam;

@SuppressWarnings("ALL")
public class C2705g {

    /* renamed from: a */
    private int f7564a;

    /* renamed from: b */
    private String f7565b;

    public C2705g(int i, String str) {
        this.f7564a = i;
        this.f7565b = str;
    }

    /* renamed from: a */
    public int m49a() {
        return this.f7564a;
    }

    /* renamed from: b */
    public String m48b() {
        return this.f7565b;
    }
}
