package ru.proghouse.robocam.p062a;

@SuppressWarnings("ALL")
public class C2684b {

    /* renamed from: a */
    private boolean f7447a = false;

    /* renamed from: b */
    private String f7448b = "c";

    /* renamed from: c */
    private int f7449c = 0;

    /* renamed from: d */
    private int f7450d = 0;

    /* renamed from: a */
    public void m271a(int i, int i2) {
        if (i == 0) {
            this.f7449c = i2;
        } else {
            this.f7450d = i2;
        }
    }

    /* renamed from: a */
    public void m270a(String str) {
        this.f7448b = str;
    }

    /* renamed from: a */
    public void m269a(boolean z) {
        this.f7447a = z;
    }

    /* renamed from: d */
    public String m268d() {
        return !this.f7447a ? "-" : this.f7448b;
    }

    /* renamed from: e */
    public String m267e() {
        return new Integer(this.f7449c).toString() + new Integer(this.f7450d).toString();
    }
}
