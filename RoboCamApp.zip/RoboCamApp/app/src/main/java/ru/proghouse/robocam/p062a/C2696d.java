package ru.proghouse.robocam.p062a;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

@SuppressWarnings("ALL")
public class C2696d {
    /* renamed from: a */
    public static int m79a(InputStream inputStream) {
        byte[] bArr = new byte[1];
        try {
            inputStream.read(bArr);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return bArr[0] < 0 ? bArr[0] + 256 : bArr[0];
    }

    /* renamed from: a */
    public static int m71a(byte[] bArr, int i) {
        byte b = bArr[i];
        return b < 0 ? b + 256 : b;
    }

    /* renamed from: a */
    public static String m70a(byte[] bArr, int i, int i2) {
        int i3 = i;
        while (true) {
            if (i3 >= Math.min(bArr.length, i3 + i2)) {
                break;
            } else if (bArr[i3] == 0) {
                i2 = i3 - i;
                break;
            } else {
                i3++;
            }
        }
        try {
            return new String(bArr, i, i2, "US-ASCII");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return null;
    }

    /* renamed from: a */
    public static String m69a(byte[] bArr, int i, int i2, String str) {
        int i3 = i;
        while (true) {
            if (i3 >= Math.min(bArr.length, i3 + i2)) {
                break;
            } else if (bArr[i3] == 0) {
                i2 = i3 - i;
                break;
            } else {
                i3++;
            }
        }
        try {
            return new String(bArr, i, i2, str);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return str;
    }

    /* renamed from: a */
    public static void m78a(OutputStream outputStream, byte b) {
        try {
            outputStream.write(b);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /* renamed from: a */
    public static void m77a(OutputStream outputStream, float f) {
        m63c(outputStream, Float.floatToIntBits(f));
    }

    /* renamed from: a */
    public static void m76a(OutputStream outputStream, int i) {
        if (i > 127) {
            i -= 256;
        }
        try {
            outputStream.write(i);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /* renamed from: a */
    public static void m75a(OutputStream outputStream, long j) {
        m76a(outputStream, (int) (j & 255));
        m76a(outputStream, (int) ((j >> 8) & 255));
        m76a(outputStream, (int) ((j >> 16) & 255));
        m76a(outputStream, (int) ((j >> 24) & 255));
    }

    /* renamed from: a */
    public static void m74a(OutputStream outputStream, String str) {
        try {
            outputStream.write(str.getBytes("US-ASCII"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /* renamed from: a */
    public static void m73a(OutputStream outputStream, String str, String str2) {
        try {
            outputStream.write(str.getBytes(str2));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /* renamed from: a */
    public static void m72a(OutputStream outputStream, short s) {
        byte[] bArr = new byte[2];
        ByteBuffer wrap = ByteBuffer.wrap(bArr);
        wrap.order(ByteOrder.LITTLE_ENDIAN);
        wrap.putShort(s);
        try {
            outputStream.write(bArr);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /* renamed from: b */
    public static int m68b(InputStream inputStream) {
        return m79a(inputStream) | (m79a(inputStream) << 8);
    }

    /* renamed from: b */
    public static void m67b(OutputStream outputStream, int i) {
        m76a(outputStream, i & 255);
        m76a(outputStream, (i >> 8) & 255);
    }

    /* renamed from: b */
    public static void m66b(OutputStream outputStream, String str) {
        m74a(outputStream, str);
        try {
            outputStream.write(0);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /* renamed from: b */
    public static void m65b(OutputStream outputStream, String str, String str2) {
        m73a(outputStream, str, str2);
        try {
            outputStream.write(0);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /* renamed from: b */
    public static void m64b(byte[] bArr, int i, int i2) {
        if (i2 > 127) {
            i2 -= 256;
        }
        bArr[i] = (byte) i2;
    }

    /* renamed from: c */
    public static void m63c(OutputStream outputStream, int i) {
        m76a(outputStream, i & 255);
        m76a(outputStream, (i >> 8) & 255);
        m76a(outputStream, (i >> 16) & 255);
        m76a(outputStream, (i >> 24) & 255);
    }

    /* renamed from: c */
    public static void m62c(byte[] bArr, int i, int i2) {
        m64b(bArr, i, i2 & 255);
        m64b(bArr, i + 1, (i2 >> 8) & 255);
    }

    /* renamed from: d */
    public static void m61d(byte[] bArr, int i, int i2) {
        m64b(bArr, i, i2 & 255);
        m64b(bArr, i + 1, (i2 >> 8) & 255);
        m64b(bArr, i + 2, (i2 >> 16) & 255);
        m64b(bArr, i + 3, (i2 >> 24) & 255);
    }
}
