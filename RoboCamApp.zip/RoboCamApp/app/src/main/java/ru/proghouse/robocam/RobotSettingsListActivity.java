package ru.proghouse.robocam;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import ru.proghouse.robocam.p062a.AbstractC2677a;

@SuppressWarnings("ALL")
public class RobotSettingsListActivity extends AppCompatActivity implements View.OnClickListener {

    /* renamed from: q */
    private File f7299q;

    /* renamed from: n */
    private Button f7296n = null;

    /* renamed from: o */
    private Button f7297o = null;

    /* renamed from: p */
    private ImageButton f7298p = null;

    /* renamed from: r */
    private ListView f7300r = null;

    /* renamed from: s */
    private Spinner f7301s = null;

    /* renamed from: t */
    private List<C2663a> f7302t = null;

    /* renamed from: u */
    private SharedPreferences.Editor f7303u = null;

    /* renamed from: v */
    private Context f7304v = null;

    /* renamed from: w */
    private String f7305w = null;

    /* renamed from: x */
    private Date f7306x = null;

    /* renamed from: y */
    private LinearLayout f7307y = null;

    /* renamed from: z */
    private TextView f7308z = null;

    /* renamed from: A */
    private LinearLayout f7295A = null;

    @SuppressWarnings("ALL")
    public class C2663a {

        /* renamed from: a */
        public String f7313a;

        /* renamed from: b */
        public String f7314b;

        /* renamed from: c */
        public String f7315c;

        /* renamed from: d */
        public File f7316d;

        /* renamed from: e */
        public String f7317e;

        public C2663a(String str, String str2, String str3, File file, String str4) {
            this.f7313a = str;
            this.f7314b = str2;
            this.f7315c = str3;
            this.f7316d = file;
            this.f7317e = str4;
        }
    }

    /* renamed from: j */
    private void m401j() {
        File[] listFiles;
        this.f7302t = new ArrayList();
        for (File file : this.f7299q.listFiles()) {
            if (file.getName().trim().endsWith(".xml")) {
                try {
                    Document parse = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(file);
                    parse.getDocumentElement().normalize();
                    if (!(parse.getDocumentElement().getNodeName().equals("EV3") || parse.getDocumentElement().getNodeName().equals("Custom"))) {
                        throw new Exception(getString(R.string.unknown_driver_name, new Object[]{parse.getDocumentElement().getNodeName()}));
//                        break;
                    }
                    String nodeName = parse.getDocumentElement().getNodeName();
                    if ("Custom".equals(nodeName)) {
                        nodeName = getString(R.string.custom_driver_desc);
                    }
                    this.f7302t.add(new C2663a(parse.getDocumentElement().getNodeName(), parse.getDocumentElement().getAttribute("Name"), parse.getDocumentElement().getAttribute("Description"), file, nodeName));
                } catch (Throwable th) {
                    Toast.makeText(this, getString(R.string.error_while_opening_settings_file, new Object[]{file.getName(), th.getMessage()}), 1).show();
                }
            }
        }
        Collections.sort(this.f7302t, new Comparator<C2663a>() {
            /* renamed from: a */
            public int compare(C2663a aVar, C2663a aVar2) {
                long lastModified = aVar2.f7316d.lastModified() - aVar.f7316d.lastModified();
                if (lastModified == 0) {
                    return 0;
                }
                return lastModified < 0 ? -1 : 1;
            }
        });
        this.f7300r.setAdapter((ListAdapter) new ArrayAdapter<C2663a>(this, R.layout.spinner_item, this.f7302t) {
            @Override
            public View getView(int i, View view, ViewGroup viewGroup) {
                if (view == null) {
                    view = RobotSettingsListActivity.this.getLayoutInflater().inflate(R.layout.spinner_item, viewGroup, false);
                }
                C2663a item = getItem(i);
                ((TextView) view.findViewById(R.id.textView1)).setText(item.f7314b);
                ((TextView) view.findViewById(R.id.textView2)).setText(item.f7317e + ": " + item.f7315c);
                return view;
            }
        });
    }

    /* renamed from: k */
    private void m400k() {
        int i = 0;
        ArrayList arrayList = new ArrayList();
        for (C2663a aVar : this.f7302t) {
            arrayList.add(aVar.f7314b);
        }
        C2712m.m18a(this.f7301s, this, arrayList, R.string.current_robot_settings);
        this.f7305w = getSharedPreferences("RoboCamSettings", 0).getString("current_robot_settings", "");
        i = -1;
        while (i < this.f7302t.size() && !this.f7302t.get(i).f7316d.getName().equals(this.f7305w)) {
            i++;
        }
        if (i > 0) {
            this.f7301s.setSelection(i);
        }
    }

    /* renamed from: l */
    public SharedPreferences.Editor m399l() {
        if (this.f7303u == null) {
            this.f7303u = getSharedPreferences("RoboCamSettings", 0).edit();
        }
        return this.f7303u;
    }

    /* renamed from: m */
    public void m398m() {
        if (this.f7303u == null) {
            return;
        }
        if (Build.VERSION.SDK_INT >= 9) {
            this.f7303u.apply();
        } else {
            this.f7303u.commit();
        }
    }

    /* renamed from: n */
    private void m397n() {
        if (C2714o.m9a(this, 1)) {
            startActivity(new Intent(this, ImportActivity.class));
        }
    }

    public void onCancelButtonClick(View view) {
        finish();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.buttonOverflow /* 2131492970 */:
                view.showContextMenu();
                return;
            case R.id.buttonDelete /* 2131493099 */:
                view.showContextMenu();
                return;
            case R.id.buttonAdd /* 2131493101 */:
                view.showContextMenu();
                return;
            default:
                return;
        }
    }

    @Override
    public boolean onContextItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case -3:
                startActivity(new Intent(this, CustomSettingsActivity.class));
                break;
            case -2:
                m397n();
                break;
            case -1:
                startActivity(new Intent(this, EV3SettingsActivity.class));
                break;
            default:
                if (menuItem.getItemId() > 0 && menuItem.getItemId() <= this.f7300r.getAdapter().getCount()) {
                    C2663a aVar = (C2663a) this.f7300r.getAdapter().getItem(menuItem.getItemId() - 1);
                    String name = aVar.f7316d.getName();
                    if (this.f7305w == null || name == null || name.length() < this.f7305w.length() || !name.substring(0, this.f7305w.length()).equals(this.f7305w)) {
                        if (aVar.f7316d.delete()) {
                            m401j();
                            m400k();
                            Toast.makeText(this, (int) R.string.settings_were_deleted, 1).show();
                            break;
                        } else {
                            Toast.makeText(this, (int) R.string.cannot_delete_settings_file, 1).show();
                            break;
                        }
                    } else {
                        Toast.makeText(this, (int) R.string.cannot_delete_current_settings_file, 1).show();
                        break;
                    }
                } else {
                    return super.onContextItemSelected(menuItem);
                }
//                break;
        }
        return true;
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_robot_settings_list);
        this.f7304v = this;
        this.f7307y = (LinearLayout) findViewById(R.id.robot_settings_list_main_layout);
        this.f7307y.setEnabled(false);
        this.f7308z = (TextView) findViewById(R.id.textViewSubsWarning);
        this.f7295A = (LinearLayout) findViewById(R.id.linearLayoutSubsWarning);
        if (bundle != null && bundle.getBoolean("WarningHided")) {
            this.f7295A.setVisibility(8);
        }
        this.f7296n = (Button) findViewById(R.id.buttonAdd);
        this.f7296n.setOnClickListener(this);
        registerForContextMenu(this.f7296n);
        this.f7297o = (Button) findViewById(R.id.buttonDelete);
        this.f7297o.setOnClickListener(this);
        registerForContextMenu(this.f7297o);
        this.f7298p = (ImageButton) findViewById(R.id.buttonOverflow);
        this.f7298p.setOnClickListener(this);
        registerForContextMenu(this.f7298p);
        this.f7299q = C2714o.m6a(this);
        this.f7300r = (ListView) findViewById(R.id.settingsListView);
        m401j();
        this.f7306x = new Date();
        C2709k.m43a(this.f7306x);
        this.f7300r.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                C2663a aVar = (C2663a) RobotSettingsListActivity.this.f7300r.getAdapter().getItem(i);
                Intent intent = new Intent(RobotSettingsListActivity.this.f7304v, aVar.f7313a.equals("EV3") ? EV3SettingsActivity.class : CustomSettingsActivity.class);
                intent.putExtra("SettingsFileName", aVar.f7316d.getName());
                RobotSettingsListActivity.this.startActivity(intent);
            }
        });
        this.f7301s = (Spinner) findViewById(R.id.spinnerCurrentRobotSettings);
        m400k();
        this.f7301s.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                String name = ((C2663a) RobotSettingsListActivity.this.f7302t.get(i)).f7316d.getName();
                if (!RobotSettingsListActivity.this.f7305w.equals(name)) {
                    RobotSettingsListActivity.this.m399l().putString("current_robot_settings", name);
                    RobotSettingsListActivity.this.m398m();
                    AbstractC2677a.m329a(RobotSettingsListActivity.this.f7304v, true);
                    Toast.makeText(RobotSettingsListActivity.this.f7304v, (int) R.string.current_robot_settings_have_changed, 1).show();
                    RobotSettingsListActivity.this.f7305w = name;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        super.onCreateContextMenu(contextMenu, view, contextMenuInfo);
        if (view.getId() == R.id.buttonAdd) {
            contextMenu.add(0, -1, 0, R.string.action_add_ev3_settings);
            contextMenu.add(0, -3, 0, R.string.action_add_custom_settings);
        } else if (view.getId() == R.id.buttonDelete) {
            for (int i = 0; i < this.f7300r.getAdapter().getCount(); i++) {
                contextMenu.add(0, i + 1, i + 1, ((C2663a) this.f7300r.getAdapter().getItem(i)).f7314b);
            }
        } else if (view.getId() == R.id.buttonOverflow) {
            contextMenu.add(0, -2, 0, R.string.action_import_robot_settings_from_file);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    public void onHideSubsButtonClick(View view) {
        this.f7295A.setVisibility(8);
    }

    @Override
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != 1) {
            super.onRequestPermissionsResult(i, strArr, iArr);
        } else if (iArr.length != 1 || iArr[0] != 0) {
            C2714o.m8a((Activity) this, (int) R.string.request_write_external_storage_permission, false);
        } else if (i == 1) {
            m397n();
        }
    }

    @Override
    protected void onRestoreInstanceState(Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        if (bundle.getBoolean("WarningHided")) {
            this.f7295A.setVisibility(8);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!this.f7306x.equals(C2709k.m39b())) {
            this.f7306x = C2709k.m39b();
            m401j();
            m400k();
            AbstractC2677a.m329a(this.f7304v, true);
        }
    }

    @Override
    public void onSaveInstanceState(Bundle bundle) {
        bundle.putBoolean("WarningHided", this.f7295A.getVisibility() == 8);
        super.onSaveInstanceState(bundle);
    }
}
