package ru.proghouse.robocam;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

@SuppressWarnings("ALL")
public class GlobalSettingsActivity extends AppCompatActivity {

    /* renamed from: n */
    private Button f7130n = null;

    /* renamed from: o */
    private Button f7131o = null;

    public void onCameraButtonClick(View view) {
        startActivity(new Intent(this, ServerSettingsActivity.class));
    }

    public void onCancelButtonClick(View view) {
        finish();
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_global_settings);
        this.f7130n = (Button) findViewById(R.id.buttonServer);
        this.f7130n.setTransformationMethod(null);
        this.f7131o = (Button) findViewById(R.id.buttonRobot);
        this.f7131o.setTransformationMethod(null);
    }

    public void onRobotButtonClick(View view) {
        startActivity(new Intent(this, RobotSettingsListActivity.class));
    }
}
