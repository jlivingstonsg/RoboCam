package ru.proghouse.robocam;

import java.util.Comparator;

@SuppressWarnings("ALL")
class C2697b implements Comparator<C2706h> {
    /* renamed from: a */
    public int compare(C2706h hVar, C2706h hVar2) {
        return Long.signum((hVar.f7566a * hVar.f7567b) - (hVar2.f7566a * hVar2.f7567b));
    }
}
