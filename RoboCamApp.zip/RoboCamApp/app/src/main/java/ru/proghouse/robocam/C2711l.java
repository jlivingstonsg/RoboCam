package ru.proghouse.robocam;

import android.content.res.Resources;
import android.support.v8.renderscript.Allocation;
import android.support.v8.renderscript.Element;
import android.support.v8.renderscript.FieldPacker;
import android.support.v8.renderscript.RSRuntimeException;
import android.support.v8.renderscript.RenderScript;
import android.support.v8.renderscript.Script;
import android.support.v8.renderscript.ScriptC;

@SuppressWarnings("ALL")
public class C2711l extends ScriptC {

    /* renamed from: a */
    private Element f7590a;

    /* renamed from: b */
    private Element f7591b;

    /* renamed from: c */
    private Element f7592c;

    /* renamed from: d */
    private Element f7593d;

    /* renamed from: e */
    private FieldPacker f7594e;

    /* renamed from: f */
    private int f7595f;

    /* renamed from: g */
    private int f7596g;

    /* renamed from: h */
    private long f7597h;

    /* renamed from: i */
    private long f7598i;

    /* renamed from: j */
    private long f7599j;

    /* renamed from: k */
    private Allocation f7600k;

    /* renamed from: l */
    private Allocation f7601l;

    /* renamed from: m */
    private Allocation f7602m;

    public C2711l(RenderScript renderScript) {
        this(renderScript, renderScript.getApplicationContext().getResources(), renderScript.getApplicationContext().getResources().getIdentifier("yuv420888", "raw", renderScript.getApplicationContext().getPackageName()));
    }

    public C2711l(RenderScript renderScript, Resources resources, int i) {
        super(renderScript, resources, i);
        this.f7591b = Element.I32(renderScript);
        this.f7592c = Element.U32(renderScript);
        this.f7590a = Element.ALLOCATION(renderScript);
        this.f7593d = Element.U8_4(renderScript);
    }

    /* renamed from: a */
    public synchronized void m35a(int i) {
        setVar(0, i);
        this.f7595f = i;
    }

    /* renamed from: a */
    public synchronized void m34a(long j) {
        if (this.f7594e != null) {
            this.f7594e.reset();
        } else {
            this.f7594e = new FieldPacker(4);
        }
        this.f7594e.addU32(j);
        setVar(2, this.f7594e);
        this.f7597h = j;
    }

    /* renamed from: a */
    public synchronized void m33a(Allocation allocation) {
        setVar(5, allocation);
        this.f7600k = allocation;
    }

    /* renamed from: a */
    public void m32a(Allocation allocation, Script.LaunchOptions launchOptions) {
        if (!allocation.getType().getElement().isCompatible(this.f7593d)) {
            throw new RSRuntimeException("Type mismatch with U8_4!");
        }
        forEach(1, (Allocation) null, allocation, (FieldPacker) null, launchOptions);
    }

    /* renamed from: b */
    public synchronized void m31b(int i) {
        setVar(1, i);
        this.f7596g = i;
    }

    /* renamed from: b */
    public synchronized void m30b(long j) {
        if (this.f7594e != null) {
            this.f7594e.reset();
        } else {
            this.f7594e = new FieldPacker(4);
        }
        this.f7594e.addU32(j);
        setVar(3, this.f7594e);
        this.f7598i = j;
    }

    /* renamed from: b */
    public synchronized void m29b(Allocation allocation) {
        setVar(6, allocation);
        this.f7601l = allocation;
    }

    /* renamed from: c */
    public synchronized void m28c(long j) {
        if (this.f7594e != null) {
            this.f7594e.reset();
        } else {
            this.f7594e = new FieldPacker(4);
        }
        this.f7594e.addU32(j);
        setVar(4, this.f7594e);
        this.f7599j = j;
    }

    /* renamed from: c */
    public synchronized void m27c(Allocation allocation) {
        setVar(7, allocation);
        this.f7602m = allocation;
    }
}
