package ru.proghouse.robocam;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.view.ContextMenu;
import android.view.ContextThemeWrapper;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import ru.proghouse.robocam.p062a.p064b.C2687c;

@SuppressWarnings("ALL")
public class EV3SettingsActivity extends AppCompatActivity implements View.OnClickListener {

    /* renamed from: n */
    private String f7038n;

    /* renamed from: o */
    private C2622b[] f7039o = new C2622b[4];

    /* renamed from: p */
    private List<C2626c> f7040p = new ArrayList();

    /* renamed from: q */
    private int f7041q = 0;

    /* renamed from: r */
    private EditText f7042r = null;

    /* renamed from: s */
    private EditText f7043s = null;

    /* renamed from: t */
    private CheckBox f7044t = null;

    /* renamed from: u */
    private CheckBox f7045u = null;

    /* renamed from: v */
    private ImageButton f7046v = null;

    /* renamed from: w */
    private CheckBox f7047w = null;

    /* renamed from: x */
    private EditText f7048x = null;

    /* renamed from: y */
    private Button f7049y = null;

    /* renamed from: z */
    private Button f7050z = null;

    /* renamed from: A */
    private Button f7034A = null;

    /* renamed from: B */
    private Button f7035B = null;

    /* renamed from: C */
    private Button f7036C = null;

    /* renamed from: D */
    private int[] f7037D = {0, 1, 3, 2};

    @SuppressWarnings("ALL")
    class C2621a {

        /* renamed from: a */
        C2626c f7051a;

        /* renamed from: b */
        boolean f7052b;

        C2621a(C2626c cVar, boolean z) {
            this.f7051a = null;
            this.f7052b = false;
            this.f7051a = cVar;
            this.f7052b = z;
        }
    }

    @SuppressWarnings("ALL")
    public class C2622b {

        /* renamed from: a */
        int f7054a;

        /* renamed from: b */
        public CheckBox f7055b;

        /* renamed from: c */
        public ImageView f7056c;

        /* renamed from: d */
        public Spinner f7057d;

        /* renamed from: e */
        public ImageView f7058e;

        /* renamed from: f */
        public Spinner f7059f;

        /* renamed from: g */
        public ImageView f7060g;

        /* renamed from: h */
        public Spinner f7061h;

        /* renamed from: i */
        public ImageView f7062i;

        /* renamed from: j */
        public Spinner f7063j;

        /* renamed from: k */
        public TextView f7064k;

        /* renamed from: l */
        public LinearLayout f7065l;

        /* renamed from: m */
        public LinearLayout f7066m;

        /* renamed from: n */
        public List<C2629d> f7067n = new ArrayList();

        /* renamed from: p */
        private C2622b f7069p;

        public C2622b(Activity activity, int i) {
            this.f7069p = null;
            this.f7069p = this;
            switch (i) {
                case 0:
                    m592a(activity, i, R.id.checkBoxJoystickVisibility1, R.id.spinnerJoystickShape1, R.id.spinnerJoystickType1, R.id.imageViewJoystickBehavior1_1, R.id.imageViewJoystickBehavior1_2, R.id.spinnerJoystickBehavior1_1, R.id.spinnerJoystickBehavior1_2, R.id.textViewJoystick1Ports, R.id.linearLayoutJoystick1Ports, R.id.imageView1_1, R.id.imageView1_2, R.id.linearLayoutJoystick1PortButtons);
                    return;
                case 1:
                    m592a(activity, i, R.id.checkBoxJoystickVisibility2, R.id.spinnerJoystickShape2, R.id.spinnerJoystickType2, R.id.imageViewJoystickBehavior2_1, R.id.imageViewJoystickBehavior2_2, R.id.spinnerJoystickBehavior2_1, R.id.spinnerJoystickBehavior2_2, R.id.textViewJoystick2Ports, R.id.linearLayoutJoystick2Ports, R.id.imageView2_1, R.id.imageView2_2, R.id.linearLayoutJoystick2PortButtons);
                    return;
                case 2:
                    m592a(activity, i, R.id.checkBoxJoystickVisibility3, R.id.spinnerJoystickShape3, R.id.spinnerJoystickType3, R.id.imageViewJoystickBehavior3_1, R.id.imageViewJoystickBehavior3_2, R.id.spinnerJoystickBehavior3_1, R.id.spinnerJoystickBehavior3_2, R.id.textViewJoystick3Ports, R.id.linearLayoutJoystick3Ports, R.id.imageView3_1, R.id.imageView3_2, R.id.linearLayoutJoystick3PortButtons);
                    return;
                case 3:
                    m592a(activity, i, R.id.checkBoxJoystickVisibility4, R.id.spinnerJoystickShape4, R.id.spinnerJoystickType4, R.id.imageViewJoystickBehavior4_1, R.id.imageViewJoystickBehavior4_2, R.id.spinnerJoystickBehavior4_1, R.id.spinnerJoystickBehavior4_2, R.id.textViewJoystick4Ports, R.id.linearLayoutJoystick4Ports, R.id.imageView4_1, R.id.imageView4_2, R.id.linearLayoutJoystick4PortButtons);
                    return;
                default:
                    return;
            }
        }

        /* renamed from: a */
        public void m593a() {
            int i = this.f7055b.isChecked() ? 0 : 8;
            this.f7069p.f7056c.setVisibility(i);
            this.f7069p.f7058e.setVisibility(i);
            this.f7069p.f7057d.setVisibility(i);
            this.f7069p.f7059f.setVisibility(i);
            this.f7069p.f7064k.setVisibility(i);
            this.f7069p.f7065l.setVisibility(i);
            this.f7069p.f7066m.setVisibility(i);
            m588c();
        }

        /* renamed from: a */
        private void m592a(Activity activity, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13) {
            this.f7054a = i;
            this.f7055b = (CheckBox) activity.findViewById(i2);
            this.f7056c = (ImageView) activity.findViewById(i11);
            this.f7058e = (ImageView) activity.findViewById(i12);
            this.f7057d = (Spinner) activity.findViewById(i3);
            C2712m.m18a(this.f7057d, activity, Arrays.asList(activity.getString(R.string.joystick_shape_vertical), activity.getString(R.string.joystick_shape_horizontal), activity.getString(R.string.joystick_shape_circular), activity.getString(R.string.joystick_shape_quadratic), activity.getString(R.string.joystick_shape_arrows), activity.getString(R.string.joystick_shape_vertical_arrows), activity.getString(R.string.joystick_shape_horizontal_arrows)), R.string.joystick_shape);
            this.f7059f = (Spinner) activity.findViewById(i4);
            Spinner spinner = this.f7059f;
            String[] strArr = new String[4];
            strArr[0] = activity.getString(R.string.joystick_type_independent_motors);
            strArr[1] = activity.getString(R.string.joystick_type_steering);
            strArr[2] = activity.getString(R.string.joystick_type_steering_progressive);
            strArr[3] = activity.getString(R.string.joystick_type_mailbox) + " (" + (i == 0 ? "x, y" : i == 1 ? "w, z" : i == 2 ? "a, b" : "c, d") + ")";
            C2712m.m18a(spinner, activity, Arrays.asList(strArr), R.string.joystick_type);
            this.f7060g = (ImageView) activity.findViewById(i5);
            this.f7062i = (ImageView) activity.findViewById(i6);
            this.f7061h = (Spinner) activity.findViewById(i7);
            C2712m.m18a(this.f7061h, activity, Arrays.asList(activity.getString(R.string.joystick_behavior_return_to_zero), activity.getString(R.string.joystick_behavior_hold_position)), R.string.joystick_behavior1);
            this.f7063j = (Spinner) activity.findViewById(i8);
            C2712m.m18a(this.f7063j, activity, Arrays.asList(activity.getString(R.string.joystick_behavior_return_to_zero), activity.getString(R.string.joystick_behavior_hold_position)), R.string.joystick_behavior2);
            this.f7064k = (TextView) activity.findViewById(i9);
            this.f7065l = (LinearLayout) activity.findViewById(i10);
            this.f7066m = (LinearLayout) activity.findViewById(i13);
            this.f7055b.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    C2622b.this.m593a();
                }
            });
            this.f7057d.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i14, long j) {
                    C2622b.this.m588c();
                    C2622b.this.m586d();
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                }
            });
            this.f7057d.setSelection(2);
            this.f7059f.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i14, long j) {
                    C2622b.this.m590b();
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                }
            });
            m593a();
        }

        /* renamed from: b */
        public void m590b() {
            int i = EV3SettingsActivity.this.f7037D[this.f7059f.getSelectedItemPosition()] == 2 ? 8 : 0;
            this.f7064k.setVisibility(i);
            this.f7065l.setVisibility(i);
            this.f7066m.setVisibility(i);
            for (C2629d dVar : this.f7067n) {
                dVar.m575a((EV3SettingsActivity.this.f7037D[this.f7059f.getSelectedItemPosition()] == 1 || EV3SettingsActivity.this.f7037D[this.f7059f.getSelectedItemPosition()] == 3) ? false : true);
                dVar.m579a(EV3SettingsActivity.this.f7037D[this.f7059f.getSelectedItemPosition()]);
            }
        }

        /* renamed from: c */
        public void m588c() {
            int i;
            int i2 = 0;
            i2 = 8;
            switch (this.f7057d.getSelectedItemPosition()) {
                case 0:
                    i = 0;
                    i2 = 8;
                    break;
                case 1:
                    i = 8;
                    break;
                case 2:
                case 3:
                default:
                    i = 0;
                    break;
                case 4:
                case 5:
                case 6:
                    i2 = 8;
                    i = 8;
                    break;
            }
            if (this.f7057d.getVisibility() != 0) {
                i = 8;
            }
            this.f7060g.setVisibility(i2);
            this.f7061h.setVisibility(i2);
            this.f7062i.setVisibility(i);
            this.f7063j.setVisibility(i);
        }

        /* renamed from: d */
        public void m586d() {
            String str = "";
            switch (this.f7057d.getSelectedItemPosition()) {
                case 0:
                case 5:
                    str = this.f7054a == 0 ? "y" : this.f7054a == 1 ? "z" : this.f7054a == 2 ? "b" : "d";
                    break;
                case 1:
                case 6:
                    str = this.f7054a == 0 ? "x" : this.f7054a == 1 ? "w" : this.f7054a == 2 ? "a" : "c";
                    break;
                case 2:
                case 3:
                case 4:
                    str = this.f7054a == 0 ? "x, y" : this.f7054a == 1 ? "w, z" : this.f7054a == 2 ? "a, b" : "c, d";
                    break;
            }
            int selectedItemPosition = this.f7059f.getSelectedItemPosition();
            C2701d dVar = (C2701d) this.f7059f.getAdapter();
            dVar.m57b().set(3, dVar.m59a().getString(R.string.joystick_type_mailbox) + " (" + str + ")");
            this.f7059f.setAdapter((SpinnerAdapter) dVar);
            this.f7059f.setSelection(selectedItemPosition);
        }
    }

    @SuppressWarnings("ALL")
    public class C2626c {

        /* renamed from: A */
        Button f7073A;

        /* renamed from: B */
        Button f7074B;

        /* renamed from: C */
        public List<C2629d> f7075C = new ArrayList();

        /* renamed from: E */
        private Activity f7077E;

        /* renamed from: a */
        int f7078a;

        /* renamed from: b */
        LinearLayout f7079b;

        /* renamed from: c */
        LinearLayout f7080c;

        /* renamed from: d */
        LinearLayout f7081d;

        /* renamed from: e */
        LinearLayout f7082e;

        /* renamed from: f */
        TextView f7083f;

        /* renamed from: g */
        TextView f7084g;

        /* renamed from: h */
        CheckBox f7085h;

        /* renamed from: i */
        LinearLayout f7086i;

        /* renamed from: j */
        Spinner f7087j;

        /* renamed from: k */
        Spinner f7088k;

        /* renamed from: l */
        Spinner f7089l;

        /* renamed from: m */
        LinearLayout f7090m;

        /* renamed from: n */
        LinearLayout f7091n;

        /* renamed from: o */
        EditText f7092o;

        /* renamed from: p */
        EditText f7093p;

        /* renamed from: q */
        EditText f7094q;

        /* renamed from: r */
        EditText f7095r;

        /* renamed from: s */
        EditText f7096s;

        /* renamed from: t */
        EditText f7097t;

        /* renamed from: u */
        EditText f7098u;

        /* renamed from: v */
        C2704f f7099v;

        /* renamed from: w */
        C2704f f7100w;

        /* renamed from: x */
        C2704f f7101x;

        /* renamed from: y */
        C2704f f7102y;

        /* renamed from: z */
        C2704f f7103z;

        C2626c(EV3SettingsActivity eV3SettingsActivity, LinearLayout linearLayout, int i, boolean z, int i2, int i3, int i4, int i5, int i6, int i7, int i8, HashSet<Integer> hashSet, HashSet<Integer> hashSet2, HashSet<Integer> hashSet3, HashSet<Integer> hashSet4, HashSet<Integer> hashSet5, String str, int i9, int i10) {
            this.f7077E = null;
            this.f7077E = eV3SettingsActivity;
            this.f7078a = i;
            this.f7082e = linearLayout;
            this.f7079b = new LinearLayout(eV3SettingsActivity);
            this.f7079b.setOrientation(1);
            linearLayout.addView(this.f7079b);
            this.f7083f = new TextView(new ContextThemeWrapper(eV3SettingsActivity, (int) R.style.SettingsSectionTitle));
            this.f7083f.setText(EV3SettingsActivity.this.getString(R.string.keygroup_n, new Object[]{Integer.toString(i + 1)}));
            this.f7079b.addView(this.f7083f);
            this.f7085h = C2712m.m19a(eV3SettingsActivity, this.f7079b, z, (int) R.string.keygroup_active, EV3SettingsActivity.this.f7041q);
            this.f7086i = new LinearLayout(eV3SettingsActivity);
            if (!z) {
                this.f7086i.setVisibility(8);
            }
            this.f7086i.setOrientation(1);
            this.f7079b.addView(this.f7086i);
            C2712m.m26a(eV3SettingsActivity, this.f7086i);
            this.f7087j = C2712m.m20a(eV3SettingsActivity, this.f7086i, Arrays.asList(eV3SettingsActivity.getString(R.string.joystick_type_independent_motors), eV3SettingsActivity.getString(R.string.keygroup_type_steering), eV3SettingsActivity.getString(R.string.joystick_type_mailbox)), i2 > 2 ? 2 : i2, R.string.joystick_type, null);
            this.f7090m = new LinearLayout(eV3SettingsActivity);
            this.f7090m.setVisibility(i2 != 2 ? 0 : 8);
            this.f7090m.setOrientation(1);
            this.f7086i.addView(this.f7090m);
            C2712m.m26a(eV3SettingsActivity, this.f7090m);
            this.f7088k = C2712m.m20a(eV3SettingsActivity, this.f7090m, Arrays.asList(eV3SettingsActivity.getString(R.string.joystick_behavior_return_to_zero), eV3SettingsActivity.getString(R.string.joystick_behavior_hold_position)), i9, R.string.keygroup_behavior1, null);
            C2712m.m26a(eV3SettingsActivity, this.f7090m);
            this.f7089l = C2712m.m20a(eV3SettingsActivity, this.f7090m, Arrays.asList(eV3SettingsActivity.getString(R.string.joystick_behavior_return_to_zero), eV3SettingsActivity.getString(R.string.joystick_behavior_hold_position)), i10, R.string.keygroup_behavior2, null);
            C2712m.m26a(eV3SettingsActivity, this.f7090m);
            this.f7092o = C2712m.m23a((Activity) eV3SettingsActivity, this.f7090m, i3, (int) R.string.inc_x, (int) R.string.inc_x_desc);
            C2712m.m26a(eV3SettingsActivity, this.f7090m);
            this.f7093p = C2712m.m23a((Activity) eV3SettingsActivity, this.f7090m, i4, (int) R.string.inc_y, (int) R.string.inc_y_desc);
            C2712m.m26a(eV3SettingsActivity, this.f7090m);
            this.f7094q = C2712m.m23a((Activity) eV3SettingsActivity, this.f7090m, i5, (int) R.string.dec_x, (int) R.string.dec_x_desc);
            C2712m.m26a(eV3SettingsActivity, this.f7090m);
            this.f7095r = C2712m.m23a((Activity) eV3SettingsActivity, this.f7090m, i6, (int) R.string.dec_y, (int) R.string.dec_y_desc);
            C2712m.m26a(eV3SettingsActivity, this.f7090m);
            this.f7096s = C2712m.m23a((Activity) eV3SettingsActivity, this.f7090m, i7, (int) R.string.step_x_pause, 0);
            C2712m.m26a(eV3SettingsActivity, this.f7090m);
            this.f7097t = C2712m.m23a((Activity) eV3SettingsActivity, this.f7090m, i8, (int) R.string.step_y_pause, 0);
            C2712m.m26a(eV3SettingsActivity, this.f7090m);
            this.f7099v = C2704f.m53a(eV3SettingsActivity, this.f7090m, hashSet, R.string.up_keys, m584a());
            this.f7099v.setOnClickListener(eV3SettingsActivity);
            C2712m.m26a(eV3SettingsActivity, this.f7090m);
            this.f7100w = C2704f.m53a(eV3SettingsActivity, this.f7090m, hashSet2, R.string.left_keys, m584a());
            this.f7100w.setOnClickListener(eV3SettingsActivity);
            C2712m.m26a(eV3SettingsActivity, this.f7090m);
            this.f7101x = C2704f.m53a(eV3SettingsActivity, this.f7090m, hashSet3, R.string.down_keys, m584a());
            this.f7101x.setOnClickListener(eV3SettingsActivity);
            C2712m.m26a(eV3SettingsActivity, this.f7090m);
            this.f7102y = C2704f.m53a(eV3SettingsActivity, this.f7090m, hashSet4, R.string.right_keys, m584a());
            this.f7102y.setOnClickListener(eV3SettingsActivity);
            this.f7084g = new TextView(new ContextThemeWrapper(eV3SettingsActivity, (int) R.style.SettingsSectionTitle));
            this.f7084g.setText(EV3SettingsActivity.this.getString(R.string.keygroup_ports, new Object[]{Integer.valueOf(i + 1)}));
            this.f7090m.addView(this.f7084g);
            this.f7080c = new LinearLayout(eV3SettingsActivity);
            this.f7080c.setOrientation(0);
            this.f7080c.setLayoutParams(new ViewGroup.LayoutParams(-1, -2));
            this.f7080c.setBaselineAligned(false);
            this.f7080c.setGravity(5);
            this.f7090m.addView(this.f7080c);
            this.f7074B = C2712m.m14c(eV3SettingsActivity, this.f7080c, R.string.delete);
            this.f7074B.setTag(new C2621a(this, false));
            this.f7074B.setOnClickListener(eV3SettingsActivity);
            EV3SettingsActivity.this.registerForContextMenu(this.f7074B);
            C2712m.m16b(eV3SettingsActivity, this.f7080c);
            this.f7073A = C2712m.m14c(eV3SettingsActivity, this.f7080c, R.string.add);
            this.f7073A.setTag(new C2621a(this, true));
            this.f7073A.setOnClickListener(eV3SettingsActivity);
            this.f7081d = new LinearLayout(eV3SettingsActivity);
            this.f7081d.setLayoutParams(new ViewGroup.LayoutParams(-1, -2));
            this.f7081d.setOrientation(1);
            this.f7090m.addView(this.f7081d);
            this.f7091n = new LinearLayout(eV3SettingsActivity);
            this.f7091n.setVisibility(i2 == 2 ? 0 : 8);
            this.f7091n.setOrientation(1);
            this.f7086i.addView(this.f7091n);
            C2712m.m26a(eV3SettingsActivity, this.f7091n);
            this.f7098u = C2712m.m21a(eV3SettingsActivity, this.f7091n, str, (int) R.string.mailbox, 0);
            C2712m.m26a(eV3SettingsActivity, this.f7091n);
            this.f7103z = C2704f.m53a(eV3SettingsActivity, this.f7091n, hashSet5, R.string.keys, m584a());
            this.f7103z.setOnClickListener(eV3SettingsActivity);
            this.f7085h.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean z2) {
                    C2626c.this.f7086i.setVisibility(z2 ? 0 : 8);
                }
            });
            this.f7087j.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i11, long j) {
                    int i12 = 0;
                    C2626c.this.f7090m.setVisibility(i11 != 2 ? 0 : 8);
                    LinearLayout linearLayout2 = C2626c.this.f7091n;
                    if (i11 != 2) {
                        i12 = 8;
                    }
                    linearLayout2.setVisibility(i12);
                    for (C2629d dVar : C2626c.this.f7075C) {
                        dVar.m579a(C2626c.this.f7087j.getSelectedItemPosition());
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                }
            });
        }

        /* renamed from: a */
        public String m584a() {
            return this.f7083f.getText().toString();
        }

        /* renamed from: a */
        public C2704f m582a(String str) {
            if (this.f7099v.getTitle().equals(str)) {
                return this.f7099v;
            }
            if (this.f7100w.getTitle().equals(str)) {
                return this.f7100w;
            }
            if (this.f7101x.getTitle().equals(str)) {
                return this.f7101x;
            }
            if (this.f7102y.getTitle().equals(str)) {
                return this.f7102y;
            }
            if (this.f7103z.getTitle().equals(str)) {
                return this.f7103z;
            }
            return null;
        }

        /* renamed from: a */
        public void m583a(int i) {
            this.f7078a = i;
            this.f7083f.setText(EV3SettingsActivity.this.getString(R.string.keygroup_n, new Object[]{Integer.toString(i + 1)}));
            this.f7084g.setText(EV3SettingsActivity.this.getString(R.string.keygroup_ports, new Object[]{Integer.valueOf(i + 1)}));
            for (int i2 = 0; i2 < this.f7075C.size(); i2++) {
                this.f7075C.get(i2).m573b(i);
            }
        }

        /* renamed from: b */
        public void m581b() {
            this.f7082e.removeView(this.f7079b);
        }
    }

    @SuppressWarnings("ALL")
    public class C2629d {

        /* renamed from: a */
        int f7108a;

        /* renamed from: b */
        boolean f7109b;

        /* renamed from: c */
        LinearLayout f7110c;

        /* renamed from: d */
        LinearLayout f7111d;

        /* renamed from: e */
        TextView f7112e;

        /* renamed from: f */
        Spinner f7113f;

        /* renamed from: g */
        Spinner f7114g;

        /* renamed from: h */
        Spinner f7115h;

        /* renamed from: i */
        Spinner f7116i;

        /* renamed from: j */
        CheckBox f7117j;

        /* renamed from: k */
        EditText f7118k;

        /* renamed from: l */
        TextView f7119l;

        /* renamed from: m */
        EditText f7120m;

        /* renamed from: n */
        CheckBox f7121n;

        /* renamed from: o */
        ImageView f7122o;

        /* renamed from: p */
        ImageView f7123p;

        /* renamed from: q */
        LinearLayout f7124q;

        public C2629d(Activity activity, LinearLayout linearLayout, int i, int i2, int i3, String str, int i4, int i5, boolean z, float f, int i6, int i7, boolean z2) {
            this.f7109b = z2;
            this.f7108a = i;
            this.f7110c = linearLayout;
            this.f7111d = new LinearLayout(activity);
            this.f7111d.setOrientation(1);
            linearLayout.addView(this.f7111d);
            this.f7112e = new TextView(new ContextThemeWrapper(activity, (int) R.style.SettingsSectionTitle));
            if (z2) {
                this.f7112e.setText(EV3SettingsActivity.this.getString(R.string.joystick_n_port_n, new Object[]{Integer.valueOf(i + 1), str}));
            } else {
                this.f7112e.setText(EV3SettingsActivity.this.getString(R.string.keygroup_n_port_n, new Object[]{Integer.valueOf(i + 1), str}));
            }
            this.f7111d.addView(this.f7112e);
            LinearLayout linearLayout2 = this.f7111d;
            String[] strArr = new String[2];
            strArr[0] = activity.getString(i7 == 0 ? R.string.joystick_group_horizontal : R.string.joystick_group_left);
            strArr[1] = activity.getString(i7 == 0 ? R.string.joystick_group_vertical : R.string.joystick_group_right);
            this.f7113f = C2712m.m20a(activity, linearLayout2, Arrays.asList(strArr), i2, i7 == 0 ? R.string.joystick_group_axis : R.string.joystick_group_motor, null);
            C2712m.m26a(activity, this.f7111d);
            this.f7114g = C2712m.m20a(activity, this.f7111d, Arrays.asList("1", "2", "3", "4"), i3, R.string.joystick_layer, null);
            C2712m.m26a(activity, this.f7111d);
            this.f7115h = C2712m.m20a(activity, this.f7111d, Arrays.asList("A", "B", "C", "D"), str.equals("A") ? 0 : str.equals("B") ? 1 : str.equals("C") ? 2 : 3, R.string.joystick_port_number, null);
            this.f7115h.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i8, long j) {
                    C2629d.this.m573b(-1);
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                }
            });
            C2712m.m26a(activity, this.f7111d);
            LinearLayout[] linearLayoutArr = new LinearLayout[1];
            this.f7116i = C2712m.m20a(activity, this.f7111d, Arrays.asList(activity.getString(R.string.joystick_type_power), activity.getString(R.string.joystick_type_angle)), i4, R.string.joystick_type_cv, linearLayoutArr);
            this.f7124q = linearLayoutArr[0];
            this.f7123p = C2712m.m26a(activity, this.f7111d);
            m575a((i7 == 1 || i7 == 3) ? false : true);
            this.f7119l = C2712m.m24a(activity, this.f7111d, (int) R.string.joystick_power);
            this.f7120m = C2712m.m23a(activity, this.f7111d, i5, 0, 0);
            this.f7122o = C2712m.m26a(activity, this.f7111d);
            this.f7117j = C2712m.m19a(activity, this.f7111d, z, (int) R.string.joystick_invert, EV3SettingsActivity.this.f7041q);
            C2712m.m26a(activity, this.f7111d);
            this.f7121n = C2712m.m19a(activity, this.f7111d, i6 == 1, (int) R.string.joystick_brake, EV3SettingsActivity.this.f7041q);
            C2712m.m26a(activity, this.f7111d);
            this.f7118k = C2712m.m25a(activity, this.f7111d, f, (int) R.string.joystick_coefficient, 0);
            this.f7116i.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i8, long j) {
                    C2629d.this.m574b();
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                }
            });
            m574b();
        }

        /* renamed from: a */
        public void m575a(boolean z) {
            int i = z ? 0 : 8;
            this.f7124q.setVisibility(i);
            this.f7123p.setVisibility(i);
        }

        /* renamed from: b */
        public void m574b() {
            int i = this.f7116i.getSelectedItemPosition() == 1 ? 0 : 8;
            this.f7120m.setVisibility(i);
            this.f7119l.setVisibility(i);
            this.f7122o.setVisibility(i);
        }

        /* renamed from: b */
        public void m573b(int i) {
            if (i >= 0) {
                this.f7108a = i;
            }
            if (this.f7109b) {
                this.f7112e.setText(EV3SettingsActivity.this.getString(R.string.joystick_n_port_n, new Object[]{Integer.valueOf(this.f7108a + 1), new String[]{"A", "B", "C", "D"}[this.f7115h.getSelectedItemPosition()]}));
            } else {
                this.f7112e.setText(EV3SettingsActivity.this.getString(R.string.keygroup_n_port_n, new Object[]{Integer.valueOf(this.f7108a + 1), new String[]{"A", "B", "C", "D"}[this.f7115h.getSelectedItemPosition()]}));
            }
        }

        /* renamed from: a */
        public void m580a() {
            this.f7110c.removeView(this.f7111d);
        }

        /* renamed from: a */
        public void m579a(int i) {
            int selectedItemPosition = this.f7113f.getSelectedItemPosition();
            C2701d dVar = (C2701d) this.f7113f.getAdapter();
            dVar.m58a(i == 0 ? this.f7109b ? R.string.joystick_group_axis : R.string.keyboard_group_axis : R.string.joystick_group_motor);
            dVar.m57b().set(0, dVar.m59a().getString(i == 0 ? this.f7109b ? R.string.joystick_group_horizontal : R.string.keygroup_horizontal : R.string.joystick_group_left));
            dVar.m57b().set(1, dVar.m59a().getString(i == 0 ? this.f7109b ? R.string.joystick_group_vertical : R.string.keygroup_vertical : R.string.joystick_group_right));
            this.f7113f.setAdapter((SpinnerAdapter) dVar);
            this.f7113f.setSelection(selectedItemPosition);
        }
    }

    /* renamed from: a */
    private String m601a(boolean z, boolean z2) {
        File file = null;
        String str;
        (z ? new File(Environment.getExternalStorageDirectory(), ".robocam") : Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)).mkdirs();
        String str2 = "RoboCam_";
        String obj = this.f7042r.getText().toString();
        if (obj != null && !obj.isEmpty()) {
            str2 = str2 + obj.replace("\\", "_").replace("/", "_").replace(":", "_").replace(" ", "_") + "_";
        }
        String str3 = str2 + new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(new Date());
        if (z2 || !new File(file.getPath() + "/" + str3 + ".xml").exists()) {
            str = str3;
        } else {
            int i = 2;
            while (new File(file.getPath() + "/" + str3 + "_" + Integer.toString(i) + ".xml").exists()) {
                i++;
            }
            str = str3 + "_" + Integer.toString(i);
        }
        String str4 = file.getPath() + "/" + str + ".xml";
        C2714o.m1a(str4, m595n());
        return str4;
    }

    /* renamed from: a */
    private HashSet<Integer> m604a(Element element, String str) {
        HashSet<Integer> hashSet = new HashSet<>();
        NodeList elementsByTagName = element.getElementsByTagName(str);
        for (int i = 0; i < elementsByTagName.getLength(); i++) {
            Integer valueOf = Integer.valueOf(((Element) elementsByTagName.item(i)).getTextContent());
            if (valueOf.intValue() > 0 && valueOf.intValue() <= 255) {
                hashSet.add(valueOf);
            }
        }
        return hashSet;
    }

    /* renamed from: a */
    private void m609a(File file) {
        try {
            m607a(DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(file));
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
    }

    /* renamed from: a */
    private void m608a(String str) {
        try {
            m607a(DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new InputSource(new StringReader(str))));
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
    }

    /* renamed from: a */
    private void m607a(Document document) {
        document.getDocumentElement().normalize();
        String nodeName = document.getDocumentElement().getNodeName();
        if (!nodeName.equals("EV3")) {
            try {
                throw new Exception(getString(R.string.unknown_driver_name, new Object[]{nodeName}));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        this.f7042r.setText(document.getDocumentElement().getAttribute("Name"));
        this.f7043s.setText(document.getDocumentElement().getAttribute("Description"));
        this.f7044t.setChecked(C2713n.m10a(document.getDocumentElement().getAttribute("ShowDebugInfo"), true));
        this.f7045u.setChecked(C2713n.m10a(document.getDocumentElement().getAttribute("HideJoysticks"), true));
        this.f7047w.setChecked(C2713n.m10a(document.getDocumentElement().getAttribute("StartUserProgram"), false));
        this.f7048x.setText(document.getDocumentElement().getAttribute("UserProgram"));
        NodeList elementsByTagName = document.getElementsByTagName("Joystick");
        for (int i = 0; i < this.f7039o.length; i++) {
            for (int i2 = 0; i2 < this.f7039o[i].f7067n.size(); i2++) {
                this.f7039o[i].f7067n.get(i2).m580a();
            }
            this.f7039o[i].f7067n.clear();
        }
        for (int i3 = 0; i3 < elementsByTagName.getLength(); i3++) {
            Element element = (Element) elementsByTagName.item(i3);
            int a = C2713n.m12a(element.getAttribute("Index"), -1);
            if (a >= 0 && a < 4) {
                C2622b bVar = this.f7039o[a];
                bVar.f7055b.setChecked(C2713n.m10a(element.getAttribute("Visible"), false));
                String a2 = C2713n.m11a(element.getAttribute("Shape"), "c");
                if (a2.equals("v")) {
                    bVar.f7057d.setSelection(0);
                } else if (a2.equals("h")) {
                    bVar.f7057d.setSelection(1);
                } else if (a2.equals("c")) {
                    bVar.f7057d.setSelection(2);
                } else if (a2.equals("q")) {
                    bVar.f7057d.setSelection(3);
                } else if (a2.equals("a")) {
                    bVar.f7057d.setSelection(4);
                } else if (a2.equals("l")) {
                    bVar.f7057d.setSelection(5);
                } else if (a2.equals("t")) {
                    bVar.f7057d.setSelection(6);
                }
                bVar.f7059f.setSelection(this.f7037D[C2713n.m12a(element.getAttribute("Type"), 0)]);
                bVar.f7061h.setSelection(C2713n.m12a(element.getAttribute("Behavior0"), 0));
                bVar.f7063j.setSelection(C2713n.m12a(element.getAttribute("Behavior1"), 0));
                m603a(element, bVar.f7067n, bVar.f7059f, bVar.f7065l, a, true);
            }
        }
        NodeList elementsByTagName2 = document.getElementsByTagName("KeyGroup");
        for (int i4 = 0; i4 < elementsByTagName2.getLength(); i4++) {
            Element element2 = (Element) elementsByTagName2.item(i4);
            this.f7040p.add(new C2626c(this, (LinearLayout) findViewById(R.id.linearLayoutKeyGroups), this.f7040p.size(), C2713n.m10a(element2.getAttribute("Active"), false), C2713n.m12a(element2.getAttribute("Type"), 0), C2713n.m12a(element2.getAttribute("IncX"), 0), C2713n.m12a(element2.getAttribute("IncY"), 0), C2713n.m12a(element2.getAttribute("DecX"), 0), C2713n.m12a(element2.getAttribute("DecY"), 0), C2713n.m12a(element2.getAttribute("StepXPause"), 100), C2713n.m12a(element2.getAttribute("StepYPause"), 100), m604a(element2, "UpKey"), m604a(element2, "LeftKey"), m604a(element2, "DownKey"), m604a(element2, "RightKey"), m604a(element2, "Key"), C2713n.m11a(element2.getAttribute("Mailbox"), ""), C2713n.m12a(element2.getAttribute("Behavior0"), 0), C2713n.m12a(element2.getAttribute("Behavior1"), 0)));
            C2626c cVar = this.f7040p.get(this.f7040p.size() - 1);
            m603a(element2, cVar.f7075C, cVar.f7087j, cVar.f7081d, this.f7040p.size() - 1, false);
        }
    }

    /* renamed from: a */
    private void m606a(Document document, Element element, List<C2629d> list) {
        for (C2629d dVar : list) {
            Element createElement = document.createElement("OutputPort");
            element.appendChild(createElement);
            createElement.setAttribute("Group", Integer.toString(dVar.f7113f.getSelectedItemPosition()));
            createElement.setAttribute("Layer", Integer.toString(dVar.f7114g.getSelectedItemPosition()));
            createElement.setAttribute("Number", new String[]{"A", "B", "C", "D"}[dVar.f7115h.getSelectedItemPosition()]);
            if (dVar.f7116i.getSelectedItemPosition() != C2687c.f7455a) {
                createElement.setAttribute("JoystickType", Integer.toString(dVar.f7116i.getSelectedItemPosition()));
            }
            if (!dVar.f7120m.getText().toString().equals("0")) {
                createElement.setAttribute("Power", dVar.f7120m.getText().toString());
            }
            if (dVar.f7117j.isChecked()) {
                createElement.setAttribute("Invert", "1");
            }
            if (!dVar.f7118k.getText().toString().equals("1.0")) {
                createElement.setAttribute("Coefficient", dVar.f7118k.getText().toString());
            }
            if (!dVar.f7121n.isChecked()) {
                createElement.setAttribute("Brake", "0");
            }
        }
    }

    /* renamed from: a */
    private void m605a(Document document, Element element, C2704f fVar, String str) {
        if (fVar.f7560a != null) {
            Iterator<Integer> it = fVar.f7560a.iterator();
            while (it.hasNext()) {
                Element createElement = document.createElement(str);
                element.appendChild(createElement);
                createElement.setTextContent(it.next().toString());
            }
        }
    }

    /* renamed from: a */
    private void m603a(Element element, List<C2629d> list, Spinner spinner, LinearLayout linearLayout, int i, boolean z) {
        NodeList elementsByTagName = element.getElementsByTagName("OutputPort");
        for (int i2 = 0; i2 < elementsByTagName.getLength(); i2++) {
            Element element2 = (Element) elementsByTagName.item(i2);
            int a = C2713n.m12a(element2.getAttribute("Group"), -1);
            int a2 = C2713n.m12a(element2.getAttribute("Layer"), -1);
            String a3 = C2713n.m11a(element2.getAttribute("Number"), "");
            char c = 65535;
            if (a3.equals("A")) {
                c = 1;
            } else if (a3.equals("B")) {
                c = 2;
            } else if (a3.equals("C")) {
                c = 4;
            } else if (a3.equals("D")) {
                c = '\b';
            }
            if (a >= 0 && a <= 1 && a2 >= 0 && a2 < 4 && c >= 0) {
                try {
                    list.add(new C2629d(this, linearLayout, i, a, a2, a3, C2713n.m12a(element2.getAttribute("JoystickType"), C2687c.f7455a), C2713n.m12a(element2.getAttribute("Power"), 0), C2713n.m10a(element2.getAttribute("Invert"), false), C2713n.m13a(element2.getAttribute("Coefficient"), 1.0f), C2713n.m12a(element2.getAttribute("Brake"), 1), this.f7037D[spinner.getSelectedItemPosition()], z));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /* renamed from: j */
    private File m599j() {
        return new File(C2714o.m6a(this), this.f7038n);
    }

    /* renamed from: k */
    private void m598k() {
        try {
            Document n = m595n();
            n.getDocumentElement().setAttribute("Name", C2714o.m5a(this, this.f7042r.getText().toString(), "EV3"));
            C2714o.m2a(new File(C2714o.m6a(this), "EV3_" + new SimpleDateFormat("yyyyMMddHHmmsszzz", Locale.ENGLISH).format(new Date()) + ".xml"), n);
            C2709k.m43a(new Date());
            Toast.makeText(this, getString(R.string.settings_ware_copied_successfully), 1).show();
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.error_while_copying_settings_xml, new Object[]{e.getLocalizedMessage()}), 1).show();
        }
    }

    /* renamed from: l */
    private void m597l() {
        if (C2714o.m9a(this, 1)) {
            try {
                C2714o.m7a((Activity) this, getString(R.string.settings_ware_exported_successfully, new Object[]{m601a(false, false)}), false);
            } catch (Exception e) {
                Toast.makeText(this, getString(R.string.error_while_exporting_settings_xml, new Object[]{e.getLocalizedMessage()}), 1).show();
            }
        }
    }

    /* renamed from: m */
    private void m596m() {
        if (C2714o.m9a(this, 2)) {
            try {
                String a = m601a(true, true);
                Intent intent = new Intent();
                intent.setAction("android.intent.action.SEND");
                intent.setType("text/xml");
                intent.putExtra("android.intent.extra.STREAM", Uri.fromFile(new File(a)));
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, getString(R.string.error_while_exporting_settings_xml, new Object[]{e.getLocalizedMessage()}), 1).show();
            }
        }
    }

    /* renamed from: n */
    private Document m595n() {
        C2622b[] bVarArr;
        Document newDocument = null;
        try {
            newDocument = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
        newDocument.appendChild(newDocument.createElement("EV3"));
        Element documentElement = newDocument.getDocumentElement();
        documentElement.setAttribute("Name", this.f7042r.getText().toString());
        documentElement.setAttribute("Description", this.f7043s.getText().toString());
        if (!this.f7044t.isChecked()) {
            documentElement.setAttribute("ShowDebugInfo", "0");
        }
        if (!this.f7045u.isChecked()) {
            documentElement.setAttribute("HideJoysticks", "0");
        }
        if (this.f7047w.isChecked()) {
            documentElement.setAttribute("StartUserProgram", "1");
        }
        if (this.f7048x.getText().toString() != null && !this.f7048x.getText().toString().equals("")) {
            documentElement.setAttribute("UserProgram", this.f7048x.getText().toString());
        }
        int i = 0;
        for (C2622b bVar : this.f7039o) {
            Element createElement = newDocument.createElement("Joystick");
            documentElement.appendChild(createElement);
            createElement.setAttribute("Index", Integer.toString(i));
            if (bVar.f7055b.isChecked()) {
                createElement.setAttribute("Visible", "1");
            }
            switch (bVar.f7057d.getSelectedItemPosition()) {
                case 0:
                    createElement.setAttribute("Shape", "v");
                    break;
                case 1:
                    createElement.setAttribute("Shape", "h");
                    break;
                case 2:
                    if (bVar.f7055b.isChecked()) {
                        createElement.setAttribute("Shape", "c");
                        break;
                    }
                    break;
                case 3:
                    createElement.setAttribute("Shape", "q");
                    break;
                case 4:
                    createElement.setAttribute("Shape", "a");
                    break;
                case 5:
                    createElement.setAttribute("Shape", "l");
                    break;
                case 6:
                    createElement.setAttribute("Shape", "t");
                    break;
            }
            if (this.f7037D[bVar.f7059f.getSelectedItemPosition()] != 0 || bVar.f7055b.isChecked()) {
                createElement.setAttribute("Type", Integer.toString(this.f7037D[bVar.f7059f.getSelectedItemPosition()]));
            }
            if (bVar.f7061h.getSelectedItemPosition() != 0) {
                createElement.setAttribute("Behavior0", Integer.toString(bVar.f7061h.getSelectedItemPosition()));
            }
            if (bVar.f7063j.getSelectedItemPosition() != 0) {
                createElement.setAttribute("Behavior1", Integer.toString(bVar.f7063j.getSelectedItemPosition()));
            }
            m606a(newDocument, createElement, bVar.f7067n);
            i++;
        }
        for (C2626c cVar : this.f7040p) {
            Element createElement2 = newDocument.createElement("KeyGroup");
            documentElement.appendChild(createElement2);
            if (cVar.f7087j.getSelectedItemPosition() != 0) {
                createElement2.setAttribute("Type", Integer.toString(cVar.f7087j.getSelectedItemPosition()));
            }
            if (cVar.f7085h.isChecked()) {
                createElement2.setAttribute("Active", "1");
            }
            if (!"".equals(cVar.f7098u.getText().toString())) {
                createElement2.setAttribute("Mailbox", cVar.f7098u.getText().toString());
            }
            if (cVar.f7088k.getSelectedItemPosition() != 0) {
                createElement2.setAttribute("Behavior0", Integer.toString(cVar.f7088k.getSelectedItemPosition()));
            }
            if (cVar.f7089l.getSelectedItemPosition() != 0) {
                createElement2.setAttribute("Behavior1", Integer.toString(cVar.f7089l.getSelectedItemPosition()));
            }
            if (!"0".equals(cVar.f7092o.getText().toString()) && !"".equals(cVar.f7092o.getText().toString())) {
                createElement2.setAttribute("IncX", cVar.f7092o.getText().toString());
            }
            if (!"0".equals(cVar.f7093p.getText().toString()) && !"".equals(cVar.f7093p.getText().toString())) {
                createElement2.setAttribute("IncY", cVar.f7093p.getText().toString());
            }
            if (!"0".equals(cVar.f7094q.getText().toString()) && !"".equals(cVar.f7094q.getText().toString())) {
                createElement2.setAttribute("DecX", cVar.f7094q.getText().toString());
            }
            if (!"0".equals(cVar.f7095r.getText().toString()) && !"".equals(cVar.f7095r.getText().toString())) {
                createElement2.setAttribute("DecY", cVar.f7095r.getText().toString());
            }
            if (!"100".equals(cVar.f7096s.getText().toString()) && !"".equals(cVar.f7096s.getText().toString())) {
                createElement2.setAttribute("StepXPause", cVar.f7096s.getText().toString());
            }
            if (!"100".equals(cVar.f7097t.getText().toString()) && !"".equals(cVar.f7097t.getText().toString())) {
                createElement2.setAttribute("StepYPause", cVar.f7097t.getText().toString());
            }
            m605a(newDocument, createElement2, cVar.f7099v, "UpKey");
            m605a(newDocument, createElement2, cVar.f7100w, "LeftKey");
            m605a(newDocument, createElement2, cVar.f7101x, "DownKey");
            m605a(newDocument, createElement2, cVar.f7102y, "RightKey");
            m605a(newDocument, createElement2, cVar.f7103z, "Key");
            m606a(newDocument, createElement2, cVar.f7075C);
        }
        return newDocument;
    }

    /* renamed from: o */
    private String m594o() {
        try {
            DOMSource dOMSource = new DOMSource(m595n());
            StringWriter stringWriter = new StringWriter();
            TransformerFactory.newInstance().newTransformer().transform(dOMSource, new StreamResult(stringWriter));
            return stringWriter.toString();
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.error_while_creating_settings_xml, new Object[]{e.getLocalizedMessage()}), 1).show();
            return null;
        }
    }

    @Override
    protected void onActivityResult(int i, int i2, Intent intent) {
        if (i2 == -1) {
            switch (i) {
                case 1:
                    String stringExtra = intent.getStringExtra("android.intent.extra.remote_intent_token");
                    String stringExtra2 = intent.getStringExtra("android.intent.extra.TEXT");
                    for (C2626c cVar : this.f7040p) {
                        if (cVar.m584a().equals(stringExtra)) {
                            C2704f a = cVar.m582a(stringExtra2);
                            if (a != null) {
                                a.m51a(this, intent.getIntArrayExtra("android.intent.extra.STREAM"));
                                return;
                            }
                            return;
                        }
                    }
                    return;
                default:
                    return;
            }
        }
    }

    public void onAddKeyGroupButtonClick(View view) {
        try {
            this.f7040p.add(new C2626c(this, (LinearLayout) findViewById(R.id.linearLayoutKeyGroups), this.f7040p.size(), true, 0, 0, 0, 0, 0, 100, 100, null, null, null, null, null, "", 0, 0));
            Toast.makeText(this, getString(R.string.keygroup_has_been_added), 1).show();
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.error_while_creating_settings_xml, new Object[]{e.getLocalizedMessage()}), 1).show();
        }
    }

    public void onAddPortButtonClick(View view) {
        int i = -1;
        if (view.getId() == R.id.buttonAddPortJoystick1) {
            i = 0;
        } else if (view.getId() == R.id.buttonAddPortJoystick2) {
            i = 1;
        } else if (view.getId() == R.id.buttonAddPortJoystick3) {
            i = 2;
        } else if (view.getId() == R.id.buttonAddPortJoystick4) {
            i = 3;
        }
        if (i >= 0) {
            try {
                this.f7039o[i].f7067n.add(new C2629d(this, this.f7039o[i].f7065l, i, 0, 0, "A", C2687c.f7455a, 0, false, 1.0f, 1, this.f7037D[this.f7039o[i].f7059f.getSelectedItemPosition()], true));
                Toast.makeText(this, getString(R.string.port_has_been_added), 1).show();
            } catch (Exception e) {
                Toast.makeText(this, getString(R.string.error_while_creating_settings_xml, new Object[]{e.getLocalizedMessage()}), 1).show();
            }
        }
    }

    public void onCancelButtonClick(View view) {
        finish();
    }

    @Override
    public void onClick(View view) {
        char c = 65535;
        if (view.getId() == R.id.buttonDeletePortJoystick1) {
            c = 0;
        } else if (view.getId() == R.id.buttonDeletePortJoystick2) {
            c = 1;
        } else if (view.getId() == R.id.buttonDeletePortJoystick3) {
            c = 2;
        } else if (view.getId() == R.id.buttonDeletePortJoystick4) {
            c = 3;
        }
        if (c >= 0 && this.f7039o[c].f7067n.size() > 0) {
            view.showContextMenu();
        } else if (view.getId() == R.id.buttonOverflow) {
            view.showContextMenu();
        } else if (C2704f.class.isAssignableFrom(view.getClass())) {
            ((C2704f) view).m54a(this, 1);
        } else if (view.getTag() != null && C2621a.class.isAssignableFrom(view.getTag().getClass())) {
            try {
                C2621a aVar = (C2621a) view.getTag();
                if (aVar.f7052b) {
                    aVar.f7051a.f7075C.add(new C2629d(this, aVar.f7051a.f7081d, aVar.f7051a.f7078a, 0, 0, "A", C2687c.f7455a, 0, false, 1.0f, 1, this.f7037D[aVar.f7051a.f7087j.getSelectedItemPosition()], false));
                    Toast.makeText(this, getString(R.string.port_has_been_added), 1).show();
                } else {
                    view.showContextMenu();
                }
            } catch (Exception e) {
                Toast.makeText(this, getString(R.string.error_while_creating_settings_xml, new Object[]{e.getLocalizedMessage()}), 1).show();
            }
        }
    }

    @Override
    public boolean onContextItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() > 1000000 && menuItem.getItemId() / 1000000 <= 4) {
            int itemId = (menuItem.getItemId() / 1000000) - 1;
            int itemId2 = (menuItem.getItemId() - ((itemId + 1) * 1000000)) - 1;
            this.f7039o[itemId].f7067n.get(itemId2).m580a();
            this.f7039o[itemId].f7067n.remove(itemId2);
            Toast.makeText(this, (int) R.string.port_was_deleted, 1).show();
            return true;
        } else if (menuItem.getItemId() > 10000000) {
            int itemId3 = (menuItem.getItemId() / 10000000) - 1;
            int itemId4 = (menuItem.getItemId() - ((itemId3 + 1) * 10000000)) - 1;
            this.f7040p.get(itemId3).f7075C.get(itemId4).m580a();
            this.f7040p.get(itemId3).f7075C.remove(itemId4);
            Toast.makeText(this, (int) R.string.port_was_deleted, 1).show();
            return true;
        } else if (menuItem.getItemId() < -10) {
            int itemId5 = (menuItem.getItemId() * (-1)) - 11;
            this.f7040p.get(itemId5).m581b();
            this.f7040p.remove(itemId5);
            for (int i = 0; i < this.f7040p.size(); i++) {
                this.f7040p.get(i).m583a(i);
            }
            Toast.makeText(this, (int) R.string.keygroup_was_deleted, 1).show();
            return true;
        } else {
            if (menuItem.getItemId() == -2) {
                m596m();
            } else if (menuItem.getItemId() == -3) {
                m597l();
            } else if (menuItem.getItemId() == -4) {
                m598k();
            }
            return super.onContextItemSelected(menuItem);
        }
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_ev3_settings);
        this.f7046v = (ImageButton) findViewById(R.id.buttonOverflow);
        this.f7046v.setOnClickListener(this);
        registerForContextMenu(this.f7046v);
        this.f7036C = (Button) findViewById(R.id.buttonDeleteKeyGroup);
        registerForContextMenu(this.f7036C);
        if (Build.VERSION.SDK_INT < 17) {
            this.f7041q = new CheckBox(this).getPaddingLeft();
        }
        this.f7042r = (EditText) findViewById(R.id.editTextBotName);
        this.f7043s = (EditText) findViewById(R.id.editTextDesc);
        this.f7044t = (CheckBox) findViewById(R.id.checkBoxShowDebugInfo);
        this.f7045u = (CheckBox) findViewById(R.id.checkBoxHideJoysticks);
        this.f7047w = (CheckBox) findViewById(R.id.checkBoxStartUserProgram);
        this.f7048x = (EditText) findViewById(R.id.editTextUserProgram);
        this.f7038n = getIntent().getStringExtra("SettingsFileName");
        if (this.f7038n == null || this.f7038n.equals("")) {
            String string = bundle != null ? bundle.getString("SettingsFileName") : null;
            if (string == null || string.equals("")) {
                this.f7038n = "EV3_" + new SimpleDateFormat("yyyyMMddHHmmsszzz", Locale.ENGLISH).format(new Date()) + ".xml";
            } else {
                this.f7038n = string;
            }
        }
        for (int i = 0; i < 4; i++) {
            this.f7039o[i] = new C2622b(this, i);
        }
        String string2 = bundle != null ? bundle.getString("SettingsXml") : null;
        if (string2 == null || string2.equals("")) {
            File j = m599j();
            if (j.exists()) {
                try {
                    m609a(j);
                } catch (Exception e) {
                    Toast.makeText(this, getString(R.string.error_while_opening_settings_file, new Object[]{this.f7038n, e.getLocalizedMessage()}), 1).show();
                }
            }
        } else {
            try {
                m608a(string2);
            } catch (Exception e2) {
                Toast.makeText(this, getString(R.string.error_while_opening_settings, new Object[]{e2.getLocalizedMessage()}), 1).show();
            }
        }
        this.f7049y = (Button) findViewById(R.id.buttonDeletePortJoystick1);
        this.f7049y.setOnClickListener(this);
        registerForContextMenu(this.f7049y);
        this.f7050z = (Button) findViewById(R.id.buttonDeletePortJoystick2);
        this.f7050z.setOnClickListener(this);
        registerForContextMenu(this.f7050z);
        this.f7034A = (Button) findViewById(R.id.buttonDeletePortJoystick3);
        this.f7034A.setOnClickListener(this);
        registerForContextMenu(this.f7034A);
        this.f7035B = (Button) findViewById(R.id.buttonDeletePortJoystick4);
        this.f7035B.setOnClickListener(this);
        registerForContextMenu(this.f7035B);
    }

    @Override
    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        super.onCreateContextMenu(contextMenu, view, contextMenuInfo);
        int i = -1;
        if (view.getId() == R.id.buttonDeletePortJoystick1) {
            i = 0;
        } else if (view.getId() == R.id.buttonDeletePortJoystick2) {
            i = 1;
        } else if (view.getId() == R.id.buttonDeletePortJoystick3) {
            i = 2;
        } else if (view.getId() == R.id.buttonDeletePortJoystick4) {
            i = 3;
        }
        if (i >= 0) {
            for (int i2 = 0; i2 < this.f7039o[i].f7067n.size(); i2++) {
                contextMenu.add(0, ((i + 1) * 1000000) + i2 + 1, i2 + 1, this.f7039o[i].f7067n.get(i2).f7112e.getText());
            }
        } else if (view.getTag() != null && C2621a.class.isAssignableFrom(view.getTag().getClass())) {
            C2621a aVar = (C2621a) view.getTag();
            for (int i3 = 0; i3 < aVar.f7051a.f7075C.size(); i3++) {
                contextMenu.add(0, ((aVar.f7051a.f7078a + 1) * 10000000) + i3 + 1, i3 + 1, aVar.f7051a.f7075C.get(i3).f7112e.getText());
            }
        } else if (view.getId() == R.id.buttonDeleteKeyGroup) {
            for (int i4 = 0; i4 < this.f7040p.size(); i4++) {
                contextMenu.add(0, (i4 + 11) * (-1), i4 + 1, this.f7040p.get(i4).f7083f.getText());
            }
        } else {
            contextMenu.add(0, -2, 0, R.string.action_send_robot_settings);
            contextMenu.add(0, -3, 0, R.string.action_export_robot_settings_to_file);
            contextMenu.add(0, -4, 0, R.string.action_copy_robot_settings);
        }
    }

    public void onDeleteKeyGroupClick(View view) {
        view.showContextMenu();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != 1 && i != 2) {
            super.onRequestPermissionsResult(i, strArr, iArr);
        } else if (iArr.length != 1 || iArr[0] != 0) {
            C2714o.m8a((Activity) this, (int) R.string.request_write_external_storage_permission, false);
        } else if (i == 1) {
            m597l();
        } else if (i == 2) {
            m598k();
        }
    }

    @Override
    protected void onRestoreInstanceState(Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        this.f7038n = bundle.getString("SettingsFileName");
    }

    public void onSaveButtonClick(View view) {
        try {
            TransformerFactory.newInstance().newTransformer().transform(new DOMSource(m595n()), new StreamResult(new FileOutputStream(m599j())));
            C2709k.m43a(new Date());
            Toast.makeText(this, (int) R.string.settings_were_saved, 0).show();
            finish();
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.error_while_creating_settings_xml, new Object[]{e.getLocalizedMessage()}), 1).show();
        }
    }

    @Override
    public void onSaveInstanceState(Bundle bundle) {
        bundle.putString("SettingsFileName", this.f7038n);
        bundle.putString("SettingsXml", m594o());
        super.onSaveInstanceState(bundle);
    }
}
