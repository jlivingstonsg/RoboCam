package ru.proghouse.robocam;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.Fragment;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;

@TargetApi(11)
@SuppressWarnings("ALL")
public class DialogFragmentC2698c extends DialogFragment {
    @Override
    public Dialog onCreateDialog(Bundle bundle) {
        if (Build.VERSION.SDK_INT < 17) {
            return null;
        }
        final Fragment parentFragment = getParentFragment();
        return new AlertDialog.Builder(getActivity()).setMessage(getArguments().getInt("message_id")).setPositiveButton(17039370, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                try {
                    Bundle arguments = DialogFragmentC2698c.this.getArguments();
                    ActivityCompat.requestPermissions(DialogFragmentC2698c.this.getActivity(), arguments.getStringArray("permissions"), arguments.getInt("request_code"));
                } catch (Throwable th) {
                    th.printStackTrace();
                }
            }
        }).setNegativeButton(17039360, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                try {
                    if (DialogFragmentC2698c.this.getArguments().getBoolean("finish_activity")) {
                        Activity activity = null;
                        if (parentFragment != null) {
                            activity = parentFragment.getActivity();
                        }
                        if (activity == null) {
                            activity = DialogFragmentC2698c.this.getActivity();
                        }
                        if (activity != null) {
                            activity.finish();
                        }
                    }
                } catch (Throwable th) {
                    th.printStackTrace();
                }
            }
        }).create();
    }
}
