package ru.proghouse.robocam.p062a.p064b;

import java.util.List;

@SuppressWarnings("ALL")
public interface AbstractC2686b {
    /* renamed from: a */
    List<C2694g> mo136a(int i);
}
