package ru.proghouse.robocam;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.graphics.YuvImage;
import android.hardware.Camera;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.v4.app.ActivityCompat;
import android.util.Size;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.TextureView;
import android.view.View;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

@SuppressWarnings("ALL")
public class C2671a implements Camera.PreviewCallback {

    /* renamed from: c */
    private static C2671a f7364c = new C2671a();

    /* renamed from: d */
    private String f7386d = null;

    /* renamed from: e */
    private HttpServer f7387e = null;

    /* renamed from: f */
    private Camera f7388f = null;

    /* renamed from: g */
    private int f7389g = 0;

    /* renamed from: h */
    private int f7390h = -1;

    /* renamed from: i */
    private C2706h f7391i = null;

    /* renamed from: j */
    private boolean f7392j = false;

    /* renamed from: k */
    private volatile int f7393k = 0;

    /* renamed from: l */
    private int f7394l = 60;

    /* renamed from: m */
    private volatile int f7395m = -1;

    /* renamed from: n */
    private volatile int f7396n = -1;

    /* renamed from: o */
    private volatile SurfaceHolder f7397o = null;

    /* renamed from: p */
    private volatile boolean f7398p = false;

    /* renamed from: q */
    private volatile boolean f7399q = false;

    /* renamed from: a */
    int f7384a = -1;

    /* renamed from: b */
    int f7385b = -1;

    /* renamed from: r */
    private volatile boolean f7400r = false;

    /* renamed from: s */
    private CameraManager f7401s = null;

    /* renamed from: t */
    private String f7402t = "";

    /* renamed from: u */
    private int f7403u = 0;

    /* renamed from: v */
    private int f7404v = 0;

    /* renamed from: w */
    private C2706h[] f7405w = null;

    /* renamed from: x */
    private List<C2706h> f7406x = new ArrayList();

    /* renamed from: y */
    private CameraDevice.StateCallback f7407y = null;

    /* renamed from: z */
    private CameraDevice f7408z = null;

    /* renamed from: A */
    private CameraCaptureSession f7365A = null;

    /* renamed from: B */
    private CaptureRequest.Builder f7366B = null;

    /* renamed from: C */
    private CaptureRequest f7367C = null;

    /* renamed from: D */
    private CameraCaptureSession.CaptureCallback f7368D = null;

    /* renamed from: E */
    private Handler f7369E = null;

    /* renamed from: F */
    private HandlerThread f7370F = null;

    /* renamed from: G */
    private SurfaceTexture f7371G = null;

    /* renamed from: H */
    private ImageReader f7372H = null;

    /* renamed from: I */
    private ImageReader.OnImageAvailableListener f7373I = null;

    /* renamed from: J */
    private volatile boolean f7374J = true;

    /* renamed from: K */
    private AbstractC2676a f7375K = null;

    /* renamed from: L */
    private int f7376L = Integer.MIN_VALUE;

    /* renamed from: M */
    private C2708j[] f7377M = {new C2708j(), new C2708j(), new C2708j()};

    /* renamed from: N */
    private int f7378N = 1;

    /* renamed from: O */
    private int f7379O = 0;

    /* renamed from: P */
    private int f7380P = 0;

    /* renamed from: Q */
    private Object f7381Q = new Object();

    /* renamed from: R */
    private Object f7382R = new Object();

    /* renamed from: S */
    private int f7383S = 0;

    @SuppressWarnings("ALL")
    public interface AbstractC2676a {
        /* renamed from: a */
        Bitmap mo46a(byte[] bArr, byte[] bArr2, byte[] bArr3, int i, int i2, int i3, int i4, int i5);

        /* renamed from: a */
        void mo47a(Activity activity);
    }

    C2671a() {
    }

    /* renamed from: a */
    public static C2671a m379a() {
        return f7364c;
    }

    /* renamed from: a */
    public void m370a(Object obj) {
        if (Build.VERSION.SDK_INT >= 23 && obj != null) {
            Image image = (Image) obj;
            this.f7376L++;
            if (this.f7376L == Integer.MAX_VALUE) {
                this.f7376L = Integer.MIN_VALUE;
            }
            if (this.f7376L == 0) {
                this.f7376L++;
            }
            ByteBuffer buffer = image.getPlanes()[0].getBuffer();
            ByteBuffer buffer2 = image.getPlanes()[1].getBuffer();
            ByteBuffer buffer3 = image.getPlanes()[2].getBuffer();
            int remaining = buffer.remaining();
            if (this.f7377M[this.f7378N].f7576f == null || this.f7377M[this.f7378N].f7576f.length != remaining) {
                this.f7377M[this.f7378N].f7576f = new byte[remaining];
            }
            buffer.rewind();
            buffer.get(this.f7377M[this.f7378N].f7576f);
            int remaining2 = buffer2.remaining();
            if (this.f7377M[this.f7378N].f7577g == null || this.f7377M[this.f7378N].f7577g.length != remaining2) {
                this.f7377M[this.f7378N].f7577g = new byte[remaining2];
            }
            buffer2.rewind();
            buffer2.get(this.f7377M[this.f7378N].f7577g);
            int remaining3 = buffer3.remaining();
            if (this.f7377M[this.f7378N].f7578h == null || this.f7377M[this.f7378N].f7578h.length != remaining3) {
                this.f7377M[this.f7378N].f7578h = new byte[buffer3.remaining()];
            }
            buffer3.rewind();
            buffer3.get(this.f7377M[this.f7378N].f7578h);
            this.f7377M[this.f7378N].f7579i = image.getPlanes()[1].getRowStride();
            this.f7377M[this.f7378N].f7580j = image.getPlanes()[1].getPixelStride();
            this.f7377M[this.f7378N].f7581k = image.getPlanes()[2].getRowStride();
            this.f7377M[this.f7378N].f7582l = image.getPlanes()[2].getPixelStride();
            this.f7377M[this.f7378N].f7583m = image.getWidth();
            this.f7377M[this.f7378N].f7584n = image.getHeight();
            this.f7377M[this.f7378N].f7571a = true;
            this.f7377M[this.f7378N].f7586p = this.f7376L;
            synchronized (this.f7381Q) {
                this.f7379O = this.f7378N;
                this.f7378N++;
                if (this.f7378N >= this.f7377M.length) {
                    this.f7378N = 0;
                }
                if (this.f7378N == this.f7380P) {
                    this.f7378N++;
                    if (this.f7378N >= this.f7377M.length) {
                        this.f7378N = 0;
                    }
                }
            }
        }
    }

    /* renamed from: a */
    private void m363a(int[] iArr, byte[] bArr, byte[] bArr2, byte[] bArr3, int i, int i2, int i3, int i4, int i5) {
        int i6;
        int i7;
        int i8;
        if (i5 == 270 || i5 == 90) {
            i6 = i4;
            i4 = i3;
        } else {
            i6 = i3;
        }
        int i9 = 0;
        int i10 = 0;
        while (i9 < i4) {
            int i11 = 0;
            while (i11 < i6) {
                if (i5 == 180) {
                    i8 = (i6 - i11) - 1;
                    i7 = (i4 - i9) - 1;
                } else if (i5 == 90) {
                    i7 = (i6 - i11) - 1;
                    i8 = i9;
                } else if (i5 == 270) {
                    i8 = (i4 - i9) - 1;
                    i7 = i11;
                } else {
                    i7 = i9;
                    i8 = i11;
                }
                int i12 = bArr[(i7 * i3) + i8];
                if (i12 < 0) {
                    i12 += 256;
                }
                int i13 = ((i8 / 2) * i2) + ((i7 / 2) * i);
                int i14 = bArr2[i13];
                if (i14 < 0) {
                    i14 += 256;
                }
                int i15 = bArr3[i13];
                if (i15 < 0) {
                    i15 += 256;
                }
                int max = Math.max(0, Math.min(255, (int) (i12 + (1.402f * (i15 - 128.0f)))));
                iArr[i10] = (Math.max(0, Math.min(255, (int) (((i14 - 128.0f) * 1.772f) + i12))) & 255) | ((Math.max(0, Math.min(255, (int) ((i12 - (0.34414f * (i14 - 128.0f))) - ((i15 - 128.0f) * 0.71414f)))) << 8) & 65280) | ((max << 16) & 16711680) | (-16777216);
                i11++;
                i10++;
            }
            i9++;
            i10 = i10;
        }
    }

    /* renamed from: b */
    private int m361b(Activity activity) {
        int i;
        int i2 = 90;
        boolean z = false;
        synchronized (HttpServer.f7135a) {
            this.f7398p = false;
            this.f7399q = false;
            if ((this.f7388f == null || this.f7392j) && this.f7408z == null) {
                return this.f7395m;
            }
            int rotation = activity.getWindowManager().getDefaultDisplay().getRotation();
            switch (rotation) {
                case 0:
                    i = 0;
                    break;
                case 1:
                    i = 90;
                    break;
                case 2:
                    i = 180;
                    break;
                case 3:
                    i = 270;
                    break;
                default:
                    i = 0;
                    break;
            }
            if (Build.VERSION.SDK_INT >= 23) {
                if (this.f7404v == 0 || this.f7404v == 1) {
                    i2 = (360 - i) % 360;
                    if ((rotation == 1 || rotation == 3) && this.f7404v == 0) {
                        z = true;
                    }
                    this.f7399q = z;
                } else {
                    i2 = 0;
                }
            } else if (Build.VERSION.SDK_INT >= 9) {
                Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
                Camera.getCameraInfo(this.f7389g, cameraInfo);
                if (cameraInfo.facing == 1) {
                    i2 = (360 - ((cameraInfo.orientation + i) % 360)) % 360;
                    if (rotation == 0) {
                        z = true;
                    }
                    this.f7398p = z;
                } else {
                    i2 = ((cameraInfo.orientation - i) + 360) % 360;
                }
            } else if (activity.getResources().getConfiguration().orientation == 2) {
                i2 = i - 90;
            }
            this.f7396n = rotation;
            return i2;
        }
    }

    /* renamed from: p */
    private void m339p() {
        if (Build.VERSION.SDK_INT >= 23 && this.f7407y == null) {
            this.f7407y = new CameraDevice.StateCallback() {
                @Override
                public void onDisconnected(CameraDevice cameraDevice) {
                    if (Build.VERSION.SDK_INT >= 23) {
                        cameraDevice.close();
                        C2671a.this.f7408z = null;
                    }
                }

                @Override
                public void onError(CameraDevice cameraDevice, int i) {
                    if (Build.VERSION.SDK_INT >= 23) {
                        cameraDevice.close();
                        C2671a.this.f7408z = null;
                    }
                }

                @Override
                public void onOpened(CameraDevice cameraDevice) {
                    C2671a.this.f7408z = cameraDevice;
                    C2671a.this.m337r();
                }
            };
        }
    }

    /* renamed from: q */
    private C2706h m338q() {
        C2706h[] hVarArr;
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        int i = this.f7391i.f7566a;
        int i2 = this.f7391i.f7567b;
        for (C2706h hVar : this.f7405w) {
            if (hVar.f7567b == (hVar.f7566a * i2) / i) {
                if (hVar.f7566a < i || hVar.f7567b < i2) {
                    arrayList2.add(hVar);
                } else {
                    arrayList.add(hVar);
                }
            }
        }
        return arrayList.size() > 0 ? (C2706h) Collections.min(arrayList, new C2697b()) : arrayList2.size() > 0 ? (C2706h) Collections.max(arrayList2, new C2697b()) : this.f7391i;
    }

    /* renamed from: r */
    public void m337r() {
        try {
            if (Build.VERSION.SDK_INT >= 23 && this.f7408z != null && this.f7365A == null && !this.f7392j) {
                C2706h q = m338q();
                this.f7371G.setDefaultBufferSize(q.f7566a, q.f7567b);
                Surface surface = new Surface(this.f7371G);
                Surface surface2 = this.f7372H.getSurface();
                this.f7366B = (CaptureRequest.Builder) CameraDevice.class.getMethod("createCaptureRequest", Integer.TYPE).invoke(this.f7408z, 1);
                this.f7366B.addTarget(surface);
                this.f7366B.addTarget(surface2);
                this.f7408z.createCaptureSession(Arrays.asList(surface2, surface), new CameraCaptureSession.StateCallback() {
                    @Override
                    public void onConfigureFailed(CameraCaptureSession cameraCaptureSession) {
                        C2671a.this.f7386d = "Preview configure failed.";
                    }

                    @Override
                    public void onConfigured(CameraCaptureSession cameraCaptureSession) {
                        try {
                            if (Build.VERSION.SDK_INT >= 23) {
                                C2671a.this.f7365A = cameraCaptureSession;
                                C2671a.this.f7366B.set(CaptureRequest.CONTROL_CAPTURE_INTENT, 1);
                                C2671a.this.f7366B.set(CaptureRequest.CONTROL_MODE, 1);
                                C2671a.this.f7366B.set(CaptureRequest.CONTROL_EFFECT_MODE, 0);
                                C2671a.this.f7366B.set(CaptureRequest.CONTROL_AWB_MODE, 1);
                                C2671a.this.f7366B.set(CaptureRequest.CONTROL_AE_MODE, 1);
                                C2671a.this.f7366B.set(CaptureRequest.CONTROL_AF_MODE, 3);
                                C2671a.this.f7367C = C2671a.this.f7366B.build();
                                C2671a.this.f7365A.setRepeatingRequest(C2671a.this.f7367C, C2671a.this.f7368D, C2671a.this.f7369E);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, null);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* renamed from: s */
    private void m336s() {
        if (Build.VERSION.SDK_INT >= 23 && this.f7368D == null) {
            this.f7368D = new CameraCaptureSession.CaptureCallback() {
            };
        }
    }

    /* renamed from: t */
    private void m335t() {
        if (this.f7370F == null) {
            this.f7370F = new HandlerThread("PreviewBackground");
            this.f7370F.start();
            this.f7369E = new Handler(this.f7370F.getLooper());
        }
    }

    /* renamed from: u */
    private void m334u() {
        if (this.f7370F != null) {
            if (Build.VERSION.SDK_INT >= 18) {
                this.f7370F.quitSafely();
            } else {
                this.f7370F.quit();
            }
            try {
                this.f7370F.join();
                this.f7370F = null;
                this.f7369E = null;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /* renamed from: v */
    private C2706h m333v() {
        if (this.f7406x == null || this.f7406x.size() == 0) {
            return null;
        }
        if (this.f7390h < 0) {
            C2706h hVar = this.f7406x.get(0);
            C2706h hVar2 = this.f7406x.get(this.f7406x.size() - 1);
            int round = Math.round(this.f7406x.size() / 3.0f);
            if (hVar.f7566a > hVar2.f7566a || hVar.f7567b > hVar2.f7567b) {
                this.f7390h = this.f7406x.size() - round;
            } else {
                this.f7390h = round - 1;
            }
        }
        if (this.f7390h < 0) {
            this.f7390h = 0;
        }
        if (this.f7390h >= this.f7406x.size()) {
            this.f7390h = this.f7406x.size() - 1;
        }
        return this.f7406x.get(this.f7390h);
    }

    /* renamed from: w */
    private void m332w() {
        if (Build.VERSION.SDK_INT >= 23 && this.f7373I == null) {
            this.f7373I = new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader imageReader) {
                    if (Build.VERSION.SDK_INT >= 23) {
                        try {
                            Image acquireLatestImage = imageReader.acquireLatestImage();
                            if (acquireLatestImage != null) {
                                if (C2671a.this.f7393k > 0) {
                                    C2671a.this.m370a(acquireLatestImage);
                                }
                                acquireLatestImage.close();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            };
        }
    }

    /* renamed from: a */
    public int m371a(OutputStream outputStream, String str, int i) {
        byte[] bArr;
        int i2 = 0;
        Bitmap bitmap;
        boolean z;
        byte[] bArr2;
        synchronized (this.f7381Q) {
            if (this.f7377M[this.f7380P].f7586p == 0 && this.f7377M[this.f7379O].f7586p == 0) {
                i2 = 0;
            } else {
                if (this.f7377M[this.f7380P].f7586p == 0) {
                    this.f7380P = this.f7379O;
                }
                if (this.f7383S <= 0 || this.f7377M[this.f7380P].f7586p != i) {
                    if (this.f7383S == 0) {
                        this.f7380P = this.f7379O;
                    }
                    this.f7383S++;
                    try {
                        synchronized (this.f7382R) {
                            if (this.f7377M[this.f7380P].f7586p == i) {
                                bArr = null;
                            } else if (this.f7377M[this.f7380P].f7573c != this.f7377M[this.f7380P].f7586p) {
                                int i3 = 0;
                                if (this.f7395m != 0 || Build.VERSION.SDK_INT >= 23) {
                                    i3 = this.f7398p ? this.f7395m + 180 : this.f7399q ? ((this.f7395m + this.f7403u) + 180) % 360 : (this.f7395m + this.f7403u) % 360;
                                }
                                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                                if (this.f7377M[this.f7380P].f7574d != null) {
                                    new YuvImage(this.f7377M[this.f7380P].f7574d, 17, this.f7377M[this.f7380P].f7583m, this.f7377M[this.f7380P].f7584n, null).compressToJpeg(new Rect(0, 0, this.f7377M[this.f7380P].f7583m, this.f7377M[this.f7380P].f7584n), i3 == 0 ? this.f7394l : 100, byteArrayOutputStream);
                                    bArr2 = byteArrayOutputStream.toByteArray();
                                    bitmap = null;
                                    z = true;
                                } else if (this.f7377M[this.f7380P].f7576f != null && this.f7377M[this.f7380P].f7577g != null && this.f7377M[this.f7380P].f7578h != null) {
                                    try {
                                        if (!this.f7374J || this.f7375K == null) {
                                            int[] iArr = new int[this.f7377M[this.f7380P].f7583m * this.f7377M[this.f7380P].f7584n];
                                            m363a(iArr, this.f7377M[this.f7380P].f7576f, this.f7377M[this.f7380P].f7577g, this.f7377M[this.f7380P].f7578h, this.f7377M[this.f7380P].f7579i, this.f7377M[this.f7380P].f7580j, this.f7377M[this.f7380P].f7583m, this.f7377M[this.f7380P].f7584n, i3);
                                            bitmap = (i3 == 270 || i3 == 90) ? Bitmap.createBitmap(iArr, this.f7377M[this.f7380P].f7584n, this.f7377M[this.f7380P].f7583m, Bitmap.Config.ARGB_8888) : Bitmap.createBitmap(iArr, this.f7377M[this.f7380P].f7583m, this.f7377M[this.f7380P].f7584n, Bitmap.Config.ARGB_8888);
                                        } else {
                                            bitmap = this.f7375K.mo46a(this.f7377M[this.f7380P].f7576f, this.f7377M[this.f7380P].f7577g, this.f7377M[this.f7380P].f7578h, this.f7377M[this.f7380P].f7579i, this.f7377M[this.f7380P].f7580j, this.f7377M[this.f7380P].f7583m, this.f7377M[this.f7380P].f7584n, i3);
                                        }
                                        z = false;
                                        bArr2 = null;
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        bitmap = null;
                                        z = true;
                                        bArr2 = null;
                                    }
                                } else if (this.f7377M[this.f7380P].f7575e != null) {
                                    bArr2 = this.f7377M[this.f7380P].f7575e;
                                    bitmap = null;
                                    z = true;
                                } else {
                                    bitmap = null;
                                    z = true;
                                    bArr2 = null;
                                }
                                if (z && !(i3 == 0 && this.f7377M[this.f7380P].f7575e == null)) {
                                    if (bArr2 != null) {
                                        bitmap = BitmapFactory.decodeByteArray(bArr2, 0, bArr2.length);
                                    }
                                    Matrix matrix = new Matrix();
                                    matrix.postRotate(i3);
                                    bitmap = Bitmap.createBitmap(bitmap, 0, 0, this.f7377M[this.f7380P].f7583m, this.f7377M[this.f7380P].f7584n, matrix, true);
                                }
                                if (bitmap != null) {
                                    byteArrayOutputStream.reset();
                                    bitmap.compress(Bitmap.CompressFormat.JPEG, this.f7394l, byteArrayOutputStream);
                                    bArr = byteArrayOutputStream.toByteArray();
                                } else {
                                    bArr = bArr2;
                                }
                                this.f7377M[this.f7380P].f7573c = this.f7377M[this.f7380P].f7586p;
                                this.f7377M[this.f7380P].f7572b = bArr;
                            } else {
                                bArr = this.f7377M[this.f7380P].f7572b;
                            }
                        }
                        if (bArr != null) {
                            outputStream.write(("Content-type: image/jpeg\r\nContent-Length: " + bArr.length + "\r\n\r\n").getBytes());
                            outputStream.write(bArr);
                            outputStream.write("\r\n".getBytes());
                            outputStream.flush();
                        }
                        synchronized (this.f7381Q) {
                            i2 = this.f7377M[this.f7380P].f7586p;
                            this.f7383S--;
                        }
                    } catch (Throwable th) {
                        synchronized (this.f7381Q) {
                            int i4 = this.f7377M[this.f7380P].f7586p;
                            this.f7383S--;
                            try {
                                throw th;
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                } else {
                    i2 = this.f7377M[this.f7380P].f7586p;
                }
            }
        }
        return i2;
    }

    /* renamed from: a */
    public void m377a(Activity activity, SurfaceTexture surfaceTexture) {
        synchronized (HttpServer.f7135a) {
            m373a(this.f7371G);
            m360b(activity, surfaceTexture);
        }
    }

    /* renamed from: a */
    public void m376a(Activity activity, SurfaceHolder surfaceHolder) {
        synchronized (HttpServer.f7135a) {
            m372a(this.f7397o);
            m359b(activity, surfaceHolder);
        }
    }

    /* renamed from: a */
    public void m375a(Activity activity, View view, int i, int i2) {
        if (Build.VERSION.SDK_INT >= 23) {
            TextureView textureView = (TextureView) view;
            int b = m361b(activity);
            Matrix matrix = new Matrix();
            RectF rectF = new RectF(0.0f, 0.0f, i, i2);
            float centerX = rectF.centerX();
            float centerY = rectF.centerY();
            if (b == 90 || b == 270) {
                RectF rectF2 = new RectF(0.0f, 0.0f, this.f7391i.f7567b, this.f7391i.f7566a);
                rectF2.offset(centerX - rectF2.centerX(), centerY - rectF2.centerY());
                matrix.setRectToRect(rectF, rectF2, Matrix.ScaleToFit.FILL);
                float max = Math.max(i2 / this.f7391i.f7567b, i / this.f7391i.f7566a);
                matrix.postScale(max, max, centerX, centerY);
                matrix.postRotate(b, centerX, centerY);
            } else {
                matrix.postRotate(b, centerX, centerY);
            }
            textureView.setTransform(matrix);
        }
    }

    /* renamed from: a */
    public void m374a(Activity activity, boolean z) {
        this.f7400r = z;
        if (!m362b() && this.f7371G != null) {
            m360b(activity, this.f7371G);
        }
    }

    /* renamed from: a */
    public void m373a(SurfaceTexture surfaceTexture) {
        synchronized (HttpServer.f7135a) {
            if (Build.VERSION.SDK_INT >= 23 && this.f7408z != null && this.f7371G != null && surfaceTexture == this.f7371G) {
                this.f7400r = false;
                if (this.f7365A != null) {
                    this.f7365A.close();
                    this.f7365A = null;
                }
                if (this.f7408z != null) {
                    try {
                        CameraDevice.class.getMethod("close", new Class[0]).invoke(this.f7408z, new Object[0]);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    this.f7408z = null;
                }
                if (this.f7372H != null) {
                    this.f7372H.close();
                    this.f7372H = null;
                }
                m334u();
                this.f7371G = null;
            }
        }
    }

    /* renamed from: a */
    public void m372a(SurfaceHolder surfaceHolder) {
        synchronized (HttpServer.f7135a) {
            if (!(this.f7388f == null || this.f7397o == null || surfaceHolder != this.f7397o)) {
                m341n();
                this.f7388f.release();
                this.f7388f = null;
                this.f7397o = null;
            }
        }
    }

    /* renamed from: a */
    public boolean m378a(Activity activity) {
        boolean z = false;
        synchronized (HttpServer.f7135a) {
            this.f7398p = false;
            int i = this.f7395m;
            this.f7395m = m361b(activity);
            if (this.f7388f != null) {
                this.f7388f.setDisplayOrientation(this.f7395m);
            }
            if (i != this.f7395m) {
                z = true;
            }
        }
        return z;
    }

    /* renamed from: b */
    public void m360b(Activity activity, SurfaceTexture surfaceTexture) {
        synchronized (HttpServer.f7135a) {
            if (Build.VERSION.SDK_INT >= 23) {
                try {
                    this.f7375K = (AbstractC2676a) Class.forName("ru.proghouse.robocam.i").newInstance();
                    this.f7375K.mo47a(activity);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                this.f7371G = surfaceTexture;
                SharedPreferences sharedPreferences = activity.getSharedPreferences("RoboCamSettings", 0);
                this.f7390h = sharedPreferences.getInt("preview_size", -1);
                this.f7374J = sharedPreferences.getBoolean("use_render_script", true);
                this.f7394l = sharedPreferences.getInt("jpeg_quality", 60);
                if (ActivityCompat.checkSelfPermission((Context) activity, "android.permission.CAMERA") == 0) {
                    this.f7401s = (CameraManager) activity.getSystemService("camera");
                    try {
                        this.f7402t = sharedPreferences.getString("camera2_id", null);
                        if (this.f7402t == null) {
                            this.f7402t = this.f7401s.getCameraIdList()[0];
                        }
                        CameraCharacteristics cameraCharacteristics = this.f7401s.getCameraCharacteristics(this.f7402t);
                        this.f7403u = ((Integer) cameraCharacteristics.get(CameraCharacteristics.SENSOR_ORIENTATION)).intValue();
                        this.f7404v = ((Integer) cameraCharacteristics.get(CameraCharacteristics.LENS_FACING)).intValue();
                        StreamConfigurationMap streamConfigurationMap = (StreamConfigurationMap) cameraCharacteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                        Size[] outputSizes = streamConfigurationMap.getOutputSizes(SurfaceTexture.class);
                        this.f7405w = new C2706h[outputSizes.length];
                        HashSet hashSet = new HashSet();
                        for (int i = 0; i < outputSizes.length; i++) {
                            this.f7405w[i] = new C2706h(outputSizes[i]);
                            hashSet.add(Float.valueOf(outputSizes[i].getHeight() / outputSizes[i].getWidth()));
                        }
                        Size[] outputSizes2 = streamConfigurationMap.getOutputSizes(35);
                        this.f7406x.clear();
                        for (int i2 = 0; i2 < outputSizes2.length; i2++) {
                            if (hashSet.contains(Float.valueOf(outputSizes2[i2].getHeight() / outputSizes2[i2].getWidth()))) {
                                this.f7406x.add(new C2706h(outputSizes2[i2]));
                            }
                        }
                        Collections.sort(this.f7406x, new C2697b());
                        this.f7391i = m333v();
                        m339p();
                        m336s();
                        m335t();
                        m332w();
                        this.f7372H = ImageReader.newInstance(this.f7391i.f7566a, this.f7391i.f7567b, 35, 2);
                        this.f7372H.setOnImageAvailableListener(this.f7373I, this.f7369E);
                        this.f7401s.openCamera(this.f7402t, this.f7407y, this.f7369E);
                    } catch (Exception e2) {
                        this.f7386d = e2.getMessage();
                        e2.printStackTrace();
                    }
                } else if (ActivityCompat.shouldShowRequestPermissionRationale(activity, "android.permission.CAMERA")) {
                    Bundle bundle = new Bundle();
                    bundle.putInt("message_id", R.string.request_camera_permission);
                    bundle.putStringArray("permissions", new String[]{"android.permission.CAMERA"});
                    bundle.putInt("request_code", 1);
                    DialogFragmentC2698c cVar = new DialogFragmentC2698c();
                    cVar.setArguments(bundle);
                    cVar.show(activity.getFragmentManager(), "dialog");
                } else {
                    ActivityCompat.requestPermissions(activity, new String[]{"android.permission.CAMERA"}, 1);
                }
            }
        }
    }

    /* renamed from: b */
    public void m359b(Activity activity, SurfaceHolder surfaceHolder) {
        synchronized (HttpServer.f7135a) {
            if (Build.VERSION.SDK_INT < 23) {
                this.f7397o = surfaceHolder;
                SharedPreferences sharedPreferences = activity.getSharedPreferences("RoboCamSettings", 0);
                this.f7390h = sharedPreferences.getInt("preview_size", -1);
                this.f7394l = sharedPreferences.getInt("jpeg_quality", 60);
                if (Build.VERSION.SDK_INT >= 9) {
                    this.f7389g = sharedPreferences.getInt("camera_id", 0);
                    this.f7388f = Camera.open(this.f7389g);
                    this.f7394l = sharedPreferences.getInt("jpeg_quality", 60);
                } else if (this.f7389g == 0) {
                    this.f7388f = Camera.open();
                } else {
                    this.f7386d = this.f7387e.getString(R.string.error_only_back_facing_camera_supported);
                    return;
                }
                if (this.f7388f != null) {
                    List<Camera.Size> supportedPreviewSizes = this.f7388f.getParameters().getSupportedPreviewSizes();
                    this.f7406x.clear();
                    for (int i = 0; i < supportedPreviewSizes.size(); i++) {
                        this.f7406x.add(new C2706h(supportedPreviewSizes.get(i)));
                    }
                    try {
                        this.f7388f.setPreviewDisplay(surfaceHolder);
                    } catch (IOException e) {
                        this.f7386d = e.getMessage();
                        e.printStackTrace();
                        this.f7388f.release();
                        this.f7388f = null;
                    }
                    m342m();
                }
            }
        }
    }

    /* renamed from: b */
    public boolean m362b() {
        boolean z = true;
        synchronized (HttpServer.f7135a) {
            if (Build.VERSION.SDK_INT >= 23) {
                if (this.f7408z == null) {
                    z = false;
                }
            } else if (this.f7388f == null) {
                z = false;
            }
        }
        return z;
    }

    /* renamed from: c */
    public C2706h m357c() {
        C2706h hVar;
        synchronized (HttpServer.f7135a) {
            hVar = this.f7391i;
        }
        return hVar;
    }

    /* renamed from: d */
    public int m355d() {
        int i;
        synchronized (HttpServer.f7135a) {
            i = this.f7391i.f7566a;
        }
        return i;
    }

    /* renamed from: e */
    public int m353e() {
        int i;
        synchronized (HttpServer.f7135a) {
            i = this.f7391i.f7567b;
        }
        return i;
    }

    /* renamed from: f */
    public int m351f() {
        int i = -1;
        synchronized (HttpServer.f7135a) {
            if (Build.VERSION.SDK_INT >= 23) {
                i = (this.f7396n == 0 || this.f7396n == 2) ? m353e() : m355d();
            } else if (m344k() && m343l() != -1) {
                i = m343l() % 180 == 0 ? m355d() : m353e();
            }
        }
        return i;
    }

    /* renamed from: g */
    public int m349g() {
        int i = -1;
        synchronized (HttpServer.f7135a) {
            if (Build.VERSION.SDK_INT >= 23) {
                i = (this.f7396n == 0 || this.f7396n == 2) ? m355d() : m353e();
            } else if (m344k() && m343l() != -1) {
                i = m343l() % 180 == 0 ? m353e() : m355d();
            }
        }
        return i;
    }

    /* renamed from: h */
    public void m347h() {
        if (this.f7393k == 0) {
            this.f7383S = 0;
            for (C2708j jVar : this.f7377M) {
                jVar.m45a();
            }
        }
        this.f7393k++;
    }

    /* renamed from: i */
    public void m346i() {
        this.f7393k--;
    }

    /* renamed from: j */
    public boolean m345j() {
        return this.f7400r;
    }

    /* renamed from: k */
    public boolean m344k() {
        return this.f7392j;
    }

    /* renamed from: l */
    public int m343l() {
        return this.f7395m;
    }

    /* renamed from: m */
    public void m342m() {
        synchronized (HttpServer.f7135a) {
            if (this.f7388f != null) {
                this.f7388f.setPreviewCallback(this);
                this.f7388f.startPreview();
                this.f7392j = true;
            }
        }
    }

    /* renamed from: n */
    public void m341n() {
        synchronized (HttpServer.f7135a) {
            if (this.f7388f != null) {
                this.f7392j = false;
                this.f7388f.stopPreview();
                this.f7388f.setPreviewCallback(null);
            }
        }
    }

    public boolean m340o() {
        boolean b0 = false;
//        Object a0 = ru.proghouse.robocam.HttpServer.a;
        /*monenter(a0)*/;
        int i0 = android.os.Build.VERSION.SDK_INT;
        label5: try {
            label2: {
                label4: {
                    if (i0 < 23) {
                        break label4;
                    }
                    if (this.f7408z != null) {
                        break label2;
                    }
                    /*monexit(a0)*/;
                    b0 = false;
                    break label5;
                }
                android.hardware.Camera a1 = this.f7388f;
                label3: {
                    if (a1 == null) {
                        break label3;
                    }
                    if (!this.f7392j) {
                        break label2;
                    }
                }
                /*monexit(a0)*/;
                b0 = false;
                break label5;
            }
            this.f7391i = this.m333v();
            ru.proghouse.robocam.C2708j[] a2 = this.f7377M;
            int i1 = a2.length;
            int i2 = 0;
            while(i2 < i1) {
                a2[i2].m45a();
                i2 = i2 + 1;
            }
            if (android.os.Build.VERSION.SDK_INT < 23) {
                android.hardware.Camera.Parameters a3 = this.f7388f.getParameters();
                a3.setPreviewSize(f7391i.f7566a, f7391i.f7567b);
                a3.setJpegQuality(100);
                this.f7388f.setParameters(a3);
            }
            int i3 = f7384a;
            int i4 = f7391i.f7566a;
            label0: {
                label1: {
                    if (i3 != i4) {
                        break label1;
                    }
                    if (this.f7385b == f7391i.f7567b) {
                        b0 = false;
                        break label0;
                    }
                }
                b0 = true;
            }
            f7384a = (f7391i != null) ? f7391i.f7566a : -1;
            this.f7385b = (f7391i != null) ? f7391i.f7567b : -1;
            /*monexit(a0)*/;
        } catch(Throwable a4) {
            Throwable a5 = a4;
            while(true) {
                try {
                    /*monexit(a0)*/;
                } catch(IllegalMonitorStateException | NullPointerException a6) {
                    Throwable a7 = a6;
                    a5 = a7;
                    continue;
                }
                try {
                    throw a5;
                } catch (Throwable throwable) {
                    throwable.printStackTrace();
                }
            }
        }
        return b0;
    }

    @Override
    public void onPreviewFrame(byte[] bArr, Camera camera) {
        if (this.f7393k > 0 && this.f7392j) {
            this.f7376L++;
            if (this.f7376L == Integer.MAX_VALUE) {
                this.f7376L = Integer.MIN_VALUE;
            }
            if (this.f7376L == 0) {
                this.f7376L++;
            }
            if (!this.f7377M[this.f7378N].f7571a) {
                this.f7377M[this.f7378N].f7583m = camera.getParameters().getPreviewSize().width;
                this.f7377M[this.f7378N].f7584n = camera.getParameters().getPreviewSize().height;
                this.f7377M[this.f7378N].f7571a = true;
            }
            if (this.f7377M[this.f7378N].f7574d == null || this.f7377M[this.f7378N].f7574d.length != bArr.length) {
                this.f7377M[this.f7378N].f7574d = (byte[]) bArr.clone();
            } else {
                System.arraycopy(bArr, 0, this.f7377M[this.f7378N].f7574d, 0, bArr.length);
            }
            this.f7377M[this.f7378N].f7586p = this.f7376L;
            synchronized (this.f7381Q) {
                this.f7379O = this.f7378N;
                this.f7378N++;
                if (this.f7378N >= this.f7377M.length) {
                    this.f7378N = 0;
                }
                if (this.f7378N == this.f7380P) {
                    this.f7378N++;
                    if (this.f7378N >= this.f7377M.length) {
                        this.f7378N = 0;
                    }
                }
            }
        }
    }
}
