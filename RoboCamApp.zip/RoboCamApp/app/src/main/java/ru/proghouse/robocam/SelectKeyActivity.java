package ru.proghouse.robocam;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.util.HashSet;
import ru.proghouse.robocam.p062a.p064b.C2693f;

@SuppressWarnings("ALL")
public class SelectKeyActivity extends AppCompatActivity {

    /* renamed from: n */
    HashSet<Integer> f7319n = new HashSet<>();

    /* renamed from: o */
    ListView f7320o;

    /* renamed from: p */
    TextView f7321p;

    /* renamed from: q */
    Activity f7322q;

    /* renamed from: r */
    String f7323r;

    /* renamed from: c */
    private int m395c(int i) {
        if (i >= 29 && i <= 54) {
            return (i - 29) + 65;
        }
        if (i >= 7 && i <= 16) {
            return (i - 7) + 48;
        }
        if (i == 112) {
            return 46;
        }
        if (i == 67) {
            return 8;
        }
        if (i == 124) {
            return 45;
        }
        if (i == 59 || i == 60) {
            return 16;
        }
        if (i == 113 || i == 114) {
            return 17;
        }
        if (i == 57 || i == 58) {
            return 18;
        }
        if (i == 143) {
            return 144;
        }
        if (i == 116) {
            return 145;
        }
        if (i >= 144 && i <= 153) {
            return (i - 144) + 96;
        }
        if (i == 121) {
            return 19;
        }
        if (i == 68) {
            return 192;
        }
        if (i == 69) {
            return 189;
        }
        if (i == 71) {
            return 219;
        }
        if (i == 72) {
            return 221;
        }
        if (i == 73) {
            return 220;
        }
        if (i == 74) {
            return 186;
        }
        if (i == 75) {
            return 222;
        }
        if (i == 55) {
            return 188;
        }
        if (i == 56) {
            return 190;
        }
        if (i == 76) {
            return 191;
        }
        if (i == 132) {
            return 113;
        }
        if (i == 134) {
            return 115;
        }
        if (i == 137) {
            return 118;
        }
        if (i == 138) {
            return 119;
        }
        if (i == 139) {
            return 120;
        }
        if (i == 140) {
            return 121;
        }
        return 0;
    }

    /* renamed from: j */
    public void m394j() {
        if (this.f7319n.size() == 0) {
            this.f7321p.setText(R.string.nothing_selected);
        } else {
            this.f7321p.setText(getString(R.string.selected, new Object[]{C2693f.m133a(this.f7322q, this.f7319n)}));
        }
    }

    public void onCancelButtonClick(View view) {
        finish();
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_select_key);
        this.f7322q = this;
        this.f7323r = getIntent().getStringExtra("android.intent.extra.remote_intent_token");
        setTitle(getIntent().getStringExtra("android.intent.extra.TEXT"));
        if (bundle != null) {
            C2693f.m130a(bundle.getIntArray("SettingsKeys"), this.f7319n);
        } else {
            C2693f.m130a(getIntent().getIntArrayExtra("android.intent.extra.STREAM"), this.f7319n);
        }
        this.f7321p = (TextView) findViewById(R.id.titleTextView);
        ArrayAdapter<C2705g> arrayAdapter = new ArrayAdapter<C2705g>(this, R.layout.checked_listview_item, C2693f.m137a()) {
            @Override
            public View getView(int i, View view, ViewGroup viewGroup) {
                if (view == null) {
                    view = SelectKeyActivity.this.getLayoutInflater().inflate(R.layout.checked_listview_item, viewGroup, false);
                }
                C2705g item = getItem(i);
                CheckBox checkBox = (CheckBox) view.findViewById(R.id.checkBox1);
                checkBox.setText(item.m48b());
                checkBox.setTag(new Integer(item.m49a()));
                checkBox.setChecked(SelectKeyActivity.this.f7319n.contains(Integer.valueOf(item.m49a())));
                checkBox.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view2) {
                        CheckBox checkBox2 = (CheckBox) view2;
                        Integer num = (Integer) checkBox2.getTag();
                        if (checkBox2.isChecked()) {
                            SelectKeyActivity.this.f7319n.add(num);
                        } else {
                            SelectKeyActivity.this.f7319n.remove(num);
                        }
                        SelectKeyActivity.this.m394j();
                    }
                });
                return view;
            }
        };
        this.f7320o = (ListView) findViewById(R.id.keyListView);
        this.f7320o.setAdapter((ListAdapter) arrayAdapter);
        m394j();
    }

    public void onDoneButtonClick(View view) {
        Intent intent = new Intent(this, SelectKeyActivity.class);
        intent.putExtra("android.intent.extra.remote_intent_token", this.f7323r);
        intent.putExtra("android.intent.extra.TEXT", getTitle().toString());
        intent.putExtra("android.intent.extra.STREAM", C2693f.m131a(this.f7319n));
        setResult(-1, intent);
        finish();
    }

    @Override
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        int c = m395c(i);
        if (!C2693f.m128b(c)) {
            return super.onKeyDown(i, keyEvent);
        }
        if (this.f7319n.contains(Integer.valueOf(c))) {
            this.f7319n.remove(Integer.valueOf(c));
        } else {
            this.f7319n.add(Integer.valueOf(c));
        }
        ((ArrayAdapter) this.f7320o.getAdapter()).notifyDataSetChanged();
        m394j();
        return true;
    }

    @Override
    protected void onRestoreInstanceState(Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        C2693f.m130a(bundle.getIntArray("SettingsKeys"), this.f7319n);
    }

    @Override
    public void onSaveInstanceState(Bundle bundle) {
        bundle.putIntArray("SettingsKeys", C2693f.m131a(this.f7319n));
        super.onSaveInstanceState(bundle);
    }
}
