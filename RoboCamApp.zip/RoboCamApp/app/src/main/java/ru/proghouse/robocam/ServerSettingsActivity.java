package ru.proghouse.robocam;

import android.content.SharedPreferences;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Size;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

@SuppressWarnings("ALL")
public class ServerSettingsActivity extends AppCompatActivity {

    /* renamed from: A */
    private String f7326A;

    /* renamed from: C */
    private String f7328C;

    /* renamed from: E */
    private String f7330E;

    /* renamed from: y */
    private String f7357y;

    /* renamed from: o */
    private Spinner f7347o = null;

    /* renamed from: n */
    CameraManager f7346n = null;

    /* renamed from: p */
    private int f7348p = 0;

    /* renamed from: q */
    private String f7349q = null;

    /* renamed from: r */
    private Spinner f7350r = null;

    /* renamed from: s */
    private int f7351s = -1;

    /* renamed from: t */
    private int f7352t = -1;

    /* renamed from: u */
    private TextView f7353u = null;

    /* renamed from: v */
    private SeekBar f7354v = null;

    /* renamed from: w */
    private int f7355w = 60;

    /* renamed from: x */
    private SharedPreferences.Editor f7356x = null;

    /* renamed from: z */
    private EditText f7358z = null;

    /* renamed from: B */
    private EditText f7327B = null;

    /* renamed from: D */
    private EditText f7329D = null;

    /* renamed from: F */
    private EditText f7331F = null;

    /* renamed from: G */
    private CheckBox f7332G = null;

    /* renamed from: H */
    private CheckBox f7333H = null;

    /* renamed from: I */
    private ImageView f7334I = null;

    /* renamed from: J */
    private boolean f7335J = true;

    /* renamed from: K */
    private boolean f7336K = true;

    /* renamed from: L */
    private TextView f7337L = null;

    /* renamed from: M */
    private TextView f7338M = null;

    /* renamed from: N */
    private List<String> f7339N = new ArrayList();

    /* renamed from: O */
    private CheckBox f7340O = null;

    /* renamed from: P */
    private CheckBox f7341P = null;

    /* renamed from: Q */
    private boolean f7342Q = false;

    /* renamed from: R */
    private boolean f7343R = false;

    /* renamed from: S */
    private LinearLayout f7344S = null;

    /* renamed from: T */
    private LinearLayout f7345T = null;

    /* renamed from: b */
    public void m388b(boolean z) {
        ArrayList arrayList = new ArrayList();
        List<String> a = m393a(arrayList);
        C2712m.m18a(this.f7350r, this, a, R.string.previewSize);
        if (z && this.f7351s < 0) {
            C2706h hVar = (C2706h) arrayList.get(0);
            C2706h hVar2 = (C2706h) arrayList.get(arrayList.size() - 1);
            int round = Math.round(a.size() / 3.0f);
            if (hVar.f7566a > hVar2.f7566a || hVar.f7567b > hVar2.f7567b) {
                this.f7351s = a.size() - round;
            } else {
                this.f7351s = round - 1;
            }
        }
        if (this.f7351s < 0) {
            this.f7351s = 0;
        }
        if (this.f7351s >= a.size()) {
            this.f7351s = a.size() - 1;
        }
        this.f7350r.setSelection(this.f7351s, true);
        this.f7350r.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                ServerSettingsActivity.this.f7351s = i;
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
    }

    /* renamed from: k */
    private SharedPreferences.Editor m381k() {
        if (this.f7356x == null) {
            this.f7356x = getSharedPreferences("RoboCamSettings", 0).edit();
        }
        return this.f7356x;
    }

    /* renamed from: l */
    private void m380l() {
        if (this.f7356x == null) {
            return;
        }
        if (Build.VERSION.SDK_INT >= 9) {
            this.f7356x.apply();
        } else {
            this.f7356x.commit();
        }
    }

    /* renamed from: a */
    public List<String> m393a(List<C2706h> list) {
        Size[] outputSizes;
        ArrayList arrayList = new ArrayList();
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                StreamConfigurationMap streamConfigurationMap = (StreamConfigurationMap) this.f7346n.getCameraCharacteristics(this.f7349q).get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                HashSet hashSet = new HashSet();
                for (Size size : streamConfigurationMap.getOutputSizes(SurfaceTexture.class)) {
                    hashSet.add(Float.valueOf(size.getHeight() / size.getWidth()));
                }
                Size[] outputSizes2 = streamConfigurationMap.getOutputSizes(35);
                for (Size size2 : outputSizes2) {
                    if (hashSet.contains(Float.valueOf(size2.getHeight() / size2.getWidth()))) {
                        list.add(new C2706h(size2));
                    }
                }
                Collections.sort(list, new C2697b());
                for (C2706h hVar : list) {
                    arrayList.add("" + hVar.f7566a + "x" + hVar.f7567b);
                }
            } catch (Exception e) {
                Toast.makeText(this, e.getLocalizedMessage(), 1).show();
            }
        } else {
            Camera open = Build.VERSION.SDK_INT >= 9 ? Camera.open(this.f7348p) : Camera.open();
            try {
                for (Camera.Size size3 : open.getParameters().getSupportedPreviewSizes()) {
                    if (list != null) {
                        list.add(new C2706h(size3));
                    }
                    arrayList.add("" + size3.width + "x" + size3.height);
                }
            } finally {
                open.release();
            }
        }
        return arrayList;
    }

    /* renamed from: j */
    public List<String> m382j() {
        String[] cameraIdList;
        ArrayList arrayList = new ArrayList();
        this.f7339N.clear();
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                this.f7346n = (CameraManager) getSystemService("camera");
                for (String str : this.f7346n.getCameraIdList()) {
                    this.f7339N.add(str);
                    switch (((Integer) this.f7346n.getCameraCharacteristics(str).get(CameraCharacteristics.LENS_FACING)).intValue()) {
                        case 0:
                            arrayList.add(getString(R.string.camera_facing_front));
                            continue;
                        case 1:
                            arrayList.add(getString(R.string.camera_facing_back));
                            continue;
                        default:
                            arrayList.add(getString(R.string.camera_facing_external));
                            continue;
                    }
                }
            } catch (Exception e) {
                Toast.makeText(this, e.getLocalizedMessage(), 1).show();
            }
        } else if (Build.VERSION.SDK_INT >= 9) {
            int numberOfCameras = Camera.getNumberOfCameras();
            for (int i = 0; i < numberOfCameras; i++) {
                Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
                Camera.getCameraInfo(i, cameraInfo);
                if (cameraInfo.facing == 1) {
                    arrayList.add(getString(R.string.camera_facing_front));
                } else if (cameraInfo.facing == 0) {
                    arrayList.add(getString(R.string.camera_facing_back));
                } else {
                    arrayList.add(getString(R.string.camera_facing_external));
                }
            }
        } else {
            arrayList.add(getString(R.string.camera_facing_back));
        }
        return arrayList;
    }

    public void onCancelButtonClick(View view) {
        finish();
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_server_settings);
        SharedPreferences sharedPreferences = getSharedPreferences("RoboCamSettings", 0);
        this.f7340O = (CheckBox) findViewById(R.id.checkBoxUseLocalControls);
        this.f7342Q = sharedPreferences.getBoolean("use_local_controls", false);
        this.f7340O.setChecked(this.f7342Q);
        this.f7344S = (LinearLayout) findViewById(R.id.linearLayoutServer);
        this.f7344S.setVisibility(this.f7342Q ? 8 : 0);
        this.f7345T = (LinearLayout) findViewById(R.id.linearLayoutLocal);
        this.f7345T.setVisibility(this.f7342Q ? 0 : 8);
        this.f7340O.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                int i = 0;
                ServerSettingsActivity.this.f7344S.setVisibility(z ? 8 : 0);
                LinearLayout linearLayout = ServerSettingsActivity.this.f7345T;
                if (!z) {
                    i = 8;
                }
                linearLayout.setVisibility(i);
            }
        });
        this.f7341P = (CheckBox) findViewById(R.id.checkBoxMaximizeJoysticks);
        this.f7343R = sharedPreferences.getBoolean("maximize_joysticks", false);
        this.f7341P.setChecked(this.f7343R);
        List<String> j = m382j();
        this.f7347o = (Spinner) findViewById(R.id.spinnerCamera);
        C2712m.m18a(this.f7347o, this, j, R.string.camera);
        if (Build.VERSION.SDK_INT >= 23) {
            this.f7349q = sharedPreferences.getString("camera2_id", null);
            if (this.f7349q == null || !this.f7339N.contains(this.f7349q)) {
                this.f7349q = this.f7339N.get(0);
            }
            this.f7347o.setSelection(this.f7339N.indexOf(this.f7349q), true);
        } else {
            this.f7348p = sharedPreferences.getInt("camera_id", 0);
            if (this.f7348p < 0 || this.f7348p >= j.size()) {
                this.f7348p = 0;
            }
            this.f7347o.setSelection(this.f7348p, true);
        }
        this.f7347o.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j2) {
                ServerSettingsActivity.this.m388b(false);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        if (bundle != null) {
            this.f7351s = bundle.getInt("preview_size", -1);
        }
        if (bundle == null || this.f7351s < 0) {
            this.f7351s = sharedPreferences.getInt("preview_size", -1);
        }
        this.f7352t = sharedPreferences.getInt("preview_size", -1);
        this.f7350r = (Spinner) findViewById(R.id.spinnerPreviewSize);
        m388b(true);
        this.f7353u = (TextView) findViewById(R.id.textViewJpegQuality2);
        this.f7354v = (SeekBar) findViewById(R.id.seekBarJpegQuality);
        this.f7355w = sharedPreferences.getInt("jpeg_quality", 60);
        this.f7354v.incrementProgressBy(5);
        this.f7354v.setProgress(this.f7355w);
        this.f7353u.setText("" + this.f7355w + "%");
        this.f7354v.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                ServerSettingsActivity.this.f7353u.setText("" + ((i / 5) * 5) + "%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        this.f7333H = (CheckBox) findViewById(R.id.checkBoxUseRenderScript);
        this.f7334I = (ImageView) findViewById(R.id.imageViewUseRenderScript);
        Class<?> cls = null;
        try {
            cls = Class.forName("ru.proghouse.robocam.i");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        if (Build.VERSION.SDK_INT < 23 || cls == null) {
            this.f7333H.setVisibility(8);
            this.f7334I.setVisibility(8);
        } else {
            this.f7335J = sharedPreferences.getBoolean("use_render_script", true);
            this.f7333H.setChecked(this.f7335J);
        }
        this.f7357y = sharedPreferences.getString("driver_name", "admin");
        this.f7358z = (EditText) findViewById(R.id.editTextDriverName);
        this.f7358z.setText(this.f7357y);
        this.f7326A = sharedPreferences.getString("driver_pswd", "123");
        this.f7327B = (EditText) findViewById(R.id.editTextDriverPassword);
        this.f7327B.setText(this.f7326A);
        this.f7328C = sharedPreferences.getString("spectator_name", "guest");
        this.f7337L = (TextView) findViewById(R.id.textViewSpectatorName);
        this.f7329D = (EditText) findViewById(R.id.editTextSpectatorName);
        this.f7329D.setText(this.f7328C);
        this.f7330E = sharedPreferences.getString("spectator_pswd", "123");
        this.f7338M = (TextView) findViewById(R.id.textViewSpectatorPassword);
        this.f7331F = (EditText) findViewById(R.id.editTextSpectatorPassword);
        this.f7331F.setText(this.f7330E);
        this.f7336K = sharedPreferences.getBoolean("allow_spectators", true);
        this.f7332G = (CheckBox) findViewById(R.id.checkBoxAllowSpectators);
        this.f7332G.setChecked(this.f7336K);
        this.f7332G.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                ServerSettingsActivity.this.f7329D.setEnabled(z);
                ServerSettingsActivity.this.f7331F.setEnabled(z);
                ServerSettingsActivity.this.f7338M.setEnabled(z);
                ServerSettingsActivity.this.f7337L.setEnabled(z);
            }
        });
        this.f7329D.setEnabled(this.f7336K);
        this.f7331F.setEnabled(this.f7336K);
        this.f7338M.setEnabled(this.f7336K);
        this.f7337L.setEnabled(this.f7336K);
    }

    @Override
    protected void onRestoreInstanceState(Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        this.f7351s = bundle.getInt("preview_size", -1);
    }

    public void onSaveButtonClick(View view) {
        boolean z = true;
        if (this.f7357y != this.f7358z.getText().toString()) {
            m381k().putString("driver_name", this.f7358z.getText().toString());
            z = true;
        } else {
            z = false;
        }
        if (this.f7326A != this.f7327B.getText().toString()) {
            m381k().putString("driver_pswd", this.f7327B.getText().toString());
            z = true;
        }
        if (this.f7328C != this.f7329D.getText().toString()) {
            m381k().putString("spectator_name", this.f7329D.getText().toString());
            z = true;
        }
        if (this.f7330E != this.f7331F.getText().toString()) {
            m381k().putString("spectator_pswd", this.f7331F.getText().toString());
            z = true;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            if (!this.f7339N.get(this.f7347o.getSelectedItemPosition()).equals(this.f7349q)) {
                m381k().putString("camera2_id", this.f7339N.get(this.f7347o.getSelectedItemPosition()));
                z = true;
            }
        } else if (this.f7348p != this.f7347o.getSelectedItemPosition()) {
            m381k().putInt("camera_id", this.f7347o.getSelectedItemPosition());
            z = true;
        }
        if (this.f7352t != this.f7350r.getSelectedItemPosition()) {
            m381k().putInt("preview_size", this.f7350r.getSelectedItemPosition());
            z = true;
        }
        int progress = (this.f7354v.getProgress() / 5) * 5;
        if (progress == 0) {
            progress = 5;
        }
        if (progress != this.f7355w) {
            m381k().putInt("jpeg_quality", progress);
            z = true;
        }
        if (this.f7336K != this.f7332G.isChecked()) {
            m381k().putBoolean("allow_spectators", this.f7332G.isChecked());
            z = true;
        }
        if (this.f7335J != this.f7333H.isChecked()) {
            m381k().putBoolean("use_render_script", this.f7333H.isChecked());
            z = true;
        }
        if (this.f7342Q != this.f7340O.isChecked()) {
            m381k().putBoolean("use_local_controls", this.f7340O.isChecked());
            z = true;
        }
        if (this.f7343R != this.f7341P.isChecked()) {
            m381k().putBoolean("maximize_joysticks", this.f7341P.isChecked());
        }
        if (z) {
            m380l();
        }
        Toast.makeText(this, (int) R.string.settings_were_saved, 0).show();
        finish();
    }

    @Override
    public void onSaveInstanceState(Bundle bundle) {
        bundle.putInt("preview_size", this.f7351s);
        super.onSaveInstanceState(bundle);
    }
}
