package ru.proghouse.robocam;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import ru.proghouse.robocam.p062a.AbstractC2677a;

@SuppressWarnings("ALL")
public class ImportActivity extends AppCompatActivity {

    /* renamed from: n */
    private ListView f7179n = null;

    /* renamed from: o */
    private List<File> f7180o = new ArrayList();

    /* renamed from: p */
    private String f7181p = null;

    /* renamed from: q */
    private TextView f7182q = null;

    /* renamed from: r */
    private Activity f7183r = null;

    /* renamed from: s */
    private SharedPreferences.Editor f7184s = null;

    /* renamed from: t */
    private int f7185t = -1;

    /* renamed from: a */
    public List<File> m514a(String str) {
        File[] fileArr;
        if (str == null || str.equals("")) {
            File externalStorageDirectory = Environment.getExternalStorageDirectory();
            if ((!externalStorageDirectory.exists() || !externalStorageDirectory.isDirectory()) && System.getenv("EXTERNAL_STORAGE") != null) {
                externalStorageDirectory = new File(System.getenv("EXTERNAL_STORAGE"));
            }
            File file = System.getenv("SECONDARY_STORAGE") != null ? new File(System.getenv("SECONDARY_STORAGE")) : null;
            fileArr = (externalStorageDirectory == null || !externalStorageDirectory.exists() || !externalStorageDirectory.isDirectory() || file == null || !file.exists() || !file.isDirectory()) ? (externalStorageDirectory == null || !externalStorageDirectory.exists() || !externalStorageDirectory.isDirectory()) ? (file == null || !file.exists() || !file.isDirectory()) ? null : new File[]{file} : new File[]{externalStorageDirectory} : new File[]{externalStorageDirectory, file};
        } else {
            fileArr = new File(str).listFiles();
        }
        if (fileArr == null) {
            fileArr = new File[0];
        }
        ArrayList arrayList = new ArrayList();
        for (File file2 : fileArr) {
            if (file2.isDirectory() || file2.getName().trim().toLowerCase().endsWith(".xml")) {
                arrayList.add(file2);
            }
        }
        Collections.sort(arrayList, new Comparator<File>() {
            /* renamed from: a */
            public int compare(File file3, File file4) {
                if (file3.isDirectory() && file4.isFile()) {
                    return -1;
                }
                if (!file3.isFile() || !file4.isDirectory()) {
                    return file3.getPath().compareTo(file4.getPath());
                }
                return 1;
            }
        });
        return arrayList;
    }

    /* renamed from: a */
    public void m515a(File file) {
        try {
            m503k().putString("current_path", this.f7181p);
            m502l();
            Document parse = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(file);
            parse.getDocumentElement().normalize();
            String nodeName = parse.getDocumentElement().getNodeName();
            AbstractC2677a a = AbstractC2677a.m330a(this, nodeName);
            a.mo222a(this, file, parse);
            parse.getDocumentElement().setAttribute("Name", C2714o.m5a(this, a.mo186h(), a.mo190f()));
            C2714o.m2a(new File(C2714o.m6a(this), nodeName + "_" + new SimpleDateFormat("yyyyMMddHHmmsszzz", Locale.ENGLISH).format(new Date()) + ".xml"), parse);
            C2709k.m43a(new Date());
            Toast.makeText(this, getString(R.string.settings_ware_imported_successfully), 1).show();
            finish();
        } catch (Throwable th) {
            C2714o.m7a((Activity) this, getString(R.string.error_while_opening_settings_file, new Object[]{file.getName(), th.getMessage()}), true);
        }
    }

    /* renamed from: j */
    public void m504j() {
        if (this.f7181p == null || this.f7181p.equals("")) {
            this.f7182q.setText("/storage");
        } else {
            this.f7182q.setText(this.f7181p);
        }
    }

    /* renamed from: k */
    private SharedPreferences.Editor m503k() {
        if (this.f7184s == null) {
            this.f7184s = getSharedPreferences("RoboCamSettings", 0).edit();
        }
        return this.f7184s;
    }

    /* renamed from: l */
    private void m502l() {
        if (this.f7184s == null) {
            return;
        }
        if (Build.VERSION.SDK_INT >= 9) {
            this.f7184s.apply();
        } else {
            this.f7184s.commit();
        }
    }

    public void onBackButtonClick(View view) {
        onBackPressed();
    }

    @Override
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void onBackPressed() {
        int i;
        if (this.f7181p == null || this.f7181p.equals("")) {
            m503k().putString("current_path", this.f7181p);
            m502l();
            finish();
            return;
        }
        String str = this.f7181p;
        if (!this.f7181p.toLowerCase().equals(System.getenv("EXTERNAL_STORAGE") != null ? System.getenv("EXTERNAL_STORAGE").toLowerCase() : null)) {
            if (!this.f7181p.toLowerCase().equals(System.getenv("SECONDARY_STORAGE") != null ? System.getenv("SECONDARY_STORAGE").toLowerCase() : null) && !this.f7181p.toLowerCase().equals(Environment.getExternalStorageDirectory().getPath().toLowerCase())) {
                this.f7181p = new File(this.f7181p).getParent();
                this.f7180o.clear();
                this.f7180o.addAll(m514a(this.f7181p));
                ((ArrayAdapter) this.f7179n.getAdapter()).notifyDataSetChanged();
                i = 0;
                while (true) {
                    if (i >= this.f7180o.size()) {
                        break;
                    } else if (this.f7180o.get(i).toString().equals(str)) {
                        this.f7185t = i;
                        this.f7179n.post(new Runnable() {
                            @Override
                            public void run() {
                                if (ImportActivity.this.f7185t > 0) {
                                    ImportActivity.this.f7179n.setSelection(ImportActivity.this.f7185t);
                                }
                                ImportActivity.this.f7185t = -1;
                            }
                        });
                        this.f7179n.setSelection(i);
                        break;
                    } else {
                        i++;
                    }
                }
                m504j();
            }
        }
        this.f7181p = null;
        this.f7180o.clear();
        this.f7180o.addAll(m514a(this.f7181p));
        ((ArrayAdapter) this.f7179n.getAdapter()).notifyDataSetChanged();
        i = 0;
        while (true) {
            if (i >= this.f7180o.size()) {
                break;
            }
            i++;
        }
        m504j();
    }

    public void onCancelButtonClick(View view) {
        m503k().putString("current_path", this.f7181p);
        m502l();
        finish();
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_import);
        try {
            SharedPreferences sharedPreferences = getSharedPreferences("RoboCamSettings", 0);
            if (bundle != null) {
                this.f7181p = bundle.getString("current_path");
            } else {
                this.f7181p = sharedPreferences.getString("current_path", null);
                if (this.f7181p != null) {
                    File file = new File(this.f7181p);
                    if (!file.exists() || !file.isDirectory()) {
                        this.f7181p = null;
                    }
                }
            }
            this.f7183r = this;
            this.f7182q = (TextView) findViewById(R.id.fileTextView);
            m504j();
            this.f7179n = (ListView) findViewById(R.id.fileListView);
            this.f7180o.addAll(m514a(this.f7181p));
            ArrayAdapter<File> arrayAdapter = new ArrayAdapter<File>(this, R.layout.spinner_item, this.f7180o) {
                @Override
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                */
                public View getView(int i, View view, ViewGroup viewGroup) {
                    String name;
                    String str = null;
                    if (view == null) {
                        view = ImportActivity.this.getLayoutInflater().inflate(R.layout.spinner_item, viewGroup, false);
                    }
                    File item = getItem(i);
                    if (item.isDirectory()) {
                        if (!item.getPath().toLowerCase().equals(System.getenv("EXTERNAL_STORAGE") != null ? System.getenv("EXTERNAL_STORAGE").toLowerCase() : null)) {
                            String lowerCase = item.getPath().toLowerCase();
                            if (System.getenv("SECONDARY_STORAGE") != null) {
                                str = System.getenv("SECONDARY_STORAGE").toLowerCase();
                            }
                            if (!lowerCase.equals(str)) {
                            }
                        }
                        name = item.getPath();
                        ((TextView) view.findViewById(R.id.textView1)).setText(name);
                        ((TextView) view.findViewById(R.id.textView2)).setVisibility(8);
                        ((ImageView) view.findViewById(R.id.imageView)).setVisibility(0);
                        if (!item.isDirectory()) {
                            ((ImageView) view.findViewById(R.id.imageView)).setImageResource(R.drawable.folder);
                        } else {
                            ((ImageView) view.findViewById(R.id.imageView)).setImageResource(R.drawable.document);
                        }
                        return view;
                    }
                    name = item.getName();
                    ((TextView) view.findViewById(R.id.textView1)).setText(name);
                    ((TextView) view.findViewById(R.id.textView2)).setVisibility(8);
                    ((ImageView) view.findViewById(R.id.imageView)).setVisibility(0);
                    if (!item.isDirectory()) {
                    }
                    return view;
                }
            };
            this.f7179n.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                    ArrayAdapter arrayAdapter2 = (ArrayAdapter) ImportActivity.this.f7179n.getAdapter();
                    File file2 = (File) arrayAdapter2.getItem(i);
                    if (file2.isDirectory()) {
                        ImportActivity.this.f7181p = file2.getPath();
                        ImportActivity.this.f7180o.clear();
                        ImportActivity.this.f7180o.addAll(ImportActivity.this.m514a(ImportActivity.this.f7181p));
                        arrayAdapter2.notifyDataSetChanged();
                        ImportActivity.this.f7179n.setSelectionAfterHeaderView();
                        ImportActivity.this.m504j();
                        return;
                    }
                    ImportActivity.this.m515a(file2);
                }
            });
            this.f7179n.setAdapter((ListAdapter) arrayAdapter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onRestoreInstanceState(Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        this.f7181p = bundle.getString("current_path");
    }

    @Override
    public void onSaveInstanceState(Bundle bundle) {
        bundle.putString("current_path", this.f7181p);
        super.onSaveInstanceState(bundle);
    }
}
