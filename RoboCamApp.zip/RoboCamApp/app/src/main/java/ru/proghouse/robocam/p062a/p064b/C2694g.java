package ru.proghouse.robocam.p062a.p064b;

@SuppressWarnings("ALL")
public class C2694g {

    /* renamed from: a */
    private int f7536a;

    /* renamed from: b */
    private int f7537b;

    /* renamed from: c */
    private volatile boolean f7538c = false;

    /* renamed from: d */
    private volatile float f7539d = 1.0f;

    /* renamed from: e */
    private volatile int f7540e = C2687c.f7455a;

    /* renamed from: f */
    private volatile int f7541f = 0;

    /* renamed from: g */
    private volatile float f7542g = 0.0f;

    /* renamed from: h */
    private volatile int f7543h = 0;

    /* renamed from: i */
    private volatile int f7544i = 1;

    public C2694g(int i, int i2) {
        this.f7536a = 0;
        this.f7537b = 0;
        this.f7536a = i;
        this.f7537b = i2;
    }

    /* renamed from: a */
    public int m105a() {
        return this.f7536a;
    }

    /* renamed from: a */
    public void m104a(float f) {
        this.f7542g = f;
    }

    /* renamed from: a */
    public void m103a(int i) {
        this.f7541f = i;
    }

    /* renamed from: a */
    public void m102a(C2694g gVar) {
        if (this.f7543h > 0 && gVar.f7537b == this.f7537b && gVar.f7540e == this.f7540e && gVar.f7536a == this.f7536a) {
            C2694g i = gVar.m89i();
            if (this.f7540e == C2687c.f7455a) {
                this.f7541f = i.f7541f + this.f7541f;
            } else {
                this.f7542g += i.f7542g;
                this.f7541f = i.f7541f + this.f7541f;
            }
            if (gVar.f7544i == 0 && this.f7544i == 0) {
                this.f7544i = 0;
            } else {
                this.f7544i = 1;
            }
            this.f7543h++;
        }
    }

    /* renamed from: a */
    public void m101a(boolean z) {
        this.f7538c = z;
    }

    /* renamed from: b */
    public float m100b() {
        return this.f7542g;
    }

    /* renamed from: b */
    public void m99b(float f) {
        this.f7539d = f;
    }

    /* renamed from: b */
    public void m98b(int i) {
        this.f7540e = i;
    }

    /* renamed from: b */
    public boolean m97b(C2694g gVar) {
        return gVar.f7536a == this.f7536a && gVar.f7541f == this.f7541f && gVar.f7542g == this.f7542g && gVar.f7540e == this.f7540e && gVar.f7538c == this.f7538c && gVar.f7537b == this.f7537b && gVar.f7539d == this.f7539d && this.f7544i == this.f7544i;
    }

    /* renamed from: c */
    public int m96c() {
        return this.f7541f;
    }

    /* renamed from: c */
    public void m95c(int i) {
        this.f7544i = i;
    }

    /* renamed from: d */
    public int m94d() {
        return this.f7540e;
    }

    /* renamed from: e */
    public boolean m93e() {
        return this.f7538c;
    }

    /* renamed from: f */
    public float m92f() {
        return this.f7539d;
    }

    /* renamed from: g */
    public int m91g() {
        return this.f7537b;
    }

    /* renamed from: h */
    public int m90h() {
        return this.f7544i;
    }

    /* renamed from: i */
    public C2694g m89i() {
        C2694g gVar = new C2694g(this.f7536a, this.f7537b);
        gVar.f7540e = this.f7540e;
        gVar.f7544i = this.f7544i;
        if (this.f7540e == C2687c.f7455a) {
            gVar.f7541f = Math.round(this.f7541f * this.f7539d);
            if (this.f7538c) {
                gVar.f7541f *= -1;
            }
        } else {
            gVar.f7542g = this.f7542g * this.f7539d;
            if (this.f7538c) {
                gVar.f7542g = (float) (gVar.f7542g * (-1.0d));
            }
            gVar.f7541f = Math.abs(this.f7541f);
        }
        gVar.f7543h = 1;
        return gVar;
    }

    /* renamed from: j */
    public String m88j() {
        return new Integer(this.f7536a).toString() + ":" + new Integer(C2687c.m198c(this.f7537b)).toString();
    }

    /* renamed from: k */
    public int m87k() {
        if (this.f7541f > 100) {
            return 100;
        }
        if (this.f7541f < -100) {
            return -100;
        }
        return this.f7541f;
    }

    /* renamed from: l */
    public Object m86l() {
        switch (this.f7537b) {
            case 1:
                return "A";
            case 2:
                return "B";
            case 3:
            case 5:
            case 6:
            case 7:
            default:
                return Integer.valueOf(this.f7537b);
            case 4:
                return "C";
            case 8:
                return "D";
        }
    }
}
