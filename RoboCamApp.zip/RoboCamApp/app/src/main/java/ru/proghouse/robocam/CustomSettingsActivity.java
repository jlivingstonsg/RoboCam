package ru.proghouse.robocam;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

@SuppressWarnings("ALL")
public class CustomSettingsActivity extends AppCompatActivity implements View.OnClickListener {

    /* renamed from: o */
    private String f7009o;

    /* renamed from: n */
    private int f7008n = 0;

    /* renamed from: p */
    private ImageButton f7010p = null;

    /* renamed from: q */
    private EditText f7011q = null;

    /* renamed from: r */
    private EditText f7012r = null;

    /* renamed from: s */
    private CheckBox f7013s = null;

    /* renamed from: t */
    private CheckBox f7014t = null;

    /* renamed from: u */
    private CheckBox f7015u = null;

    /* renamed from: v */
    private EditText f7016v = null;

    /* renamed from: w */
    private EditText f7017w = null;

    /* renamed from: x */
    private LinearLayout f7018x = null;

    /* renamed from: y */
    private C2704f f7019y = null;

    /* renamed from: z */
    private HashSet<Integer> f7020z = new HashSet<>();

    /* renamed from: A */
    private C2618a[] f7007A = new C2618a[4];

    @SuppressWarnings("ALL")
    public class C2618a {

        /* renamed from: a */
        int f7022a;

        /* renamed from: b */
        public CheckBox f7023b;

        /* renamed from: c */
        public ImageView f7024c;

        /* renamed from: d */
        public Spinner f7025d;

        /* renamed from: e */
        public ImageView f7026e;

        /* renamed from: f */
        public Spinner f7027f;

        /* renamed from: g */
        public ImageView f7028g;

        /* renamed from: h */
        public Spinner f7029h;

        /* renamed from: j */
        private C2618a f7031j;

        public C2618a(Activity activity, int i) {
            this.f7031j = null;
            this.f7031j = this;
            switch (i) {
                case 0:
                    m615a(activity, i, R.id.checkBoxJoystickVisibility1, R.id.spinnerJoystickShape1, R.id.imageViewJoystickBehavior1_1, R.id.imageViewJoystickBehavior1_2, R.id.spinnerJoystickBehavior1_1, R.id.spinnerJoystickBehavior1_2, R.id.imageView1_1);
                    return;
                case 1:
                    m615a(activity, i, R.id.checkBoxJoystickVisibility2, R.id.spinnerJoystickShape2, R.id.imageViewJoystickBehavior2_1, R.id.imageViewJoystickBehavior2_2, R.id.spinnerJoystickBehavior2_1, R.id.spinnerJoystickBehavior2_2, R.id.imageView2_1);
                    return;
                case 2:
                    m615a(activity, i, R.id.checkBoxJoystickVisibility3, R.id.spinnerJoystickShape3, R.id.imageViewJoystickBehavior3_1, R.id.imageViewJoystickBehavior3_2, R.id.spinnerJoystickBehavior3_1, R.id.spinnerJoystickBehavior3_2, R.id.imageView3_1);
                    return;
                case 3:
                    m615a(activity, i, R.id.checkBoxJoystickVisibility4, R.id.spinnerJoystickShape4, R.id.imageViewJoystickBehavior4_1, R.id.imageViewJoystickBehavior4_2, R.id.spinnerJoystickBehavior4_1, R.id.spinnerJoystickBehavior4_2, R.id.imageView4_1);
                    return;
                default:
                    return;
            }
        }

        /* renamed from: a */
        public void m616a() {
            int i = this.f7023b.isChecked() ? 0 : 8;
            this.f7031j.f7024c.setVisibility(i);
            this.f7031j.f7025d.setVisibility(i);
            m613b();
        }

        /* renamed from: a */
        private void m615a(Activity activity, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
            this.f7022a = i;
            this.f7023b = (CheckBox) activity.findViewById(i2);
            this.f7024c = (ImageView) activity.findViewById(i8);
            this.f7025d = (Spinner) activity.findViewById(i3);
            C2712m.m18a(this.f7025d, activity, Arrays.asList(activity.getString(R.string.joystick_shape_vertical), activity.getString(R.string.joystick_shape_horizontal), activity.getString(R.string.joystick_shape_circular), activity.getString(R.string.joystick_shape_quadratic), activity.getString(R.string.joystick_shape_arrows), activity.getString(R.string.joystick_shape_vertical_arrows), activity.getString(R.string.joystick_shape_horizontal_arrows)), R.string.joystick_shape);
            this.f7026e = (ImageView) activity.findViewById(i4);
            this.f7028g = (ImageView) activity.findViewById(i5);
            this.f7027f = (Spinner) activity.findViewById(i6);
            C2712m.m18a(this.f7027f, activity, Arrays.asList(activity.getString(R.string.joystick_behavior_return_to_zero), activity.getString(R.string.joystick_behavior_hold_position)), R.string.joystick_behavior1);
            this.f7029h = (Spinner) activity.findViewById(i7);
            C2712m.m18a(this.f7029h, activity, Arrays.asList(activity.getString(R.string.joystick_behavior_return_to_zero), activity.getString(R.string.joystick_behavior_hold_position)), R.string.joystick_behavior2);
            this.f7023b.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    C2618a.this.m616a();
                }
            });
            this.f7025d.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i9, long j) {
                    C2618a.this.m613b();
                    C2618a.this.m611c();
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                }
            });
            this.f7025d.setSelection(2);
            m616a();
        }

        /* renamed from: b */
        public void m613b() {
            int i;
            int i2 = 0;
            i2 = 8;
            switch (this.f7025d.getSelectedItemPosition()) {
                case 0:
                    i = 0;
                    i2 = 8;
                    break;
                case 1:
                    i = 8;
                    break;
                case 2:
                case 3:
                default:
                    i = 0;
                    break;
                case 4:
                case 5:
                case 6:
                    i2 = 8;
                    i = 8;
                    break;
            }
            if (this.f7025d.getVisibility() != 0) {
                i = 8;
            }
            this.f7026e.setVisibility(i2);
            this.f7027f.setVisibility(i2);
            this.f7028g.setVisibility(i);
            this.f7029h.setVisibility(i);
        }

        /* renamed from: c */
        public void m611c() {
            switch (this.f7025d.getSelectedItemPosition()) {
                case 0:
                case 5:
                    if (!(this.f7022a == 0 || this.f7022a == 1 || this.f7022a != 2)) {
                        return;
                    }
                    return;
                case 1:
                case 6:
                    if (!(this.f7022a == 0 || this.f7022a == 1 || this.f7022a != 2)) {
                        return;
                    }
                    return;
                case 2:
                case 3:
                case 4:
                    if (!(this.f7022a == 0 || this.f7022a == 1 || this.f7022a != 2)) {
                        return;
                    }
                    return;
                default:
                    return;
            }
        }
    }

    /* renamed from: a */
    private String m623a(boolean z, boolean z2) {
        File file = null;
        String str;
        (z ? new File(Environment.getExternalStorageDirectory(), ".robocam") : Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)).mkdirs();
        String str2 = "RoboCam_";
        String obj = this.f7011q.getText().toString();
        if (obj != null && !obj.isEmpty()) {
            str2 = str2 + obj.replace("\\", "_").replace("/", "_").replace(":", "_").replace(" ", "_") + "_";
        }
        String str3 = str2 + new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(new Date());
        if (z2 || !new File(file.getPath() + "/" + str3 + ".xml").exists()) {
            str = str3;
        } else {
            int i = 2;
            while (new File(file.getPath() + "/" + str3 + "_" + Integer.toString(i) + ".xml").exists()) {
                i++;
            }
            str = str3 + "_" + Integer.toString(i);
        }
        String str4 = file.getPath() + "/" + str + ".xml";
        C2714o.m1a(str4, m621k());
        return str4;
    }

    /* renamed from: a */
    private void m627a(File file) {
        try {
            m625a(DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(file));
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
    }

    /* renamed from: a */
    private void m626a(String str) {
        try {
            m625a(DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new InputSource(new StringReader(str))));
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
    }

    /* renamed from: a */
    private void m625a(Document document) {
        document.getDocumentElement().normalize();
        String nodeName = document.getDocumentElement().getNodeName();
        if (!nodeName.equals("Custom")) {
            try {
                throw new Exception(getString(R.string.unknown_driver_name, new Object[]{nodeName}));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        this.f7011q.setText(document.getDocumentElement().getAttribute("Name"));
        this.f7012r.setText(document.getDocumentElement().getAttribute("Description"));
        this.f7016v.setText(document.getDocumentElement().getAttribute("Callsign"));
        this.f7017w.setText(document.getDocumentElement().getAttribute("Response"));
        this.f7013s.setChecked(C2713n.m10a(document.getDocumentElement().getAttribute("ShowDebugInfo"), true));
        this.f7014t.setChecked(C2713n.m10a(document.getDocumentElement().getAttribute("HideJoysticks"), true));
        NodeList elementsByTagName = document.getElementsByTagName("Joystick");
        for (int i = 0; i < elementsByTagName.getLength(); i++) {
            Element element = (Element) elementsByTagName.item(i);
            int a = C2713n.m12a(element.getAttribute("Index"), -1);
            if (a >= 0 && a < 4) {
                C2618a aVar = this.f7007A[a];
                aVar.f7023b.setChecked(C2713n.m10a(element.getAttribute("Visible"), false));
                String a2 = C2713n.m11a(element.getAttribute("Shape"), "c");
                if (a2.equals("v")) {
                    aVar.f7025d.setSelection(0);
                } else if (a2.equals("h")) {
                    aVar.f7025d.setSelection(1);
                } else if (a2.equals("c")) {
                    aVar.f7025d.setSelection(2);
                } else if (a2.equals("q")) {
                    aVar.f7025d.setSelection(3);
                } else if (a2.equals("a")) {
                    aVar.f7025d.setSelection(4);
                } else if (a2.equals("l")) {
                    aVar.f7025d.setSelection(5);
                } else if (a2.equals("t")) {
                    aVar.f7025d.setSelection(6);
                }
                aVar.f7027f.setSelection(C2713n.m12a(element.getAttribute("Behavior0"), 0));
                aVar.f7029h.setSelection(C2713n.m12a(element.getAttribute("Behavior1"), 0));
            }
        }
        this.f7020z.clear();
        this.f7019y.m50b(this);
        NodeList elementsByTagName2 = document.getElementsByTagName("KeyGroup");
        for (int i2 = 0; i2 < elementsByTagName2.getLength(); i2++) {
            Element element2 = (Element) elementsByTagName2.item(i2);
            this.f7015u.setChecked(C2713n.m10a(element2.getAttribute("Active"), false));
            NodeList elementsByTagName3 = element2.getElementsByTagName("Key");
            for (int i3 = 0; i3 < elementsByTagName3.getLength(); i3++) {
                Integer valueOf = Integer.valueOf(((Element) elementsByTagName3.item(i3)).getTextContent());
                if (valueOf.intValue() > 0 && valueOf.intValue() <= 255) {
                    this.f7020z.add(valueOf);
                }
            }
        }
        this.f7019y.m52a(this, this.f7020z);
    }

    /* renamed from: j */
    private String m622j() {
        try {
            DOMSource dOMSource = new DOMSource(m621k());
            StringWriter stringWriter = new StringWriter();
            TransformerFactory.newInstance().newTransformer().transform(dOMSource, new StreamResult(stringWriter));
            return stringWriter.toString();
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.error_while_creating_settings_xml, new Object[]{e.getLocalizedMessage()}), 1).show();
            return null;
        }
    }

    /* renamed from: k */
    private Document m621k() {
        C2618a[] aVarArr;
        Document newDocument = null;
        try {
            newDocument = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
        newDocument.appendChild(newDocument.createElement("Custom"));
        Element documentElement = newDocument.getDocumentElement();
        documentElement.setAttribute("Name", this.f7011q.getText().toString());
        documentElement.setAttribute("Description", this.f7012r.getText().toString());
        documentElement.setAttribute("Callsign", this.f7016v.getText().toString());
        documentElement.setAttribute("Response", this.f7017w.getText().toString());
        if (!this.f7013s.isChecked()) {
            documentElement.setAttribute("ShowDebugInfo", "0");
        }
        if (!this.f7014t.isChecked()) {
            documentElement.setAttribute("HideJoysticks", "0");
        }
        int i = 0;
        for (C2618a aVar : this.f7007A) {
            Element createElement = newDocument.createElement("Joystick");
            documentElement.appendChild(createElement);
            createElement.setAttribute("Index", Integer.toString(i));
            if (aVar.f7023b.isChecked()) {
                createElement.setAttribute("Visible", "1");
            }
            switch (aVar.f7025d.getSelectedItemPosition()) {
                case 0:
                    createElement.setAttribute("Shape", "v");
                    break;
                case 1:
                    createElement.setAttribute("Shape", "h");
                    break;
                case 2:
                    if (aVar.f7023b.isChecked()) {
                        createElement.setAttribute("Shape", "c");
                        break;
                    }
                    break;
                case 3:
                    createElement.setAttribute("Shape", "q");
                    break;
                case 4:
                    createElement.setAttribute("Shape", "a");
                    break;
                case 5:
                    createElement.setAttribute("Shape", "l");
                    break;
                case 6:
                    createElement.setAttribute("Shape", "t");
                    break;
            }
            if (aVar.f7027f.getSelectedItemPosition() != 0) {
                createElement.setAttribute("Behavior0", Integer.toString(aVar.f7027f.getSelectedItemPosition()));
            }
            if (aVar.f7029h.getSelectedItemPosition() != 0) {
                createElement.setAttribute("Behavior1", Integer.toString(aVar.f7029h.getSelectedItemPosition()));
            }
            i++;
        }
        Element createElement2 = newDocument.createElement("KeyGroup");
        documentElement.appendChild(createElement2);
        if (this.f7015u.isChecked()) {
            createElement2.setAttribute("Active", "1");
        }
        if (this.f7019y.f7560a != null) {
            Iterator<Integer> it = this.f7019y.f7560a.iterator();
            while (it.hasNext()) {
                Element createElement3 = newDocument.createElement("Key");
                createElement2.appendChild(createElement3);
                createElement3.setTextContent(it.next().toString());
            }
        }
        return newDocument;
    }

    /* renamed from: l */
    private File m620l() {
        return new File(C2714o.m6a(this), this.f7009o);
    }

    /* renamed from: m */
    private void m619m() {
        if (C2714o.m9a(this, 1)) {
            try {
                C2714o.m7a((Activity) this, getString(R.string.settings_ware_exported_successfully, new Object[]{m623a(false, false)}), false);
            } catch (Exception e) {
                Toast.makeText(this, getString(R.string.error_while_exporting_settings_xml, new Object[]{e.getLocalizedMessage()}), 1).show();
            }
        }
    }

    /* renamed from: n */
    private void m618n() {
        if (C2714o.m9a(this, 2)) {
            try {
                String a = m623a(true, true);
                Intent intent = new Intent();
                intent.setAction("android.intent.action.SEND");
                intent.setType("text/xml");
                intent.putExtra("android.intent.extra.STREAM", Uri.fromFile(new File(a)));
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, getString(R.string.error_while_exporting_settings_xml, new Object[]{e.getLocalizedMessage()}), 1).show();
            }
        }
    }

    /* renamed from: o */
    private void m617o() {
        try {
            Document k = m621k();
            k.getDocumentElement().setAttribute("Name", C2714o.m5a(this, this.f7011q.getText().toString(), "Custom"));
            C2714o.m2a(new File(C2714o.m6a(this), "Custom_" + new SimpleDateFormat("yyyyMMddHHmmsszzz", Locale.ENGLISH).format(new Date()) + ".xml"), k);
            C2709k.m43a(new Date());
            Toast.makeText(this, getString(R.string.settings_ware_copied_successfully), 1).show();
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.error_while_copying_settings_xml, new Object[]{e.getLocalizedMessage()}), 1).show();
        }
    }

    @Override
    protected void onActivityResult(int i, int i2, Intent intent) {
        if (i2 == -1) {
            switch (i) {
                case 1:
                    this.f7019y.m51a(this, intent.getIntArrayExtra("android.intent.extra.STREAM"));
                    return;
                default:
                    return;
            }
        }
    }

    public void onCancelButtonClick(View view) {
        finish();
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.buttonOverflow) {
            view.showContextMenu();
        } else if (C2704f.class.isAssignableFrom(view.getClass())) {
            ((C2704f) view).m54a(this, 1);
        }
    }

    @Override
    public boolean onContextItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == -2) {
            m618n();
        } else if (menuItem.getItemId() == -3) {
            m619m();
        } else if (menuItem.getItemId() == -4) {
            m617o();
        }
        return super.onContextItemSelected(menuItem);
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_custom_settings);
        this.f7010p = (ImageButton) findViewById(R.id.buttonOverflow);
        this.f7010p.setOnClickListener(this);
        registerForContextMenu(this.f7010p);
        if (Build.VERSION.SDK_INT < 17) {
            this.f7008n = new CheckBox(this).getPaddingLeft();
        }
        this.f7011q = (EditText) findViewById(R.id.editTextBotName);
        this.f7012r = (EditText) findViewById(R.id.editTextDesc);
        this.f7013s = (CheckBox) findViewById(R.id.checkBoxShowDebugInfo);
        this.f7014t = (CheckBox) findViewById(R.id.checkBoxHideJoysticks);
        this.f7016v = (EditText) findViewById(R.id.editTextCallsign);
        this.f7017w = (EditText) findViewById(R.id.editTextResponse);
        this.f7015u = (CheckBox) findViewById(R.id.checkBoxActive);
        this.f7018x = (LinearLayout) findViewById(R.id.keygroupLayout);
        this.f7019y = C2704f.m53a(this, this.f7018x, this.f7020z, R.string.keys, getString(R.string.keys));
        this.f7019y.setOnClickListener(this);
        this.f7015u.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                CustomSettingsActivity.this.f7018x.setVisibility(z ? 0 : 8);
            }
        });
        this.f7009o = getIntent().getStringExtra("SettingsFileName");
        if (this.f7009o == null || this.f7009o.equals("")) {
            String string = bundle != null ? bundle.getString("SettingsFileName") : null;
            if (string == null || string.equals("")) {
                this.f7009o = "Custom_" + new SimpleDateFormat("yyyyMMddHHmmsszzz", Locale.ENGLISH).format(new Date()) + ".xml";
            } else {
                this.f7009o = string;
            }
        }
        for (int i = 0; i < 4; i++) {
            this.f7007A[i] = new C2618a(this, i);
        }
        String string2 = bundle != null ? bundle.getString("SettingsXml") : null;
        if (string2 == null || string2.equals("")) {
            File l = m620l();
            if (l.exists()) {
                try {
                    m627a(l);
                } catch (Exception e) {
                    Toast.makeText(this, getString(R.string.error_while_opening_settings_file, new Object[]{this.f7009o, e.getLocalizedMessage()}), 1).show();
                }
            }
        } else {
            try {
                m626a(string2);
            } catch (Exception e2) {
                Toast.makeText(this, getString(R.string.error_while_opening_settings, new Object[]{e2.getLocalizedMessage()}), 1).show();
            }
        }
    }

    @Override
    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        super.onCreateContextMenu(contextMenu, view, contextMenuInfo);
        contextMenu.add(0, -2, 0, R.string.action_send_robot_settings);
        contextMenu.add(0, -3, 0, R.string.action_export_robot_settings_to_file);
        contextMenu.add(0, -4, 0, R.string.action_copy_robot_settings);
    }

    @Override
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i != 1 && i != 2) {
            super.onRequestPermissionsResult(i, strArr, iArr);
        } else if (iArr.length != 1 || iArr[0] != 0) {
            C2714o.m8a((Activity) this, (int) R.string.request_write_external_storage_permission, false);
        } else if (i == 1) {
            m619m();
        } else if (i == 2) {
            m617o();
        }
    }

    @Override
    protected void onRestoreInstanceState(Bundle bundle) {
        super.onRestoreInstanceState(bundle);
        this.f7009o = bundle.getString("SettingsFileName");
    }

    public void onSaveButtonClick(View view) {
        try {
            TransformerFactory.newInstance().newTransformer().transform(new DOMSource(m621k()), new StreamResult(new FileOutputStream(m620l())));
            C2709k.m43a(new Date());
            Toast.makeText(this, (int) R.string.settings_were_saved, 0).show();
            finish();
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.error_while_creating_settings_xml, new Object[]{e.getLocalizedMessage()}), 1).show();
        }
    }

    @Override
    public void onSaveInstanceState(Bundle bundle) {
        bundle.putString("SettingsFileName", this.f7009o);
        bundle.putString("SettingsXml", m622j());
        super.onSaveInstanceState(bundle);
    }
}
