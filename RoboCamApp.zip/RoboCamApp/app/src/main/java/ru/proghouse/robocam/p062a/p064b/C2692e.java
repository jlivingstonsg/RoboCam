package ru.proghouse.robocam.p062a.p064b;

import java.util.ArrayList;
import java.util.List;
import ru.proghouse.robocam.p062a.C2684b;

@SuppressWarnings("ALL")
public class C2692e extends C2684b implements AbstractC2686b {

    /* renamed from: a */
    private int f7502a = 0;

    /* renamed from: b */
    private int f7503b = 0;

    /* renamed from: c */
    private int f7504c = 0;

    /* renamed from: d */
    private int f7505d = 0;

    /* renamed from: e */
    private boolean f7506e = true;

    /* renamed from: f */
    private List<C2694g> f7507f = new ArrayList();

    /* renamed from: g */
    private List<C2694g> f7508g = new ArrayList();

    /* renamed from: h */
    private int f7509h = 0;

    /* renamed from: a */
    public int m142a() {
        return this.f7502a;
    }

    @Override
    /* renamed from: a */
    public List<C2694g> mo136a(int i) {
        return i == 0 ? this.f7507f : this.f7508g;
    }

    /* renamed from: a */
    public void m141a(Integer a0, Integer a1) {
        label20: {
            label21: {
                if (a0 != null) {
                    break label21;
                }
                if (a1 == null) {
                    break label20;
                }
            }
            if (a0 != null) {
                f7502a = a0.intValue();
            }
            if (a1 != null) {
                f7503b = a1.intValue();
            }
            int i = f7502a;
            int i0 = f7504c;
            label11: {
                label19: {
                    if (i != i0) {
                        break label19;
                    }
                    if (f7503b == f7505d) {
                        break label11;
                    }
                }
                if (!"-".equals((Object)m268d())) {
                    int i1 = f7509h;
                    label17: {
                        label18: {
                            if (i1 == 0) {
                                break label18;
                            }
                            if (f7509h == 2) {
                                break label18;
                            }
                            if ("h".equals((Object)m268d())) {
                                break label18;
                            }
                            if ("v".equals((Object)m268d())) {
                                break label18;
                            }
                            if ("t".equals((Object)m268d())) {
                                break label18;
                            }
                            if (!"l".equals((Object)m268d())) {
                                break label17;
                            }
                        }
                        boolean b0 = "h".equals((Object)m268d());
                        label15: {
                            label16: {
                                if (b0) {
                                    break label16;
                                }
                                if (!"t".equals((Object)m268d())) {
                                    break label15;
                                }
                            }
                            f7503b = 0;
                        }
                        boolean b1 = "v".equals((Object)m268d());
                        label13: {
                            label14: {
                                if (b1) {
                                    break label14;
                                }
                                if (!"l".equals((Object)m268d())) {
                                    break label13;
                                }
                            }
                            f7502a = 0;
                        }
                        Object a2 = f7507f.iterator();
                        while(((java.util.Iterator)a2).hasNext()) {
                            ru.proghouse.robocam.p062a.p064b.C2694g a3 = (ru.proghouse.robocam.p062a.p064b.C2694g)((java.util.Iterator)a2).next();
                            if (a3.m94d() != ru.proghouse.robocam.p062a.p064b.C2687c.f7455a) {
                                a3.m104a((float)f7502a);
                            } else {
                                a3.m103a(f7502a);
                            }
                        }
                        Object a4 = f7508g.iterator();
                        while(((java.util.Iterator)a4).hasNext()) {
                            ru.proghouse.robocam.p062a.p064b.C2694g a5 = (ru.proghouse.robocam.p062a.p064b.C2694g)((java.util.Iterator)a4).next();
                            if (a5.m94d() != ru.proghouse.robocam.p062a.p064b.C2687c.f7455a) {
                                a5.m104a((float)f7503b);
                            } else {
                                a5.m103a(f7503b);
                            }
                        }
                        break label11;
                    }
                    int i2 = this.f7509h;
                    label12: {
                        if (i2 == 1) {
                            break label12;
                        }
                        if (f7509h != 3) {
                            break label11;
                        }
                    }
                    int i3 = f7503b;
                    int i4 = f7503b;
                    boolean b2 = "a".equals((Object)m268d());
                    label6: {
                        double d0 = 0.0;
                        double d1 = 0.0;
                        label8: {
                            label5: {
                                label4: {
                                    label10: {
                                        {
                                            label9: {
                                                if (!b2) {
                                                    break label9;
                                                }
                                                if (f7503b != 0) {
                                                    break label6;
                                                }
                                                break label10;
                                            }
                                            int i5 = f7509h;
                                            label7: {
                                                if (i5 == 1) {
                                                    break label7;
                                                }
                                                if (f7509h != 3) {
                                                    break label6;
                                                }
                                                break label8;
                                            }
                                            if (f7502a < 0) {
                                                break label5;
                                            }
                                            if (f7502a > 0) {
                                                break label4;
                                            }
                                        }
                                        break label6;
                                    }
                                    i3 = f7502a;
                                    i4 = -f7502a;
                                    break label6;
                                }
                                i4 = Math.round((float)(i4 * (100 - f7502a) / 100));
                                break label6;
                            }
                            i3 = Math.round((float)(i3 * (100 - Math.abs(f7502a)) / 100));
                            break label6;
                        }
                        double d2 = Math.atan2((double)f7503b, (double)f7502a) * 180.0 / 3.141592653589793;
                        double d3 = Math.sqrt((double)(f7502a * f7502a + f7503b * f7503b));
                        if (d3 > 100.0) {
                            d3 = 100.0;
                        }
                        int i6 = (d2 > 0.0) ? 1 : (d2 == 0.0) ? 0 : -1;
                        label1: {
                            label3: {
                                if (i6 < 0) {
                                    break label3;
                                }
                                if (!(d2 <= 90.0)) {
                                    break label3;
                                }
                                d0 = d2 / 90.0 * 201.0 - 100.0;
                                d1 = 100.0;
                                break label1;
                            }
                            int i7 = (d2 < 0.0) ? -1 : (d2 == 0.0) ? 0 : 1;
                            label2: {
                                if (i7 >= 0) {
                                    break label2;
                                }
                                if (!(d2 >= -90.0)) {
                                    break label2;
                                }
                                d1 = -1.0 * (d2 / 90.0 * -201.0 - 100.0);
                                d0 = -100.0;
                                break label1;
                            }
                            int i8 = (d2 > 90.0) ? 1 : (d2 == 90.0) ? 0 : -1;
                            label0: {
                                if (i8 <= 0) {
                                    break label0;
                                }
                                if (!(d2 <= 180.0)) {
                                    break label0;
                                }
                                d1 = -1.0 * ((d2 - 90.0) / 90.0 * 201.0 - 100.0);
                                d0 = 100.0;
                                break label1;
                            }
                            if (d2 < -90.0) {
                                if (d2 >= -180.0) {
                                    d0 = (90.0 + d2) / 90.0 * -201.0 - 100.0;
                                    d1 = -100.0;
                                } else {
                                    d0 = 0.0;
                                    d1 = 0.0;
                                }
                            } else {
                                d0 = 0.0;
                                d1 = 0.0;
                            }
                        }
                        double d4 = d1 / 100.0;
                        i4 = (int)Math.round(d0 / 100.0 * d3);
                        i3 = (int)Math.round(d4 * d3);
                    }
                    Object a6 = f7507f.iterator();
                    while(((java.util.Iterator)a6).hasNext()) {
                        ((ru.proghouse.robocam.p062a.p064b.C2694g)((java.util.Iterator)a6).next()).m103a(i3);
                    }
                    Object a7 = f7508g.iterator();
                    while(((java.util.Iterator)a7).hasNext()) {
                        ((ru.proghouse.robocam.p062a.p064b.C2694g)((java.util.Iterator)a7).next()).m103a(i4);
                    }
                }
            }
            f7504c = f7502a;
            f7505d = f7503b;
        }
    }


    /* renamed from: b */
    public int m140b() {
        return this.f7503b;
    }

    /* renamed from: b */
    public void m139b(int i) {
        this.f7509h = i;
    }

    /* renamed from: c */
    public int m138c() {
        return this.f7509h;
    }
}
