package ru.proghouse.robocam.p062a.p064b;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import ru.proghouse.robocam.C2709k;
import ru.proghouse.robocam.C2713n;
import ru.proghouse.robocam.C2714o;
import ru.proghouse.robocam.R;
import ru.proghouse.robocam.p062a.AbstractC2677a;
import ru.proghouse.robocam.p062a.C2695c;
import ru.proghouse.robocam.p062a.C2696d;

@SuppressWarnings("ALL")
public class C2687c extends AbstractC2677a {

    /* renamed from: a */
    public static int f7455a = 0;

    /* renamed from: b */
    public static int f7456b = 1;

    /* renamed from: c */
    static final String[] f7457c = {"x", "y", "w", "z", "a", "b", "c", "d"};

    /* renamed from: d */
    private int[] f7460d = new int[8];

    /* renamed from: e */
    private List<C2692e> f7461e = new ArrayList();

    /* renamed from: f */
    private List<C2693f> f7462f = new ArrayList();

    /* renamed from: g */
    private boolean f7463g = false;

    /* renamed from: h */
    private HashSet<Integer> f7464h = new HashSet<>();

    /* renamed from: i */
    private boolean f7465i = false;

    /* renamed from: j */
    private String f7466j = "";

    /* renamed from: k */
    private Object f7467k = new Object();

    /* renamed from: l */
    private Object f7468l = new Object();

    /* renamed from: m */
    private volatile BluetoothSocket f7469m = null;

    /* renamed from: n */
    private volatile BluetoothDevice f7470n = null;

    /* renamed from: o */
    private HashSet<Integer> f7471o = new HashSet<>();

    /* renamed from: p */
    private Hashtable<String, C2691d> f7472p = new Hashtable<>();

    /* renamed from: q */
    private Hashtable<String, C2694g> f7473q = new Hashtable<>();

    /* renamed from: r */
    private List<C2694g> f7474r = new ArrayList();

    /* renamed from: s */
    private volatile int f7475s = 100;

    /* renamed from: t */
    private volatile int f7476t = 0;

    /* renamed from: u */
    private volatile boolean f7477u = false;

    /* renamed from: v */
    private final Object f7478v = new Object();

    /* renamed from: w */
    private final Object f7479w = new Object();

    /* renamed from: x */
    private Hashtable<String, Integer> f7480x = new Hashtable<>();

    /* renamed from: y */
    private volatile String f7481y = "";

    /* renamed from: z */
    private volatile String f7482z = "";

    /* renamed from: A */
    private volatile long f7458A = 0;

    /* renamed from: B */
    private volatile boolean f7459B = true;

    @SuppressWarnings("ALL")
    public class RunnableC2688a implements Runnable {

        /* renamed from: d */
        private C2687c f7486d = null;

        /* renamed from: e */
        private boolean f7487e = true;

        /* renamed from: a */
        HashSet<Integer> f7483a = null;

        /* renamed from: b */
        long f7484b = System.currentTimeMillis();

        RunnableC2688a() {
        }

        /* renamed from: a */
        private void m153a(String str, int i) {
            try {
                C2685a aVar = new C2685a();
                aVar.m264a(129, 158);
                C2696d.m76a((OutputStream) aVar.f7453a, str.length() + 1);
                C2696d.m66b(aVar.f7453a, str);
                C2696d.m67b(aVar.f7453a, 4);
                C2696d.m77a((OutputStream) aVar.f7453a, i);
                C2687c.this.m218a(aVar);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        /* renamed from: a */
        public void m154a() {
            Hashtable<String, Integer> hashtable;
            while (C2687c.this.f7476t != 2 && C2687c.this.f7469m != null) {
                synchronized (C2687c.this.f7479w) {
                    if (C2687c.this.f7480x.size() > 0) {
                        hashtable = (Hashtable) C2687c.this.f7480x.clone();
                        C2687c.this.f7480x.clear();
                    } else {
                        hashtable = null;
                    }
                    if (C2687c.this.f7463g) {
                        this.f7483a = C2687c.this.f7464h;
                        C2687c.this.f7463g = false;
                        this.f7487e = false;
                    }
                }
                long currentTimeMillis = System.currentTimeMillis();
                if (hashtable != null || (!this.f7487e && currentTimeMillis - this.f7484b >= 100)) {
                    this.f7487e = m152a(hashtable, this.f7483a);
                    if (this.f7487e) {
                        this.f7483a = null;
                    }
                    this.f7484b = currentTimeMillis;
                } else {
                    return;
                }
            }
        }

        /* renamed from: a */
        public boolean m152a(Hashtable<String, Integer> hashtable, HashSet<Integer> hashSet) {
            boolean z = true;
            if (C2687c.this.f7476t != 2 || (hashtable == null && hashSet == null)) {
                try {
                    if (C2687c.this.f7469m != null) {
                        Hashtable hashtable2 = new Hashtable();
                        for (int i = 0; i < 4; i++) {
                            if (hashtable != null && (hashtable.containsKey(C2687c.f7457c[i * 2]) || hashtable.containsKey(C2687c.f7457c[(i * 2) + 1]))) {
                                ((C2692e) C2687c.this.f7461e.get(i)).m141a(hashtable.containsKey(C2687c.f7457c[i * 2]) ? hashtable.get(C2687c.f7457c[i * 2]) : null, hashtable.containsKey(C2687c.f7457c[(i * 2) + 1]) ? hashtable.get(C2687c.f7457c[(i * 2) + 1]) : null);
                            }
                            for (int i2 = 0; i2 < 2; i2++) {
                                for (C2694g gVar : ((C2692e) C2687c.this.f7461e.get(i)).mo136a(i2)) {
                                    String j = gVar.m88j();
                                    if (!hashtable2.containsKey(j)) {
                                        hashtable2.put(j, gVar.m89i());
                                    } else {
                                        ((C2694g) hashtable2.get(j)).m102a(gVar);
                                    }
                                }
                            }
                        }
                        for (C2693f fVar : C2687c.this.f7462f) {
                            if (fVar.m82j() && fVar.m114g() != 2) {
                                z = hashSet != null ? fVar.m120d(hashSet) && z : fVar.m112h() && z;
                                for (int i3 = 0; i3 < 2; i3++) {
                                    for (C2694g gVar2 : fVar.mo136a(i3)) {
                                        String j2 = gVar2.m88j();
                                        if (!hashtable2.containsKey(j2)) {
                                            hashtable2.put(j2, gVar2.m89i());
                                        } else {
                                            ((C2694g) hashtable2.get(j2)).m102a(gVar2);
                                        }
                                    }
                                }
                            }
                        }
                        ArrayList<String> arrayList = new ArrayList();
                        Enumeration keys = hashtable2.keys();
                        while (keys.hasMoreElements()) {
                            String str = (String) keys.nextElement();
                            if (C2687c.this.f7473q.containsKey(str) && ((C2694g) hashtable2.get(str)).m97b((C2694g) C2687c.this.f7473q.get(str))) {
                                arrayList.add(str);
                            }
                        }
                        for (String str2 : arrayList) {
                            hashtable2.remove(str2);
                        }
                        int size = C2687c.this.f7474r.size() * 9;
                        if (hashtable2.size() > 0) {
                            C2685a aVar = null;
                            Enumeration keys2 = hashtable2.keys();
                            while (keys2.hasMoreElements()) {
                                C2694g gVar3 = (C2694g) hashtable2.get(keys2.nextElement());
                                if (gVar3.m94d() == C2687c.f7455a && gVar3.m96c() != 0) {
                                    aVar = C2687c.this.m216a(aVar, 0, size, 0);
                                    aVar.m237l();
                                    aVar.m246g(gVar3.m105a());
                                    aVar.m246g(gVar3.m91g());
                                    aVar.m244h(gVar3.m87k());
                                    aVar.m235m();
                                    aVar.m246g(gVar3.m105a());
                                    aVar.m246g(gVar3.m91g());
                                }
                            }
                            Enumeration keys3 = hashtable2.keys();
                            while (keys3.hasMoreElements()) {
                                C2694g gVar4 = (C2694g) hashtable2.get(keys3.nextElement());
                                if (gVar4.m94d() == C2687c.f7455a && gVar4.m96c() == 0) {
                                    aVar = C2687c.this.m216a(aVar, 0, size, 0);
                                    aVar.m239k();
                                    aVar.m246g(gVar4.m105a());
                                    aVar.m246g(gVar4.m91g());
                                    aVar.m246g(gVar4.m90h());
                                }
                            }
                            for (int i4 = 0; i4 < C2687c.this.f7474r.size(); i4++) {
                                if (hashtable2.containsKey(((C2694g) C2687c.this.f7474r.get(i4)).m88j())) {
                                    int size2 = C2687c.this.f7474r.size() * 8;
                                    aVar = C2687c.this.m216a(aVar, 0, size, 0);
                                    C2694g gVar5 = (C2694g) hashtable2.get(((C2694g) C2687c.this.f7474r.get(i4)).m88j());
                                    int i5 = (i4 * 8) + 0;
                                    int i6 = 0 + (i4 * 8) + 4;
                                    int i7 = size2 + i4;
                                    aVar.m239k();
                                    aVar.m246g(gVar5.m105a());
                                    aVar.m246g(gVar5.m91g());
                                    aVar.m246g(gVar5.m90h());
                                    aVar.m236l(28);
                                    aVar.m246g(gVar5.m105a());
                                    aVar.m246g(C2687c.m198c(gVar5.m91g()));
                                    aVar.m246g(0);
                                    aVar.m246g(0);
                                    aVar.m246g(1);
                                    aVar.m256c(i5);
                                    aVar.m251e();
                                    aVar.m240j(Math.round(gVar5.m100b()));
                                    aVar.m256c(i5);
                                    aVar.m256c(i6);
                                    aVar.m245h();
                                    aVar.m244h(gVar5.m87k());
                                    aVar.m256c(i7);
                                    aVar.m241j();
                                    aVar.m256c(i6);
                                    aVar.m240j(0);
                                    aVar.m240j(0);
                                    int a = aVar.m266a();
                                    aVar.m249f();
                                    aVar.m244h(-1);
                                    aVar.m256c(i7);
                                    aVar.m256c(i7);
                                    aVar.m247g();
                                    aVar.m240j(-1);
                                    aVar.m256c(i6);
                                    aVar.m256c(i6);
                                    aVar.m258b(a - 4, aVar.m266a() - a);
                                    aVar.m231o();
                                    aVar.m246g(gVar5.m105a());
                                    aVar.m246g(gVar5.m91g());
                                    aVar.m256c(i7);
                                    aVar.m240j(0);
                                    aVar.m256c(i6);
                                    aVar.m240j(0);
                                    aVar.m246g(gVar5.m90h());
                                }
                            }
                            if (aVar != null) {
                                if (C2687c.this.m217a(aVar, 1000) != null) {
                                }
                            }
                        }
                        Enumeration keys4 = hashtable2.keys();
                        while (keys4.hasMoreElements()) {
                            String str3 = (String) keys4.nextElement();
                            C2694g gVar6 = (C2694g) C2687c.this.f7473q.get(str3);
                            C2694g gVar7 = (C2694g) hashtable2.get(str3);
                            gVar6.m101a(gVar7.m93e());
                            gVar6.m99b(gVar7.m92f());
                            gVar6.m103a(gVar7.m96c());
                            float b = gVar6.m100b();
                            float b2 = gVar7.m100b();
                            gVar6.m104a(b2);
                            gVar6.m95c(gVar7.m90h());
                            gVar6.m98b(gVar7.m94d());
                            if (b2 != b) {
                                C2687c.this.f7477u = true;
                            }
                        }
                        for (int i8 = 0; i8 < C2687c.this.f7461e.size(); i8++) {
                            if (((C2692e) C2687c.this.f7461e.get(i8)).m138c() == 2) {
                                if (C2687c.this.f7460d[i8 * 2] != ((C2692e) C2687c.this.f7461e.get(i8)).m142a()) {
                                    m153a(C2687c.f7457c[i8 * 2], ((C2692e) C2687c.this.f7461e.get(i8)).m142a());
                                    C2687c.this.f7460d[i8 * 2] = ((C2692e) C2687c.this.f7461e.get(i8)).m142a();
                                }
                                if (C2687c.this.f7460d[(i8 * 2) + 1] != ((C2692e) C2687c.this.f7461e.get(i8)).m140b()) {
                                    m153a(C2687c.f7457c[(i8 * 2) + 1], ((C2692e) C2687c.this.f7461e.get(i8)).m140b());
                                    C2687c.this.f7460d[(i8 * 2) + 1] = ((C2692e) C2687c.this.f7461e.get(i8)).m140b();
                                }
                            }
                        }
                        for (C2693f fVar2 : C2687c.this.f7462f) {
                            if (fVar2.m82j() && fVar2.m114g() == 2 && fVar2.m126b(hashSet)) {
                                int c = fVar2.m123c(hashSet);
                                m153a(fVar2.m129b(), c);
                                fVar2.m134a(c, hashSet);
                            }
                        }
                    }
                } catch (Throwable th) {
                    th.printStackTrace();
                }
            }
            return z;
        }

       @Override
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public void run() {
            while (true) {
                try {
                    synchronized (C2687c.this.f7478v) {
                        if (C2687c.this.f7476t != 2 && C2687c.this.f7469m != null) {
                            C2687c.this.f7478v.wait(100L);
                            if (C2687c.this.f7476t == 2 || C2687c.this.f7469m == null) {
                                break;
                            }
                        } else {
                            break;
                        }
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                m154a();
            }
        }
    }

    @SuppressWarnings("ALL")
    public class RunnableC2689b implements Runnable {

        /* renamed from: b */
        private C2687c f7489b;

        RunnableC2689b(C2687c cVar) {
            this.f7489b = null;
            this.f7489b = cVar;
        }

        @Override
        public void run() {
            byte[] a;
            while (C2687c.this.f7476t != 2 && this.f7489b.f7469m != null && C2687c.this.f7472p.size() != 0) {
                C2685a aVar = new C2685a();
                aVar.m263a(0, C2687c.this.f7472p.size() * 4, 0);
                Enumeration keys = C2687c.this.f7472p.keys();
                int i = 0;
                while (keys.hasMoreElements()) {
                    C2691d dVar = (C2691d) C2687c.this.f7472p.get(keys.nextElement());
                    aVar.m236l(29);
                    aVar.m246g(dVar.m146a());
                    aVar.m246g(dVar.m144b());
                    aVar.m246g(0);
                    aVar.m246g(0);
                    aVar.m246g(1);
                    aVar.m256c(i * 4);
                    i++;
                }
                a = C2687c.this.m217a(aVar, 1000);
                if (C2687c.this.f7476t != 2 && this.f7489b.f7469m != null) {
                    if (a == null || a.length < 3 || a[2] == 4) {
                        C2687c.this.m205b(R.string.ev3_error_no_reply_while_reading_input_port_values);
                        return;
                    }
                    ByteBuffer wrap = ByteBuffer.wrap(a);
                    wrap.order(ByteOrder.LITTLE_ENDIAN);
                    new ArrayList();
                    new ArrayList();
                    new ArrayList();
                    C2687c.this.f7477u = false;
                    Enumeration keys2 = C2687c.this.f7472p.keys();
                    int i2 = 0;
                    while (keys2.hasMoreElements()) {
                        ((C2691d) C2687c.this.f7472p.get(keys2.nextElement())).m145a(wrap.getFloat((i2 * 4) + 3));
                        i2++;
                    }
                    int i3 = 0;
                    while (true) {
                        try {
                            if (i3 * 20 < (C2687c.this.f7477u ? 0 : C2687c.this.f7475s)) {
                                Thread.sleep(20L);
                                i3++;
                            }
                        } catch (InterruptedException e2) {
                            e2.printStackTrace();
                        }
                    }
                } else {
                    return;
                }
            }
        }
    }

    @SuppressWarnings("ALL")
    class RunnableC2690c implements Runnable {

        /* renamed from: b */
        private C2687c f7491b;

        /* renamed from: c */
        private int f7492c = 0;

        /* renamed from: d */
        private Object f7493d = null;

        /* renamed from: e */
        private Object f7494e = null;

        RunnableC2690c(C2687c cVar) {
            this.f7491b = null;
            this.f7491b = cVar;
        }

        /* renamed from: a */
        private void m151a() {
            C2685a aVar = new C2685a();
            aVar.m263a(0, 1020, 0);
            aVar.m234m(3);
            aVar.m240j(255);
            aVar.m265a(0);
            aVar.m234m(9);
            aVar.m240j(255);
            aVar.m265a(255);
            aVar.m234m(10);
            aVar.m240j(255);
            aVar.m265a(510);
            aVar.m234m(26);
            aVar.m240j(255);
            aVar.m265a(765);
            byte[] a = C2687c.this.m217a(aVar, 1000);
            if (a != null && a.length == 1023 && a[2] == 2) {
                String a2 = C2696d.m70a(a, 3, 255);
                String a3 = C2696d.m70a(a, 258, 255);
                String a4 = C2696d.m70a(a, 513, 255);
                String a5 = C2696d.m70a(a, 768, 255);
                if (a2 == null || a3 == null || a4 == null || a5 == null || !a2.startsWith("Linux") || !a3.startsWith("V") || !a4.startsWith("V") || !a5.startsWith("LMS2012")) {
                    this.f7492c = R.string.ev3_error_strange_reply;
                    return;
                }
                return;
            }
            this.f7492c = R.string.ev3_error_unknown_device;
        }

        /* renamed from: b */
        private void m150b() {
            C2685a aVar = new C2685a();
            aVar.m263a(0, 64, 0);
            for (int i = 0; i < 4; i++) {
                int i2 = 0;
                while (i2 < 8) {
                    aVar.m236l(5);
                    aVar.m246g(i);
                    aVar.m246g(i2 < 4 ? i2 : i2 + 12);
                    aVar.m265a((i2 * 2) + (i * 16));
                    aVar.m265a((i2 * 2) + (i * 16) + 1);
                    i2++;
                }
            }
            byte[] a = C2687c.this.m217a(aVar, 1000);
            C2685a aVar2 = null;
            if (a != null && a.length >= 3 && a[2] == 2) {
                for (int i3 = 0; i3 < 4; i3++) {
                    int i4 = 0;
                    while (i4 < 8) {
                        byte b = a[(i4 * 2) + 3 + (i3 * 16)];
                        byte b2 = a[(i4 * 2) + 3 + (i3 * 16) + 1];
                        if (!(b == 126 || b == 125 || b == 255 || b == Byte.MAX_VALUE)) {
                            if (!C2687c.this.f7471o.contains(Integer.valueOf(i3))) {
                                C2687c.this.f7471o.add(Integer.valueOf(i3));
                            }
                            int i5 = i4 < 4 ? i4 : i4 + 12;
                            C2691d dVar = new C2691d(i3, i5, b, b2);
                            C2687c.this.f7472p.put(dVar.m143c(), dVar);
                            if (i5 >= 16) {
                                C2694g gVar = new C2694g(i3, C2687c.m194d(i5));
                                C2687c.this.f7473q.put(gVar.m88j(), gVar);
                                aVar2 = C2687c.this.m216a(aVar2, 128, 0, 0);
                                aVar2.m229p();
                                aVar2.m246g(i3);
                                aVar2.m246g(gVar.m91g());
                            }
                        }
                        i4++;
                    }
                }
                if (aVar2 != null) {
                    C2687c.this.m218a(aVar2);
                    return;
                }
                return;
            }
            this.f7492c = R.string.ev3_error_cannot_read_input_port_list;
        }

        /* renamed from: c */
        private void m149c() {
            if (C2687c.this.f7482z.equals("")) {
                C2687c.this.m162v();
            }
            Hashtable hashtable = new Hashtable();
            for (int i = 0; i < C2687c.this.f7461e.size(); i++) {
                for (int i2 = 0; i2 < 2; i2++) {
                    for (int i3 = 0; i3 < ((C2692e) C2687c.this.f7461e.get(i)).mo136a(i2).size(); i3++) {
                        C2694g gVar = ((C2692e) C2687c.this.f7461e.get(i)).mo136a(i2).get(i3);
                        if (!hashtable.containsKey(gVar.m88j())) {
                            hashtable.put(gVar.m88j(), Integer.valueOf(gVar.m94d()));
                        } else if (!((Integer) hashtable.get(gVar.m88j())).equals(Integer.valueOf(gVar.m94d()))) {
                            this.f7492c = R.string.ev3_error_joysticks_have_different_types_for_same_port;
                            this.f7493d = gVar.m86l();
                        }
                        if (!C2687c.this.f7473q.containsKey(gVar.m88j())) {
                            this.f7492c = R.string.ev3_error_motor_not_connected;
                            this.f7493d = gVar.m86l();
                            return;
                        }
                        ((C2694g) C2687c.this.f7473q.get(gVar.m88j())).m98b(gVar.m94d());
                        if (gVar.m94d() == C2687c.f7456b) {
                            ((C2694g) C2687c.this.f7473q.get(gVar.m88j())).m103a(gVar.m96c());
                            C2687c.this.f7474r.add(C2687c.this.f7473q.get(gVar.m88j()));
                        }
                    }
                }
            }
        }

        /* renamed from: d */
        private void m148d() {
            C2685a aVar = new C2685a();
            aVar.m263a(128, 0, 0);
            aVar.m238k(27);
            aVar.m246g(8);
            C2687c.this.m218a(aVar);
        }

        /* renamed from: e */
        private void m147e() {
            if (this.f7491b.m172o() && this.f7491b.m170p() != null && !"".equals(this.f7491b.m170p())) {
                try {
                    C2685a aVar = new C2685a();
                    aVar.m263a(0, 0, 8);
                    this.f7491b.m204b(aVar);
                    C2687c.this.m217a(aVar, 1000);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        @Override
        public void run() {
            boolean z = true;
            int i = 0;
            while (true) {
                try {
                    this.f7491b.f7469m = this.f7491b.f7470n.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));
                    if (C2687c.this.f7476t == 2) {
                        break;
                    }
                    try {
                        this.f7491b.f7469m.connect();
                    } catch (IOException e) {
                        this.f7491b.f7469m.close();
                        if (i >= 7) {
                            throw e;
                        }
                        z = false;
                    }
                    if (z) {
                        this.f7492c = 0;
                        m151a();
                        if (i >= 7 || this.f7492c == R.string.ev3_error_unknown_device || this.f7492c == 0) {
                            break;
                        }
                    }
                    Thread.sleep(3000L);
                    i++;
                } catch (Exception e2) {
                    if (C2687c.this.f7476t != 2) {
                        e2.printStackTrace();
                        this.f7491b.m324e((int) R.string.ev3_connection_error);
                        this.f7491b.m160w();
                        return;
                    }
                    return;
                }
            }
            if (this.f7492c == 0 && C2687c.this.f7476t != 2) {
                m150b();
            }
            if (this.f7492c == 0 && C2687c.this.f7476t != 2) {
                m149c();
            }
            if (C2687c.this.f7476t == 2) {
                return;
            }
            if (this.f7492c == 0) {
                C2687c.this.m164u();
                for (C2693f fVar : C2687c.this.f7462f) {
                    fVar.m110i();
                }
                m147e();
                C2687c.this.m155z();
                C2687c.this.m156y();
                m148d();
                this.f7491b.m321r();
                C2687c.this.f7476t = 3;
                C2709k.m37c();
                return;
            }
            C2687c.this.f7476t = 0;
            if (this.f7493d == null) {
                this.f7491b.m324e(this.f7492c);
            } else {
                this.f7491b.m331a(this.f7492c, this.f7493d);
            }
            this.f7491b.m160w();
        }
    }

    public C2687c() {
        this.f7461e.add(new C2692e());
        this.f7461e.add(new C2692e());
        this.f7461e.add(new C2692e());
        this.f7461e.add(new C2692e());
        m164u();
    }

    /* renamed from: a */
    public C2685a m216a(C2685a aVar, int i, int i2, int i3) {
        if (aVar != null) {
            return aVar;
        }
        C2685a aVar2 = new C2685a();
        aVar2.m263a(i, i2, i3);
        return aVar2;
    }

    /* renamed from: a */
    public static void m223a(Context context) {
        File file = new File(C2714o.m6a(context), "researcher.xml");
        if (!file.exists()) {
            FileOutputStream fileOutputStream = null;
            try {
                fileOutputStream = new FileOutputStream(file);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            try {
                fileOutputStream.write(new String("<EV3 Name=\"" + context.getString(R.string.ev3_researcher) + "\" Description=\"" + context.getString(R.string.ev3_researcher_desc) + "\"><Joystick Index=\"0\" Visible=\"1\" Shape=\"c\" Type=\"1\"><OutputPort Group=\"0\" Layer=\"0\" Number=\"B\"/><OutputPort Group=\"1\" Layer=\"0\" Number=\"C\"/></Joystick><Joystick Index=\"1\" Visible=\"1\" Shape=\"v\" Type=\"0\" Behavior1=\"1\"><OutputPort Group=\"1\" Layer=\"0\" Number=\"A\" JoystickType=\"1\" Power=\"50\" Invert=\"1\"/></Joystick><KeyGroup Active=\"1\" Type=\"1\" IncX=\"15\" IncY=\"15\" DecX=\"50\" DecY=\"50\"><UpKey>87</UpKey><UpKey>38</UpKey><LeftKey>65</LeftKey><LeftKey>37</LeftKey><DownKey>83</DownKey><DownKey>40</DownKey><RightKey>68</RightKey><RightKey>39</RightKey><OutputPort Group=\"0\" Layer=\"0\" Number=\"B\"/><OutputPort Group=\"1\" Layer=\"0\" Number=\"C\"/></KeyGroup><KeyGroup Active=\"1\" Type=\"0\" Behavior1=\"1\" IncY=\"5\" DecY=\"5\"><UpKey>89</UpKey><DownKey>72</DownKey><OutputPort Group=\"1\" Layer=\"0\" Number=\"A\" JoystickType=\"1\" Power=\"50\" Invert=\"1\"/></KeyGroup></EV3>").getBytes("UTF-8"));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    fileOutputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /* renamed from: a */
    private void m219a(Element element, AbstractC2686b bVar) {
        NodeList elementsByTagName = element.getElementsByTagName("OutputPort");
        for (int i = 0; i < elementsByTagName.getLength(); i++) {
            Element element2 = (Element) elementsByTagName.item(i);
            int a = C2713n.m12a(element2.getAttribute("Group"), -1);
            int a2 = C2713n.m12a(element2.getAttribute("Layer"), -1);
            String a3 = C2713n.m11a(element2.getAttribute("Number"), "");
            int i2 = a3.equals("A") ? 1 : a3.equals("B") ? 2 : a3.equals("C") ? 4 : a3.equals("D") ? 8 : -1;
            if (a >= 0 && a <= 1 && a2 >= 0 && a2 < 4 && i2 >= 0) {
                C2694g gVar = new C2694g(a2, i2);
                bVar.mo136a(a).add(gVar);
                gVar.m98b(C2713n.m12a(element2.getAttribute("JoystickType"), f7455a));
                gVar.m103a(C2713n.m12a(element2.getAttribute("Power"), 0));
                gVar.m101a(C2713n.m10a(element2.getAttribute("Invert"), false));
                gVar.m99b(C2713n.m13a(element2.getAttribute("Coefficient"), 1.0f));
                gVar.m95c(C2713n.m12a(element2.getAttribute("Brake"), 1));
            }
        }
    }

    /* renamed from: a */
    public void m218a(C2685a aVar) {
        OutputStream outputStream = null;
        try {
            outputStream = this.f7469m.getOutputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        byte[] b = aVar.m260b();
        synchronized (this.f7467k) {
            try {
                outputStream.write(b);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /* renamed from: a */
    public byte[] m217a(C2685a aVar, int i) {
        byte[] bArr;
        int b;
        int i2 = 0;
        OutputStream outputStream = null;
        try {
            outputStream = this.f7469m.getOutputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        byte[] b2 = aVar.m260b();
        synchronized (this.f7467k) {
            try {
                outputStream.write(b2);
            } catch (IOException e) {
                e.printStackTrace();
            }
            InputStream inputStream = null;
            try {
                inputStream = this.f7469m.getInputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }
            int i3 = 0;
            int i4 = 0;
            while (true) {
                try {
                    if (!(i3 * 20 < i && (i4 = inputStream.available()) <= 0)) break;
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    Thread.sleep(20L);
                    i3++;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            if (i4 <= 0 || (b = C2696d.m68b(inputStream)) <= 0) {
                bArr = null;
            } else {
                bArr = new byte[b];
                int i5 = 0;
                while (true) {
                    try {
                        i2 = inputStream.read(bArr, i2, b);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    if (i2 == b) {
                        break;
                    } else if (i2 <= 0) {
                        if (i5 * 20 >= i) {
                            bArr = null;
                            break;
                        }
                        try {
                            Thread.sleep(20L);
                            i5++;
                        } catch (InterruptedException e2) {
                            e2.printStackTrace();
                        }
                    } else {
                        b -= i2;
                    }
                }
                if (!(b2[2] == bArr[0] && b2[3] == bArr[1])) {
                    bArr = null;
                }
            }
        }
        return bArr;
    }

    /* renamed from: b */
    public void m204b(C2685a aVar) {
        if (m172o() && m170p() != null && !"".equals(m170p())) {
            aVar.m232n(8);
            aVar.m242i(1);
            aVar.m261a(m170p());
            aVar.m250e(0);
            aVar.m250e(4);
            aVar.m254d();
            aVar.m242i(1);
            aVar.m250e(0);
            aVar.m250e(4);
            aVar.m246g(0);
        }
    }

    /* renamed from: c */
    public static int m198c(int i) {
        switch (i) {
            case 1:
                return 16;
            case 2:
                return 17;
            case 3:
            case 5:
            case 6:
            case 7:
            default:
                return 0;
            case 4:
                return 18;
            case 8:
                return 19;
        }
    }

    /* renamed from: d */
    public static int m194d(int i) {
        switch (i) {
            case 16:
                return 1;
            case 17:
                return 2;
            case 18:
                return 4;
            case 19:
                return 8;
            default:
                return i;
        }
    }

    /* renamed from: u */
    public void m164u() {
        for (int i = 0; i < this.f7461e.size(); i++) {
            this.f7460d[i * 2] = this.f7461e.get(i).m142a();
            this.f7460d[(i * 2) + 1] = this.f7461e.get(i).m140b();
        }
    }

    /* renamed from: v */
    public void m162v() {
        m158x();
        this.f7462f.clear();
        this.f7461e.get(0).m269a(true);
        this.f7461e.get(0).m270a("c");
        this.f7461e.get(1).m269a(true);
        this.f7461e.get(1).m270a("v");
        this.f7461e.get(0).m139b(1);
        this.f7461e.get(0).mo136a(0).add(new C2694g(0, 2));
        this.f7461e.get(0).mo136a(1).add(new C2694g(0, 4));
        this.f7461e.get(1).m139b(0);
        this.f7461e.get(1).mo136a(1).add(new C2694g(0, 1));
        this.f7461e.get(1).mo136a(1).get(0).m98b(f7456b);
        this.f7461e.get(1).mo136a(1).get(0).m103a(50);
        this.f7461e.get(1).mo136a(1).get(0).m101a(true);
        this.f7461e.get(1).m271a(1, 1);
        this.f7462f.add(new C2693f());
        this.f7462f.get(0).m124c(1);
        this.f7462f.get(0).m125c().add(87);
        this.f7462f.get(0).m125c().add(38);
        this.f7462f.get(0).m122d().add(65);
        this.f7462f.get(0).m122d().add(37);
        this.f7462f.get(0).m119e().add(83);
        this.f7462f.get(0).m119e().add(40);
        this.f7462f.get(0).m116f().add(68);
        this.f7462f.get(0).m116f().add(39);
        this.f7462f.get(0).m121d(15);
        this.f7462f.get(0).m118e(50);
        this.f7462f.get(0).m115f(15);
        this.f7462f.get(0).m113g(50);
        this.f7462f.get(0).mo136a(0).add(new C2694g(0, 2));
        this.f7462f.get(0).mo136a(1).add(new C2694g(0, 4));
        this.f7462f.add(new C2693f());
        this.f7462f.get(1).m125c().add(89);
        this.f7462f.get(1).m119e().add(72);
        this.f7462f.get(1).m124c(0);
        this.f7462f.get(1).m115f(5);
        this.f7462f.get(1).m113g(5);
        this.f7462f.get(1).mo136a(1).add(new C2694g(0, 1));
        this.f7462f.get(1).mo136a(1).get(0).m98b(f7456b);
        this.f7462f.get(1).mo136a(1).get(0).m103a(50);
        this.f7462f.get(1).mo136a(1).get(0).m101a(true);
        this.f7462f.get(1).m135a(1, 1);
    }

    /* renamed from: w */
    public void m160w() {
        if (this.f7469m != null) {
            try {
                C2685a aVar = new C2685a();
                aVar.m263a(128, 0, 0);
                aVar.m257c();
                aVar.m242i(1);
                aVar.m228q();
                aVar.m238k(27);
                aVar.m246g(1);
                m218a(aVar);
                this.f7469m.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        this.f7469m = null;
        this.f7471o.clear();
        this.f7472p.clear();
        this.f7473q.clear();
        this.f7474r.clear();
        this.f7476t = 0;
        synchronized (this.f7478v) {
            this.f7478v.notifyAll();
        }
        synchronized (this.f7479w) {
            this.f7480x.clear();
            this.f7464h.clear();
        }
    }

    /* renamed from: x */
    private void m158x() {
        for (int i = 0; i < this.f7461e.size(); i++) {
            for (int i2 = 0; i2 < 2; i2++) {
                this.f7461e.get(i).mo136a(i2).clear();
                this.f7461e.get(i).m269a(false);
            }
        }
    }

    /* renamed from: y */
    public void m156y() {
        new Thread(new RunnableC2688a()).start();
    }

    /* renamed from: z */
    public void m155z() {
        new Thread(new RunnableC2689b(this)).start();
    }

    @Override
    /* renamed from: a */
    public String mo225a() {
        if (this.f7470n != null) {
            return this.f7470n.getName();
        }
        return null;
    }

    @Override
    /* renamed from: a */
    public void mo224a(BluetoothDevice bluetoothDevice) {
        if (this.f7476t == 0 || this.f7476t == 2) {
            this.f7470n = bluetoothDevice;
            this.f7476t = 1;
            new Thread(new RunnableC2690c(this)).start();
        }
    }

    @Override
    /* renamed from: a */
    public void mo222a(Context context, File file, Document document) {
        if (!document.getDocumentElement().getNodeName().equals("EV3")) {
            try {
                throw new Exception(context.getString(R.string.unknown_driver_name, document.getDocumentElement().getNodeName()));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        this.f7481y = document.getDocumentElement().getAttribute("Name");
        this.f7466j = C2713n.m11a(document.getDocumentElement().getAttribute("UserProgram"), "");
        this.f7465i = C2713n.m10a(document.getDocumentElement().getAttribute("StartUserProgram"), false);
        this.f7459B = C2713n.m10a(document.getDocumentElement().getAttribute("HideJoysticks"), true);
        m325a(C2713n.m10a(document.getDocumentElement().getAttribute("ShowDebugInfo"), true));
        this.f7482z = file.getName();
        this.f7458A = file.lastModified();
        m158x();
        this.f7462f.clear();
        NodeList elementsByTagName = document.getElementsByTagName("Joystick");
        for (int i = 0; i < elementsByTagName.getLength(); i++) {
            Element element = (Element) elementsByTagName.item(i);
            int a = C2713n.m12a(element.getAttribute("Index"), -1);
            if (a >= 0 && a < this.f7461e.size()) {
                C2692e eVar = this.f7461e.get(a);
                eVar.m269a(C2713n.m10a(element.getAttribute("Visible"), false));
                eVar.m270a(C2713n.m11a(element.getAttribute("Shape"), "c"));
                eVar.m139b(C2713n.m12a(element.getAttribute("Type"), 0));
                eVar.m271a(0, C2713n.m12a(element.getAttribute("Behavior0"), 0));
                eVar.m271a(1, C2713n.m12a(element.getAttribute("Behavior1"), 0));
                if (eVar.m138c() != 2) {
                    m219a(element, eVar);
                }
            }
        }
        NodeList elementsByTagName2 = document.getElementsByTagName("KeyGroup");
        for (int i2 = 0; i2 < elementsByTagName2.getLength(); i2++) {
            Element element2 = (Element) elementsByTagName2.item(i2);
            C2693f fVar = new C2693f();
            fVar.m124c(C2713n.m12a(element2.getAttribute("Type"), 0));
            fVar.m84a(C2713n.m10a(element2.getAttribute("Active"), false));
            fVar.m132a(C2713n.m11a(element2.getAttribute("Mailbox"), ""));
            fVar.m135a(0, C2713n.m12a(element2.getAttribute("Behavior0"), 0));
            fVar.m135a(1, C2713n.m12a(element2.getAttribute("Behavior1"), 0));
            fVar.m121d(C2713n.m12a(element2.getAttribute("IncX"), 0));
            fVar.m118e(C2713n.m12a(element2.getAttribute("DecX"), 0));
            fVar.m115f(C2713n.m12a(element2.getAttribute("IncY"), 0));
            fVar.m113g(C2713n.m12a(element2.getAttribute("DecY"), 0));
            fVar.m111h(C2713n.m12a(element2.getAttribute("StepXPause"), 100));
            fVar.m109i(C2713n.m12a(element2.getAttribute("StepYPause"), 100));
            if (fVar.m114g() != 2) {
                C2695c.m85a(element2, fVar.m125c(), "UpKey");
                C2695c.m85a(element2, fVar.m122d(), "LeftKey");
                C2695c.m85a(element2, fVar.m119e(), "DownKey");
                C2695c.m85a(element2, fVar.m116f(), "RightKey");
                m219a(element2, fVar);
            } else {
                C2695c.m85a(element2, fVar.m80l(), "Key");
            }
            this.f7462f.add(fVar);
        }
    }

    @Override
    /* renamed from: a */
    public void mo221a(HashSet<Integer> hashSet) {
        synchronized (this.f7479w) {
            this.f7464h = hashSet;
            this.f7463g = true;
        }
        synchronized (this.f7478v) {
            this.f7478v.notifyAll();
        }
    }

    @Override
    /* renamed from: a */
    public void mo220a(Hashtable<String, Integer> hashtable) {
        synchronized (this.f7479w) {
            Enumeration<String> keys = hashtable.keys();
            while (keys.hasMoreElements()) {
                String nextElement = keys.nextElement();
                this.f7480x.put(nextElement, hashtable.get(nextElement));
            }
        }
        synchronized (this.f7478v) {
            this.f7478v.notifyAll();
        }
    }

    @Override
    /* renamed from: a_ */
    public int mo207a_(int i) {
        switch (i) {
            case 0:
                return R.string.ev3_is_disconnected;
            case 1:
                return R.string.ev3_is_connecting;
            case 2:
                return R.string.ev3_bonded_devices_not_found;
            default:
                return super.mo207a_(i);
        }
    }

    @Override
    /* renamed from: b */
    public String mo206b() {
        Iterator<C2692e> it = null;
        String str = "";
        while (this.f7461e.iterator().hasNext()) {
            str = str + it.next().m267e();
        }
        return str;
    }

    /* renamed from: b */
    public void m205b(int i) {
        this.f7476t = 2;
        C2709k.m37c();
        if (this.f7469m != null) {
            mo174n();
            m160w();
        }
        if (i == 0) {
            m320s();
        } else {
            m323f(i);
        }
    }

    @Override
    /* renamed from: c */
    public String mo199c() {
        Iterator<C2692e> it = null;
        String str = "";
        while (this.f7461e.iterator().hasNext()) {
            str = str + it.next().m268d();
        }
        return str;
    }

    @Override
    /* renamed from: d */
    public String mo195d() {
        HashSet hashSet = new HashSet();
        for (C2693f fVar : this.f7462f) {
            if (fVar.m82j()) {
                hashSet.addAll(fVar.m125c());
                hashSet.addAll(fVar.m122d());
                hashSet.addAll(fVar.m119e());
                hashSet.addAll(fVar.m116f());
                hashSet.addAll(fVar.m80l());
            }
        }
        String str = "";
        if (hashSet.size() <= 0) {
            return str;
        }
        char[] cArr = {'0'};
        Iterator it = hashSet.iterator();
        while (it.hasNext()) {
            String num = ((Integer) it.next()).toString();
            if (num.length() < 3) {
                num = new String(cArr, 0, 3 - num.length()) + num;
            }
            str = str + num;
        }
        return str;
    }

    @Override
    /* renamed from: e */
    public boolean mo192e() {
        return this.f7459B;
    }

    @Override
    /* renamed from: f */
    public String mo190f() {
        return "EV3";
    }

    @Override
    /* renamed from: g */
    public String mo188g() {
        return this.f7482z;
    }

    @Override
    /* renamed from: h */
    public String mo186h() {
        return this.f7481y;
    }

    @Override
    /* renamed from: i */
    public boolean mo184i() {
        return this.f7476t == 0;
    }

    @Override
    /* renamed from: j */
    public boolean mo182j() {
        return this.f7476t == 3;
    }

    @Override
    /* renamed from: k */
    public long mo180k() {
        return this.f7458A;
    }

    @Override
    /* renamed from: l */
    public boolean mo178l() {
        return true;
    }

    @Override
    /* renamed from: m */
    public void mo176m() {
        m205b(0);
    }

    @Override
    /* renamed from: n */
    public void mo174n() {
        if (this.f7469m != null && this.f7473q.size() > 0) {
            C2685a aVar = new C2685a();
            Enumeration<String> keys = this.f7473q.keys();
            int i = 0;
            while (keys.hasMoreElements()) {
                i = this.f7473q.get(keys.nextElement()).m94d() == f7456b ? i + 1 : i;
            }
            aVar.m263a(128, 0, i * 8);
            aVar.m257c();
            aVar.m242i(1);
            aVar.m227r();
            aVar.m246g(0);
            Enumeration<String> keys2 = this.f7473q.keys();
            while (keys2.hasMoreElements()) {
                C2694g gVar = this.f7473q.get(keys2.nextElement());
                aVar.m239k();
                aVar.m246g(gVar.m105a());
                aVar.m246g(gVar.m91g());
                aVar.m246g(gVar.m90h());
            }
            Enumeration<String> keys3 = this.f7473q.keys();
            int i2 = 0;
            while (keys3.hasMoreElements()) {
                C2694g gVar2 = this.f7473q.get(keys3.nextElement());
                if (gVar2.m94d() != f7456b || gVar2.m87k() == 0) {
                    i2 = i2;
                } else {
                    aVar.m236l(28);
                    aVar.m246g(gVar2.m105a());
                    aVar.m246g(m198c(gVar2.m91g()));
                    aVar.m246g(0);
                    aVar.m246g(0);
                    aVar.m246g(1);
                    aVar.m248f(i2 * 8);
                    aVar.m251e();
                    aVar.m240j(0);
                    aVar.m248f(i2 * 8);
                    aVar.m248f(i2 * 8);
                    aVar.m243i();
                    aVar.m240j(gVar2.m87k());
                    aVar.m248f((i2 * 8) + 4);
                    aVar.m241j();
                    aVar.m248f(i2 * 8);
                    aVar.m240j(0);
                    aVar.m240j(10);
                    aVar.m247g();
                    aVar.m240j(-1);
                    aVar.m248f((i2 * 8) + 4);
                    aVar.m248f((i2 * 8) + 4);
                    aVar.m231o();
                    aVar.m246g(gVar2.m105a());
                    aVar.m246g(gVar2.m91g());
                    aVar.m248f((i2 * 8) + 4);
                    aVar.m240j(0);
                    aVar.m248f(i2 * 8);
                    aVar.m240j(0);
                    aVar.m244h(gVar2.m90h());
                    aVar.m233n();
                    aVar.m246g(gVar2.m105a());
                    aVar.m246g(gVar2.m91g());
                    i2++;
                }
            }
            aVar.m228q();
            m204b(aVar);
            aVar.m238k(27);
            aVar.m246g(8);
            m218a(aVar);
        }
    }

    /* renamed from: o */
    public boolean m172o() {
        return this.f7465i;
    }

    /* renamed from: p */
    public String m170p() {
        return this.f7466j;
    }
}
