package ru.proghouse.robocam;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.os.Build;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URI;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Locale;
import java.util.UUID;
import java.util.zip.ZipFile;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.b.h;
import org.b.j;
import org.b.a;
import org.b.i;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import ru.proghouse.robocam.p062a.AbstractC2677a;

@SuppressWarnings("ALL")
public class HttpServer extends IntentService {

    /* renamed from: c */
    private volatile ServerSocket f7157c;

    /* renamed from: d */
    private volatile boolean f7158d;

    /* renamed from: q */
    private volatile h f7159q = null;

    /* renamed from: r */
    private volatile C2633a f7160r = null;

    /* renamed from: b */
    private static int f7136b = 0;

    /* renamed from: e */
    private static Hashtable f7137e = new Hashtable();

    /* renamed from: f */
    private static String f7138f = new String(new char[]{File.separatorChar});

    /* renamed from: g */
    private static HashSet<String> f7139g = new HashSet<>();

    /* renamed from: h */
    private static HashSet<String> f7140h = new HashSet<>();

    /* renamed from: i */
    private static HashSet<String> f7141i = new HashSet<>();

    /* renamed from: j */
    private static Hashtable<String, String> f7142j = new Hashtable<>();

    /* renamed from: k */
    private static Hashtable<String, Date> f7143k = new Hashtable<>();

    /* renamed from: l */
    private static Hashtable<String, Date> f7144l = new Hashtable<>();

    /* renamed from: m */
    private static int f7145m = 30;

    /* renamed from: n */
    private static int f7146n = 4;

    /* renamed from: a */
    public static Object f7135a = new Object();

    /* renamed from: o */
    private static int f7147o = 8088;

    /* renamed from: p */
    private static int f7148p = 8089;

    /* renamed from: s */
    private static volatile File f7149s = null;

    /* renamed from: t */
    private static HttpServer f7150t = null;

    /* renamed from: u */
    private static Hashtable<j, String> f7151u = new Hashtable<>();

    /* renamed from: v */
    private static Hashtable<j, String> f7152v = new Hashtable<>();

    /* renamed from: w */
    private static Hashtable<j, Date> f7153w = new Hashtable<>();

    /* renamed from: x */
    private static Hashtable<String, Socket> f7154x = new Hashtable<>();

    /* renamed from: y */
    private static volatile String f7155y = "admin";

    /* renamed from: z */
    private static volatile String f7156z = "123";

    /* renamed from: A */
    private static volatile String f7132A = "guest";

    /* renamed from: B */
    private static volatile String f7133B = "123";

    /* renamed from: C */
    private static volatile boolean f7134C = true;

    @SuppressWarnings("ALL")
    class C2633a extends a {
        C2633a() {
        }

        /* renamed from: a */
        public void m531a() {
            synchronized (HttpServer.f7135a) {
                Enumeration keys = HttpServer.f7151u.keys();
                while (keys.hasMoreElements()) {
                    j jVar = (j) keys.nextElement();
                    if (HttpServer.f7143k.containsKey((String) HttpServer.f7151u.get(jVar))) {
                        jVar.a("<msg><name>updateJoysticks</name><jb>" + (AbstractC2677a.m322q().mo182j() ? AbstractC2677a.m322q().mo206b() : "00000000") + "</jb><js>" + (AbstractC2677a.m322q().mo182j() ? AbstractC2677a.m322q().mo199c() : "----") + "</js><kb>" + (AbstractC2677a.m322q().mo182j() ? AbstractC2677a.m322q().mo195d() : "") + "</kb><hj>" + ((!AbstractC2677a.m322q().mo182j() || !AbstractC2677a.m322q().mo192e()) ? "0" : "1") + "</hj><di>" + ((!AbstractC2677a.m322q().mo182j() || !AbstractC2677a.m322q().m319t()) ? "0" : "1") + "</di></msg>");
                    }
                }
            }
        }

        /* renamed from: a */
        public void m530a(String str) {
            synchronized (HttpServer.f7135a) {
                Enumeration keys = HttpServer.f7151u.keys();
                while (keys.hasMoreElements()) {
                    ((j) keys.nextElement()).a(str);
                }
            }
        }

        @Override
        /* renamed from: a */
        public void a(j jVar) {
            synchronized (HttpServer.f7135a) {
                String str = "";
                String a = jVar.a().a("sk");
                if (HttpServer.f7142j.containsKey(a)) {
                    str = (String) HttpServer.f7142j.get(a);
                    HttpServer.f7142j.remove(a);
                }
                HttpServer.f7151u.put(jVar, str);
            }
        }

        @Override
        /* renamed from: a */
        public void a(j jVar, String str) {
            synchronized (HttpServer.f7135a) {
                if (HttpServer.f7143k.containsKey((String) HttpServer.f7151u.get(jVar))) {
                    String[] split = str.split(":", 2);
                    if (split.length != 2 || !split[0].equalsIgnoreCase("tst")) {
                        if (split.length == 2 && split[0].equalsIgnoreCase("jv")) {
                            String[] split2 = split[1].split(";");
                            Hashtable hashtable = new Hashtable();
                            for (String str2 : split2) {
                                if (str2 != null && !str2.equalsIgnoreCase("")) {
                                    String[] split3 = str2.split("=");
                                    if (split3.length == 2) {
                                        try {
                                            hashtable.put(split3[0], Integer.valueOf(Integer.parseInt(split3[1])));
                                        } catch (NumberFormatException e) {
                                        }
                                    }
                                }
                            }
                            if (hashtable.size() > 0) {
                                C2709k.m41a(hashtable);
                            }
                        } else if (split.length == 2 && split[0].equalsIgnoreCase("kp")) {
                            try {
                                HashSet hashSet = new HashSet();
                                for (int i = 0; i < split[1].length() / 3; i++) {
                                    int parseInt = Integer.parseInt(split[1].substring(i * 3, (i * 3) + 3));
                                    if (parseInt > 0 && parseInt <= 255) {
                                        hashSet.add(Integer.valueOf(parseInt));
                                    }
                                }
                                C2709k.m42a(hashSet);
                            } catch (NumberFormatException e2) {
                            }
                        }
                    } else if (!HttpServer.f7152v.containsKey(jVar) || !((String) HttpServer.f7152v.get(jVar)).equals(split[1])) {
                        HttpServer.f7152v.put(jVar, split[1]);
                        HttpServer.f7153w.put(jVar, new Date());
                    }
                }
            }
        }

        @Override
        /* renamed from: b */
        public void b(j jVar) {
            synchronized (HttpServer.f7135a) {
                HttpServer.f7151u.remove(jVar);
                HttpServer.f7152v.remove(jVar);
                HttpServer.f7153w.remove(jVar);
                if (HttpServer.f7143k.containsKey((String) HttpServer.f7151u.get(jVar))) {
                    AbstractC2677a.m322q().mo174n();
                }
            }
        }
    }

    @SuppressWarnings("ALL")
    private static class RunnableC2634b implements Runnable {

        /* renamed from: h */
        private static String f7162h = "web";

        /* renamed from: a */
        private HttpServer f7163a;

        /* renamed from: b */
        private Socket f7164b;

        /* renamed from: c */
        private InputStream f7165c;

        /* renamed from: d */
        private OutputStream f7166d;

        /* renamed from: e */
        private OutputStreamWriter f7167e;

        /* renamed from: f */
        private AssetManager f7168f;

        /* renamed from: g */
        private String f7169g;

        /* renamed from: i */
        private String f7170i;

        /* renamed from: j */
        private Integer f7171j;

        /* renamed from: k */
        private Hashtable<String, String> f7172k;

        /* renamed from: l */
        private Hashtable<String, String> f7173l;

        /* renamed from: m */
        private String f7174m;

        /* renamed from: n */
        private String f7175n;

        /* renamed from: o */
        private String f7176o;

        /* renamed from: p */
        private String f7177p;

        private RunnableC2634b(HttpServer httpServer, Socket socket, AssetManager assetManager, String str, String str2) {
            this.f7171j = null;
            this.f7172k = new Hashtable<>();
            this.f7173l = new Hashtable<>();
            this.f7174m = "none";
            this.f7175n = "";
            this.f7176o = "";
            this.f7177p = "";
            this.f7163a = httpServer;
            this.f7170i = str2;
            this.f7169g = str;
            this.f7164b = socket;
            this.f7168f = assetManager;
            try {
                this.f7165c = socket.getInputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                this.f7166d = socket.getOutputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                this.f7167e = new OutputStreamWriter(this.f7166d, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }

        /* renamed from: a */
        private int m526a() {
            if (this.f7171j == null) {
                try {
                    return this.f7165c.read();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            int intValue = this.f7171j.intValue();
            this.f7171j = null;
            return intValue;
        }

        /* renamed from: a */
        private String m524a(String str) {
            int lastIndexOf = str.lastIndexOf(46);
            if (lastIndexOf > 0) {
                String lowerCase = str.substring(lastIndexOf).toLowerCase();
                if (HttpServer.f7137e.containsKey(lowerCase)) {
                    return (String) HttpServer.f7137e.get(lowerCase);
                }
            }
            return "content/unknown";
        }

        /* renamed from: a */
        private String m523a(String str, String str2, String str3) {
            if (!(this.f7176o == null || this.f7176o.compareTo("") == 0 || this.f7175n == null || this.f7175n.compareTo("") == 0)) {
                this.f7174m = "block";
            }
            return str.replace("$$systemMessageDisplay$$", this.f7174m).replace("$$systemMessageText$$", this.f7176o).replace("$$systemMessageTitle$$", this.f7175n).replace("$$loginWrongUsername$$", this.f7177p).replace("<html manifest=\"offline.appcache\">", "<html>");
        }

        /* renamed from: a */
        private void m525a(int i, String str, String[] strArr, boolean z, boolean z2) {
            try {
                this.f7167e.write("HTTP/1.1 " + i + " " + str + "\r\n");
                if (strArr != null) {
                    for (int i2 = 0; i2 < strArr.length; i2++) {
                        this.f7167e.write(strArr[i2] + "\r\n");
                    }
                }
                if (z2) {
                    this.f7167e.write("Content-type: text/html\r\n\r\n" + str);
                }
                this.f7167e.flush();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (z) {
                    try {
                        this.f7164b.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        /* renamed from: a */
        private void m522a(String s, String s0, java.net.URI a0) {
            String s1 = null;
            String s2 = null;
            int i0 = 0;
            int i1 = 0;
            java.io.File a1 = null;
            String s3 = null;
            String s4 = null;
            String s5 = null;
            boolean b0 = s != null;
            C2671a a2 = C2671a.m379a();
            String s6 = java.util.UUID.randomUUID().toString();
            label18: {
                Exception a3 = null;
                label24: {
                    int i2 = 0;
                    org.w3c.dom.Element[] a4 = null;
                    Object[] a5 = null;
                    int i3 = 0;
                    org.w3c.dom.Node a6 = null;
                    label27: {
                        label26: {
                            label28: {
                                java.io.File a7 = null;
                                boolean b1 = false;
                                try {
                                    String[] a8 = a0.getQuery().split("&");
                                    int i4 = a8.length;
                                    int i5 = 0;
                                    while(true) {
                                        if (i5 >= i4) {
                                            i2 = 0;
                                            break;
                                        } else {
                                            String[] a9 = a8[i5].split("=", 2);
                                            if (!a9[0].equals((Object)"sm")) {
                                                i5 = i5 + 1;
                                                continue;
                                            }
                                            i2 = Integer.parseInt(a9[1]);
                                            break;
                                        }
                                    }
                                    if (i2 <= 0) {
                                        break label26;
                                    }
                                    a7 = new java.io.File(ru.proghouse.robocam.HttpServer.n(), "v.xml");
                                    b1 = a7.exists();
                                } catch(Exception a10) {
                                    a3 = a10;
                                    break label28;
                                }
                                if (!b1) {
                                    break label26;
                                }
                                a4 = new org.w3c.dom.Element[1];
                                a4[0] = null;
                                try {
                                    org.w3c.dom.Document a11 = javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(a7);
                                    java.util.List a12 = ru.proghouse.robocam.MainActivity.m468a((android.content.Context)this.f7163a);
                                    String[] a13 = new String[1];
                                    a13[0] = null;
                                    String[] a14 = new String[1];
                                    a14[0] = null;
                                    if (!ru.proghouse.robocam.MainActivity.m465a(a11, a12, a4, a13, a14)) {
                                        break label26;
                                    }
                                    s1 = a11.getDocumentElement().getAttribute("number");
                                    break label27;
                                } catch(Exception a15) {
                                    a3 = a15;
                                }
                            }
                            s1 = "";
                            s2 = "";
                            i0 = 0;
                            i1 = 0;
                            a1 = null;
                            s3 = "";
                            break label24;
                        }
                        s1 = "";
                        s2 = "";
                        s4 = "";
                        i0 = 0;
                        i1 = 0;
                        a1 = null;
                        s3 = "";
                        break label18;
                    }
                    label25: {
                        try {
                            a1 = new java.io.File(ru.proghouse.robocam.HttpServer.n(), s1);
                            a5 = a4;
                            i3 = 0;
                            break label25;
                        } catch(Exception a16) {
                            a3 = a16;
                        }
                        s2 = "";
                        i0 = 0;
                        i1 = 0;
                        a1 = null;
                        s3 = "";
                        break label24;
                    }
                    label23: {
                        label22: {
                            try {
                                while(true) {
                                    s3 = "";
                                    i0 = 0;
                                    s2 = "";
                                    if (i3 >= ((org.w3c.dom.Element)a5[0]).getChildNodes().getLength()) {
                                        break label22;
                                    }
                                    s3 = "";
                                    i0 = 0;
                                    s2 = "";
                                    boolean b2 = ((org.w3c.dom.Element)a5[0]).getChildNodes().item(i3).getNodeName().equals((Object)"device");
                                    label19: {
                                        if (!b2) {
                                            break label19;
                                        }
                                        s3 = "";
                                        i0 = 0;
                                        s2 = "";
                                        a6 = ((org.w3c.dom.Element)a5[0]).getChildNodes().item(i3);
                                        s3 = "";
                                        i0 = 0;
                                        s2 = "";
                                        String s7 = ((org.w3c.dom.Element)(Object)a6).getAttribute("target");
                                        label21: {
                                            if (s7 == null) {
                                                break label21;
                                            }
                                            s3 = "";
                                            i0 = 0;
                                            s2 = "";
                                            if (((org.w3c.dom.Element)(Object)a6).getAttribute("target").isEmpty()) {
                                                break label21;
                                            }
                                            s3 = "";
                                            i0 = 0;
                                            s2 = "";
                                            if (!((org.w3c.dom.Element)(Object)a6).getAttribute("target").equals((Object)"client")) {
                                                break label19;
                                            }
                                        }
                                        s3 = "";
                                        i0 = 0;
                                        s2 = "";
                                        String s8 = ((org.w3c.dom.Element)(Object)a6).getAttribute("screenMin");
                                        label20: {
                                            if (s8 == null) {
                                                break label20;
                                            }
                                            s3 = "";
                                            i0 = 0;
                                            s2 = "";
                                            if (((org.w3c.dom.Element)(Object)a6).getAttribute("screenMin").isEmpty()) {
                                                break label20;
                                            }
                                            double d0 = (double)i2;
                                            s3 = "";
                                            i0 = 0;
                                            s2 = "";
                                            if (!(d0 >= Double.parseDouble(((org.w3c.dom.Element)(Object)a6).getAttribute("screenMin")))) {
                                                break label19;
                                            }
                                        }
                                        s3 = "";
                                        i0 = 0;
                                        s2 = "";
                                        if (((org.w3c.dom.Element)(Object)a6).getAttribute("sdkMin") == null) {
                                            break;
                                        }
                                        s3 = "";
                                        i0 = 0;
                                        s2 = "";
                                        if (((org.w3c.dom.Element)(Object)a6).getAttribute("sdkMin").isEmpty()) {
                                            break;
                                        }
                                        int i6 = android.os.Build.VERSION.SDK_INT;
                                        s3 = "";
                                        i0 = 0;
                                        s2 = "";
                                        if (i6 >= Integer.parseInt(((org.w3c.dom.Element)(Object)a6).getAttribute("sdkMin"))) {
                                            break;
                                        }
                                    }
                                    i3 = i3 + 1;
                                }
                                s3 = "";
                                i0 = 0;
                                s2 = "";
                                s2 = ((org.w3c.dom.Element)(Object)a6).getAttribute("path");
                                s3 = "";
                                i0 = 0;
                                s3 = ((org.w3c.dom.Element)(Object)a6).getAttribute("url");
                                i0 = 0;
                                i0 = Integer.parseInt(((org.w3c.dom.Element)(Object)a6).getAttribute("width"));
                                i1 = Integer.parseInt(((org.w3c.dom.Element)(Object)a6).getAttribute("height"));
                                break label23;
                            } catch(Exception a17) {
                                a3 = a17;
                            }
                            i1 = 0;
                            break label24;
                        }
                        s2 = "";
                        s4 = "";
                        i0 = 0;
                        i1 = 0;
                        s3 = "";
                        break label18;
                    }
                    try {
                        s4 = ((org.w3c.dom.Element)(Object)a6).getAttribute("type");
                        break label18;
                    } catch(Exception a18) {
                        a3 = a18;
                    }
                }
                a3.printStackTrace();
                s4 = "";
            }
            Object a19 = HttpServer.f7135a;
            /*monenter(a19)*/;
            try {
                String s9 = null;
                String s10 = null;
                String s11 = null;
                String s12 = null;
                String s13 = null;
                java.util.Hashtable a20 = ru.proghouse.robocam.HttpServer.i();
                if (s == null) {
                    s = s0;
                }
                a20.put((Object)s6, (Object)s);
                StringBuilder a21 = new StringBuilder().append("<settings><cp>").append(ru.proghouse.robocam.HttpServer.o()).append("</cp>").append("<prw>").append(a2.m351f()).append("</prw>").append("<prh>").append(a2.m349g()).append("</prh>").append("<jb>");
                label17: {
                    label15: {
                        label16: {
                            if (!b0) {
                                break label16;
                            }
                            if (AbstractC2677a.m322q().mo182j()) {
                                break label15;
                            }
                        }
                        s9 = "00000000";
                        break label17;
                    }
                    s9 = AbstractC2677a.m322q().mo206b();
                }
                StringBuilder a22 = a21.append(s9).append("</jb>").append("<js>");
                label14: {
                    label12: {
                        label13: {
                            if (!b0) {
                                break label13;
                            }
                            if (AbstractC2677a.m322q().mo182j()) {
                                break label12;
                            }
                        }
                        s10 = "----";
                        break label14;
                    }
                    s10 = AbstractC2677a.m322q().mo199c();
                }
                StringBuilder a23 = a22.append(s10).append("</js>").append("<kb>");
                label11: {
                    label9: {
                        label10: {
                            if (!b0) {
                                break label10;
                            }
                            if (AbstractC2677a.m322q().mo182j()) {
                                break label9;
                            }
                        }
                        s11 = "";
                        break label11;
                    }
                    s11 = AbstractC2677a.m322q().mo195d();
                }
                StringBuilder a24 = a23.append(s11).append("</kb>").append("<hj>");
                label8: {
                    label6: {
                        label7: {
                            if (!b0) {
                                break label7;
                            }
                            if (!AbstractC2677a.m322q().mo182j()) {
                                break label7;
                            }
                            if (AbstractC2677a.m322q().mo192e()) {
                                break label6;
                            }
                        }
                        s12 = "0";
                        break label8;
                    }
                    s12 = "1";
                }
                StringBuilder a25 = a24.append(s12).append("</hj>").append("<di>");
                label5: {
                    label3: {
                        label4: {
                            if (!b0) {
                                break label4;
                            }
                            if (!AbstractC2677a.m322q().mo182j()) {
                                break label4;
                            }
                            if (AbstractC2677a.m322q().m319t()) {
                                break label3;
                            }
                        }
                        s13 = "0";
                        break label5;
                    }
                    s13 = "1";
                }
                String s14 = a25.append(s13).append("</di>").append("<lng>").append(this.f7163a.getString(R.string.local_web_path)).append("</lng>").append("<sk>").append(s6).append("</sk>").toString();
                boolean b3 = s2.equals((Object)"");
                label1: {
                    label0: {
                        {
                            if (b3) {
                                break label1;
                            }
                            if (i0 <= 0) {
                                break label1;
                            }
                            if (i1 <= 0) {
                                break label1;
                            }
                            boolean b4 = s4.equals((Object)"replace");
                            label2: {
                                if (b4) {
                                    break label2;
                                }
                                if (!s4.equals((Object)"offline")) {
                                    break label1;
                                }
                            }
                            if (new java.io.File(a1, s2).exists()) {
                                break label0;
                            }
                        }
                        break label1;
                    }
                    s14 = new StringBuilder().append(s14).append("<bnp>/").append(s1).append("/").append(s2).append("</bnp>").append("<bnw>").append(Integer.toString(i0)).append("</bnw>").append("<bnh>").append(Integer.toString(i1)).append("</bnh>").append("<bnu>").append(s3).append("</bnu>").toString();
                }
                s5 = new StringBuilder().append(s14).append("</settings>").toString();
                /*monexit(a19)*/;
            } catch(Throwable a26) {
                Throwable a27 = a26;
                while(true) {
                    try {
                        /*monexit(a19)*/;
                    } catch(IllegalMonitorStateException | NullPointerException a28) {
                        Throwable a29 = a28;
                        a27 = a29;
                        continue;
                    }
                    try {
                        throw a27;
                    } catch (Throwable throwable) {
                        throwable.printStackTrace();
                    }
                }
            }
            byte[] a30 = new byte[0];
            try {
                a30 = s5.getBytes("UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            String[] a31 = new String[7];
            a31[0] = "Server: RoboCam Server";
            a31[1] = "Content-type: text/xml; charset=UTF-8";
            a31[2] = new StringBuilder().append("Content-Length: ").append(a30.length).toString();
            a31[3] = new StringBuilder().append("Date: ").append(ru.proghouse.robocam.HttpServer.m558b(new java.util.Date())).toString();
            a31[4] = "Cache-Control: no-store, no-cache, must-revalidate";
            a31[5] = "Pragma: no-cache";
            a31[6] = "Access-Control-Allow-Origin: *";
            this.m525a(200, "OK", a31, false, false);
            try {
                this.f7167e.write("\r\n");
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                this.f7167e.write(s5);
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                this.f7167e.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                this.f7164b.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        /* renamed from: a */
        private void m521a(Hashtable<String, Date> hashtable) {
            synchronized (HttpServer.f7135a) {
                Calendar gregorianCalendar = GregorianCalendar.getInstance();
                gregorianCalendar.add(12, -HttpServer.f7145m);
                ArrayList arrayList = new ArrayList();
                Enumeration<String> keys = hashtable.keys();
                while (keys.hasMoreElements()) {
                    String nextElement = keys.nextElement();
                    if (hashtable.get(nextElement).before(gregorianCalendar.getTime())) {
                        arrayList.add(nextElement);
                    }
                }
                for (int i = 0; i < arrayList.size(); i++) {
                    hashtable.remove(arrayList.get(i));
                }
            }
        }

        /* renamed from: a */
        private boolean m520a(String[] strArr, String str) {
            for (String str2 : strArr) {
                if (str2.toLowerCase().compareTo(str) == 0) {
                    return true;
                }
            }
            return false;
        }

        /* renamed from: b */
        private String m519b() {
            int a;
            ArrayList arrayList = new ArrayList();
            while (true) {
                a = m526a();
                if (a < 0) {
                    break;
                } else if (a == 13 || a == 10) {
                    break;
                } else {
                    arrayList.add(new Byte((byte) a));
                }
            }
            int a2 = m526a();
            if (a2 >= 0 && !((a == 13 && a2 == 10) || (a == 10 && a2 == 13))) {
                this.f7171j = new Integer(a2);
            }
            byte[] bArr = new byte[arrayList.size()];
            for (int i = 0; i < arrayList.size(); i++) {
                bArr[i] = ((Byte) arrayList.get(i)).byteValue();
            }
            try {
                return new String(bArr, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            return null;
        }

        /* renamed from: b */
        private Hashtable<String, String> m518b(String str) {
            Hashtable<String, String> hashtable = new Hashtable<>();
            for (String str2 : str.split("&")) {
                String[] split = str2.split("=", 2);
                if (split.length > 0) {
                    try {
                        hashtable.put(split[0], split.length > 1 ? URLDecoder.decode(split[1], "UTF-8") : "");
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                }
            }
            return hashtable;
        }

        /* renamed from: c */
        private void m517c() {
            if (this.f7172k.containsKey("Cookie:")) {
                for (String str : this.f7172k.get("Cookie:").split(";")) {
                    String[] split = str.split("=", 2);
                    this.f7173l.put(split[0], split.length > 1 ? split[1] : "");
                }
            }
        }

        /* renamed from: c */
        private void m516c(String str) {
            int a;
            int i = 0;
            try {
                C2671a a2 = C2671a.m379a();
                m525a(200, "OK", new String[]{"Server: RoboCam Server", "Connection: close", "Max-Age: 0", "Expires: 0", "Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0", "Pragma: no-cache", "Content-Type: multipart/x-mixed-replace; boundary=This is the frame!"}, false, false);
                this.f7167e.write("\r\n");
                this.f7167e.write("--This is the frame!\r\n");
                this.f7167e.flush();
                HttpServer.f7154x.put(str, this.f7164b);
                a2.m347h();
                while (true) {
                    try {
                        a = a2.m371a(this.f7166d, "This is the frame!", i);
                        if (this.f7163a.f7158d || this.f7164b.isClosed()) {
                            break;
                        }
                        if (a != i && a != 0) {
                            this.f7166d.write(("--This is the frame!\r\n").getBytes());
                        } else if (!a2.m344k()) {
                            Thread.sleep(100L);
                        }
                        i = a;
                    } finally {
                        a2.m346i();
                    }
                }
                if (!(a == i || a == 0)) {
                    this.f7166d.write(("--This is the frame!--\r\n").getBytes());
                }
                HttpServer.f7154x.remove(str);
                this.f7164b.close();
            } catch (Throwable th) {
                th.printStackTrace();
            }
        }

        @Override
        public void run() {
            label0: {
                Throwable a0 = null;
                label17: {
                    String[] a1 = null;
                    label21: try {
                        String s = m519b();
                        label23: {
                            label24: {
                                if (s == null) {
                                    break label24;
                                }
                                if (s.trim().length() != 0) {
                                    break label23;
                                }
                            }
                            String[] a2 = new String[1];
                            a2[0] = "Allow: GET, HEAD, POST";
                            m525a(405, "empty method type", a2, true, true);
                            break label0;
                        }
                        a1 = s.split(" ", 3);
                        int i0 = a1.length;
                        label22: {
                            if (i0 >= 2) {
                                break label22;
                            }
                            String[] a3 = new String[1];
                            a3[0] = "Allow: GET, HEAD, POST";
                            m525a(405, "unknown method type", a3, true, true);
                            break label0;
                        }
                        if (a1[0].compareTo("GET") == 0) {
                            break label21;
                        }
                        if (a1[0].compareTo("HEAD") == 0) {
                            break label21;
                        }
                        if (a1[0].compareTo("POST") == 0) {
                            break label21;
                        }
                        String s0 = new StringBuilder().append("unsupported method type: ").append(a1[0]).toString();
                        String[] a4 = new String[1];
                        a4[0] = "Allow: GET, HEAD, POST";
                        m525a(405, s0, a4, true, true);
                        break label0;
                    } catch(Throwable a5) {
                        a0 = a5;
                        break label17;
                    }
                    while(true) {
                        String[] a6 = null;
                        java.util.Hashtable a7 = null;
                        int i1 = 0;
                        String s1 = null;
                        try {
                            String s2 = m519b();
                            a6 = s2.split(" ", 2);
                            if (s2 == null) {
                                break;
                            }
                            if (s2.trim().length() == 0) {
                                break;
                            }
                            a7 = f7172k;
                        } catch(Throwable a8) {
                            a0 = a8;
                            break label17;
                        }
                        String s3 = a6[0];
                        try {
                            i1 = a6.length;
                        } catch(NullPointerException a9) {
                            a0 = a9;
                            break label17;
                        }
                        label20: {
                            label18: {
                                label19: {
                                    if (i1 < 2) {
                                        break label19;
                                    }
                                    if (a6[1] != null) {
                                        break label18;
                                    }
                                }
                                s1 = "";
                                break label20;
                            }
                            s1 = a6[1];
                        }
                        try {
                            a7.put((Object)s3, (Object)s1);
                        } catch(Throwable a10) {
                            a0 = a10;
                            break label17;
                        }
                    }
                    try {
                        String s4 = null;
                        String s5 = null;
                        java.io.IOException a11 = null;
                        m517c();
                        boolean b0 = f7173l.containsKey((Object)"sess");
                        label16: {
                            Object a12 = null;
                            Throwable a13 = null;
                            if (b0) {
                                m521a(ru.proghouse.robocam.HttpServer.f());
                                m521a(ru.proghouse.robocam.HttpServer.p());
                                a12 = HttpServer.f7135a;
                                /*monenter(a12)*/;
                                try {
                                    if (ru.proghouse.robocam.HttpServer.f().containsKey(f7173l.get((Object)"sess"))) {
                                        s4 = (String)f7173l.get((Object)"sess");
                                        ru.proghouse.robocam.HttpServer.f().put((Object)s4, (Object)new java.util.Date());
                                        s5 = null;
                                    } else if (ru.proghouse.robocam.HttpServer.p().containsKey(f7173l.get((Object)"sess"))) {
                                        s5 = (String)f7173l.get((Object)"sess");
                                        ru.proghouse.robocam.HttpServer.p().put((Object)s5, (Object)new java.util.Date());
                                        s4 = null;
                                    } else {
                                        s4 = null;
                                        s5 = null;
                                    }
                                    /*monexit(a12)*/;
                                    break label16;
                                } catch(Throwable a14) {
                                    a13 = a14;
                                }
                            } else {
                                s5 = null;
                                s4 = null;
                                break label16;
                            }
                            while(true) {
                                try {
                                    /*monexit(a12)*/;
                                } catch(IllegalMonitorStateException | NullPointerException a15) {
                                    Throwable a16 = a15;
                                    a13 = a16;
                                    continue;
                                }
                                throw a13;
                            }
                        }
                        if (C2709k.f7587a && s4 == null) {
                            s4 = java.util.UUID.randomUUID().toString();
                            ru.proghouse.robocam.HttpServer.f().put((Object)s4, (Object)new java.util.Date());
                        }
                        int i2 = a1[0].compareTo("POST");
                        label15: {
                            byte[] a17 = null;
                            if (i2 != 0) {
                                break label15;
                            }
                            int i3 = (f7172k.containsKey((Object)"Content-Length:")) ? Integer.parseInt((String)f7172k.get((Object)"Content-Length:")) : 0;
                            if (i3 <= 0) {
                                a17 = null;
                            } else {
                                a17 = new byte[i3];
                                i3 = this.f7165c.read(a17);
                            }
                            if (i3 <= 0) {
                                break label15;
                            }
                            if (a1[1].compareTo("/login.html") != 0) {
                                break label15;
                            }
                            java.util.Hashtable a18 = this.m518b(new String(a17, 0, i3, "UTF-8"));
                            int i4 = ((String)a18.get((Object)"username")).compareTo(ru.proghouse.robocam.HttpServer.q());
                            label14: {
                                if (i4 != 0) {
                                    break label14;
                                }
                                if (((String)a18.get((Object)"password")).compareTo(ru.proghouse.robocam.HttpServer.r()) != 0) {
                                    break label14;
                                }
                                String s6 = java.util.UUID.randomUUID().toString();
                                Object a19 = HttpServer.f7135a;
                                /*monenter(a19)*/;
                                try {
                                    ru.proghouse.robocam.HttpServer.f().put((Object)s6, (Object)new java.util.Date());
                                    /*monexit(a19)*/;
                                } catch(Throwable a20) {
                                    Throwable a21 = a20;
                                    while(true) {
                                        try {
                                            /*monexit(a19)*/;
                                        } catch(IllegalMonitorStateException | NullPointerException a22) {
                                            Throwable a23 = a22;
                                            a21 = a23;
                                            continue;
                                        }
                                        throw a21;
                                    }
                                }
                                java.util.Calendar a24 = java.util.GregorianCalendar.getInstance();
                                a24.setTime(new java.util.Date());
                                a24.add(1, 1);
                                StringBuilder a25 = new StringBuilder();
                                String[] a26 = new String[2];
                                a26[0] = "Location: /";
                                a26[1] = a25.append("Set-Cookie: sess=").append(s6).append("; expires=").append(ru.proghouse.robocam.HttpServer.m558b(a24.getTime())).append("; path=/").toString();
                                m525a(302, "moved temporarily", a26, true, false);
                                break label0;
                            }
                            boolean b1 = ru.proghouse.robocam.HttpServer.s();
                            label13: {
                                if (!b1) {
                                    break label13;
                                }
                                if (((String)a18.get((Object)"username")).compareTo(ru.proghouse.robocam.HttpServer.t()) != 0) {
                                    break label13;
                                }
                                if (((String)a18.get((Object)"password")).compareTo(ru.proghouse.robocam.HttpServer.u()) != 0) {
                                    break label13;
                                }
                                String s7 = java.util.UUID.randomUUID().toString();
                                Object a27 = HttpServer.f7135a;
                                /*monenter(a27)*/;
                                try {
                                    ru.proghouse.robocam.HttpServer.p().put((Object)s7, (Object)new java.util.Date());
                                    /*monexit(a27)*/;
                                } catch(Throwable a28) {
                                    Throwable a29 = a28;
                                    while(true) {
                                        try {
                                            /*monexit(a27)*/;
                                        } catch(IllegalMonitorStateException | NullPointerException a30) {
                                            Throwable a31 = a30;
                                            a29 = a31;
                                            continue;
                                        }
                                        throw a29;
                                    }
                                }
                                java.util.Calendar a32 = java.util.GregorianCalendar.getInstance();
                                a32.setTime(new java.util.Date());
                                a32.add(1, 1);
                                StringBuilder a33 = new StringBuilder();
                                String[] a34 = new String[2];
                                a34[0] = "Location: /";
                                a34[1] = a33.append("Set-Cookie: sess=").append(s7).append("; expires=").append(ru.proghouse.robocam.HttpServer.m558b(a32.getTime())).append("; path=/").toString();
                                m525a(302, "moved temporarily", a34, true, false);
                                break label0;
                            }
                            if (((String)a18.get((Object)"username")).compareTo("") != 0) {
                                this.f7176o = f7163a.getString(R.string.username_and_password_are_wrong);
                            } else {
                                this.f7176o = f7163a.getString(R.string.enter_your_username);
                            }
                            this.f7175n = f7163a.getString(R.string.error);
                            this.f7177p = (String)a18.get((Object)"username");
                        }
                        a1[1] = ru.proghouse.robocam.HttpServer.b(a1[1]);
                        int i5 = a1[1].substring(0, 1).compareTo(ru.proghouse.robocam.HttpServer.v());
                        label7: {
                            label6: {
                                java.io.IOException a35 = null;
                                label9: {
                                    java.io.InputStream a36 = null;
                                    Throwable a37 = null;
                                    label1: if (i5 == 0) {
                                        java.net.URI a38 = new java.net.URI(a1[1]);
                                        if (a1[1].compareTo(ru.proghouse.robocam.HttpServer.v()) == 0) {
                                            String[] a39 = f7168f.list(new StringBuilder().append(f7162h).append(ru.proghouse.robocam.HttpServer.v()).append(f7170i).toString());
                                            if (m520a(a39, "index.html")) {
                                                a1[1] = new StringBuilder().append(ru.proghouse.robocam.HttpServer.v()).append("index.html").toString();
                                            } else if (m520a(a39, "index.htm")) {
                                                a1[1] = new StringBuilder().append(ru.proghouse.robocam.HttpServer.v()).append("index.htm").toString();
                                            } else if (f7170i.compareTo("def") != 0) {
                                                if (m520a(f7168f.list(new StringBuilder().append(f7162h).append(ru.proghouse.robocam.HttpServer.v()).append("def").toString()), "index.html")) {
                                                    a1[1] = new StringBuilder().append(ru.proghouse.robocam.HttpServer.v()).append("index.html").toString();
                                                } else {
                                                    a1[1] = new StringBuilder().append(ru.proghouse.robocam.HttpServer.v()).append("index.htm").toString();
                                                }
                                            }
                                        }
                                        label12: {
                                            if (s4 != null) {
                                                break label12;
                                            }
                                            if (s5 != null) {
                                                break label12;
                                            }
                                            if (!ru.proghouse.robocam.HttpServer.w().contains((Object)a1[1])) {
                                                break label12;
                                            }
                                            String[] a40 = new String[1];
                                            a40[0] = "Location: /login.html";
                                            m525a(302, "moved temporarily", a40, true, false);
                                            break label0;
                                        }
                                        boolean b2 = ru.proghouse.robocam.HttpServer.x().contains((Object)a1[1]);
                                        label10: try {
                                            int i6 = a1[1].compareTo("/cam");
                                            label11: {
                                                if (i6 != 0) {
                                                    break label11;
                                                }
                                                if (s4 == null) {
                                                    s4 = s5;
                                                }
                                                this.m516c(s4);
                                                break label0;
                                            }
                                            if (!a38.getPath().equals((Object)"/settings")) {
                                                break label10;
                                            }
                                            m522a(s4, s5, a38);
                                            break label0;
                                        } catch(Exception a41) {
                                            a35 = (IOException) a41;
                                            break label9;
                                        }
                                        boolean b3 = ru.proghouse.robocam.HttpServer.y().contains((Object)a1[1]);
                                        label8: {
                                            try {
                                                try {
                                                    a36 = f7168f.open(new StringBuilder().append(f7162h).append(ru.proghouse.robocam.HttpServer.v()).append(f7170i).append(a1[1]).toString());
                                                    a1[1] = new StringBuilder().append(f7162h).append(ru.proghouse.robocam.HttpServer.v()).append(f7170i).append(a1[1]).toString();
                                                    break label8;
                                                } catch(java.io.FileNotFoundException ignoredException) {
                                                }
                                            } catch(java.io.IOException a42) {
                                                a11 = a42;
                                                break label7;
                                            }
                                            try {
                                                a36 = f7168f.open(new StringBuilder().append(f7162h).append(ru.proghouse.robocam.HttpServer.v()).append("def").append(a1[1]).toString());
                                                a1[1] = new StringBuilder().append(f7162h).append(ru.proghouse.robocam.HttpServer.v()).append("def").append(a1[1]).toString();
                                            } catch(java.io.FileNotFoundException ignoredException0) {
                                                java.io.FileInputStream a43 = null;
                                                try {
                                                    java.io.File a44 = new java.io.File(C2714o.m0b((android.content.Context)f7163a), a1[1]);
                                                    a43 = new java.io.FileInputStream(a44);
                                                    a1[1] = a44.getName();
                                                } catch(java.io.FileNotFoundException ignoredException1) {
                                                    break label6;
                                                }
                                                a36 = a43;
                                            }
                                        }
                                        try {
                                            byte[] a45 = null;
                                            if (b3) {
                                                byte[] a46 = new byte[a36.available()];
                                                a45 = m523a(new String(a46, 0, a36.read(a46, 0, a46.length), "UTF-8"), s4, s5).getBytes("UTF-8");
                                            } else {
                                                a45 = null;
                                            }
                                            if (b2) {
                                                String s8 = new StringBuilder().append("Content-length: ").append(b3 ? a45.length : a36.available()).toString();
                                                StringBuilder a47 = new StringBuilder();
                                                String[] a48 = new String[7];
                                                a48[0] = "Server: RoboCam Server";
                                                a48[1] = s8;
                                                a48[2] = a47.append("Content-type: ").append(m524a(a1[1])).toString();
                                                a48[3] = "Max-Age: 0";
                                                a48[4] = "Expires: 0";
                                                a48[5] = "Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0";
                                                a48[6] = "Pragma: no-cache";
                                                m525a(200, "OK", a48, false, false);
                                            } else {
                                                String s9 = new StringBuilder().append("Date: ").append(ru.proghouse.robocam.HttpServer.m558b(new java.util.Date())).toString();
                                                String s10 = new StringBuilder().append("Content-length: ").append(b3 ? a45.length : a36.available()).toString();
                                                String s11 = new StringBuilder().append("Last Modified: ").append(f7169g).toString();
                                                StringBuilder a49 = new StringBuilder();
                                                String[] a50 = new String[5];
                                                a50[0] = "Server: RoboCam Server";
                                                a50[1] = s9;
                                                a50[2] = s10;
                                                a50[3] = s11;
                                                a50[4] = a49.append("Content-type: ").append(m524a(a1[1])).toString();
                                                m525a(200, "OK", a50, false, false);
                                            }
                                            int i7 = a1[0].compareTo("GET");
                                            label4: {
                                                label5: {
                                                    if (i7 == 0) {
                                                        break label5;
                                                    }
                                                    if (a1[0].compareTo("POST") != 0) {
                                                        break label4;
                                                    }
                                                }
                                                this.f7167e.write("\r\n");
                                            }
                                            this.f7167e.flush();
                                            int i8 = a1[0].compareTo("GET");
                                            label2: {
                                                label3: {
                                                    if (i8 == 0) {
                                                        break label3;
                                                    }
                                                    if (a1[0].compareTo("POST") != 0) {
                                                        break label2;
                                                    }
                                                }
                                                if (b3) {
                                                    f7166d.write(a45, 0, a45.length);
                                                } else {
                                                    byte[] a51 = new byte[2048];
                                                    while(true) {
                                                        int i9 = a36.read(a51);
                                                        if (i9 < 0) {
                                                            break;
                                                        }
                                                        f7166d.write(a51, 0, i9);
                                                    }
                                                }
                                                f7166d.flush();
                                            }
                                            this.f7164b.close();
                                        } catch(Throwable a52) {
                                            a37 = a52;
                                            break label1;
                                        }
                                        a36.close();
                                        break label0;
                                    } else {
                                        m525a(404, "path not found", (String[])null, true, true);
                                        break label0;
                                    }
                                    a36.close();
                                    throw a37;
                                }
                                m525a(500, a35.getMessage(), (String[])null, true, true);
                                break label0;
                            }
                            m525a(404, "file not found", (String[])null, true, true);
                            break label0;
                        }
                        m525a(500, a11.getMessage(), (String[])null, true, true);
                        break label0;
                    } catch(Throwable a53) {
                        a0 = a53;
                    }
                }
                a0.printStackTrace();
            }
        }
    }

    @SuppressWarnings("ALL")
    class RunnableC2635c implements Runnable {
        RunnableC2635c() {
        }

        @Override
        public void run() {
            ArrayList<j> arrayList = new ArrayList();
            do {
                synchronized (HttpServer.f7135a) {
                    arrayList.clear();
                    Calendar gregorianCalendar = GregorianCalendar.getInstance();
                    gregorianCalendar.add(13, -HttpServer.f7146n);
                    Enumeration keys = HttpServer.f7151u.keys();
                    while (keys.hasMoreElements()) {
                        j jVar = (j) keys.nextElement();
                        if (HttpServer.f7143k.containsKey((String) HttpServer.f7151u.get(jVar))) {
                            if (!HttpServer.f7153w.containsKey(jVar)) {
                                HttpServer.f7153w.put(jVar, new Date());
                            }
                            if (gregorianCalendar.getTime().after((Date) HttpServer.f7153w.get(jVar))) {
                                arrayList.add(jVar);
                            }
                        }
                    }
                    if (arrayList.size() > 0) {
                        for (j jVar2 : arrayList) {
                            HttpServer.m557b(jVar2, HttpServer.this.getString(R.string.error_poor_connection_quality));
                            jVar2.b();
                        }
                    }
                }
                try {
                    Thread.sleep(1000L);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            } while (HttpServer.f7150t != null);
        }
    }

    static java.util.Hashtable e() {
        return f7151u;
    }

    static java.util.Hashtable f() {
        return f7143k;
    }

    static java.util.Hashtable g() {
        return f7153w;
    }

    static ru.proghouse.robocam.HttpServer h() {
        return f7150t;
    }

    static java.util.Hashtable i() {
        return f7142j;
    }

    static java.util.Hashtable j() {
        return f7152v;
    }

    static java.util.Hashtable k() {
        return f7137e;
    }

    static int l() {
        return f7145m;
    }

    static java.util.Hashtable m() {
        return f7154x;
    }

    static java.io.File n() {
        return f7149s;
    }

    static int o() {
        return f7148p;
    }

    static java.util.Hashtable p() {
        return f7144l;
    }

    static String q() {
        return f7155y;
    }

    static String r() {
        return f7156z;
    }

    static boolean s() {
        return f7134C;
    }

    static String t() {
        return f7132A;
    }

    static String u() {
        return f7133B;
    }

    static String v() {
        return f7138f;
    }

    static java.util.HashSet w() {
        return f7139g;
    }

    static java.util.HashSet x() {
        return f7140h;
    }

    static java.util.HashSet y() {
        return f7141i;
    }


    static {
        m532z();
        m572A();
        m571B();
        m570C();
    }

    public HttpServer() {
        super("RoboCamServer");
    }

    /* renamed from: A */
    private static void m572A() {
        f7139g.add(m555c("/index.html"));
    }

    /* renamed from: B */
    private static void m571B() {
        f7140h.add(m555c("/index.html"));
    }

    /* renamed from: C */
    private static void m570C() {
        f7141i.add(m555c("/login.html"));
        f7141i.add(m555c("/index.html"));
    }

    /* renamed from: D */
    private String m569D() {
        Exception e;
        String str = "";
        try {
            ZipFile zipFile = new ZipFile(getPackageManager().getApplicationInfo(getPackageName(), 0).sourceDir);
            str = m558b(new Date(zipFile.getEntry("classes.dex").getTime()));
            try {
                zipFile.close();
            } catch (Exception e2) {
                e = e2;
                e.printStackTrace();
                return str;
            }
        } catch (Exception e3) {
            e = e3;
        }
        return str;
    }

    /* renamed from: a */
    public static void m568a() {
        synchronized (f7135a) {
            if (f7150t != null) {
                f7150t.f7160r.m531a();
            }
        }
    }

    /* renamed from: a */
    public static void m567a(Context context) {
        synchronized (f7135a) {
            f7136b = 2;
        }
        C2709k.m44a();
        context.startService(new Intent(context, HttpServer.class));
    }

    /* renamed from: a */
    public static void m566a(Context context, boolean z) {
        synchronized (f7135a) {
            SharedPreferences sharedPreferences = context.getSharedPreferences("RoboCamSettings", 0);
            String str = f7155y;
            String str2 = f7156z;
            f7155y = sharedPreferences.getString("driver_name", "admin");
            f7156z = sharedPreferences.getString("driver_pswd", "123");
            String str3 = f7132A;
            String str4 = f7133B;
            f7132A = sharedPreferences.getString("spectator_name", "guest");
            f7133B = sharedPreferences.getString("spectator_pswd", "123");
            boolean z2 = f7134C;
            f7134C = sharedPreferences.getBoolean("allow_spectators", true);
            boolean z3 = sharedPreferences.getBoolean("use_local_controls", false);
            ArrayList<j> arrayList = new ArrayList();
            ArrayList<Socket> arrayList2 = new ArrayList();
            if (z || z3 || !((!z2 || f7134C) && str3 == f7132A && str4 == f7133B)) {
                Enumeration<j> keys = f7151u.keys();
                while (keys.hasMoreElements()) {
                    j nextElement = keys.nextElement();
                    if (f7144l.containsKey(f7151u.get(nextElement))) {
                        arrayList.add(nextElement);
                    }
                }
                Enumeration<String> keys2 = f7154x.keys();
                while (keys2.hasMoreElements()) {
                    String nextElement2 = keys2.nextElement();
                    if (f7144l.containsKey(nextElement2)) {
                        arrayList2.add(f7154x.get(nextElement2));
                    }
                }
                f7144l.clear();
            }
            if (z || z3 || str != f7155y || str2 != f7156z) {
                Enumeration<j> keys3 = f7151u.keys();
                while (keys3.hasMoreElements()) {
                    j nextElement3 = keys3.nextElement();
                    if (f7143k.containsKey(f7151u.get(nextElement3))) {
                        arrayList.add(nextElement3);
                    }
                }
                Enumeration<String> keys4 = f7154x.keys();
                while (keys4.hasMoreElements()) {
                    String nextElement4 = keys4.nextElement();
                    if (f7143k.containsKey(nextElement4)) {
                        arrayList2.add(f7154x.get(nextElement4));
                    }
                }
                f7143k.clear();
                AbstractC2677a.m322q().mo174n();
            }
            if (arrayList.size() > 0) {
                for (j jVar : arrayList) {
                    if (z) {
                        m557b(jVar, context.getString(R.string.error_server_has_been_turned_off));
                    } else if (z3) {
                        m557b(jVar, context.getString(R.string.error_local_controls_have_been_activated));
                    } else {
                        m557b(jVar, context.getString(R.string.error_security_settings_have_been_changed));
                    }
                    jVar.b();
                }
            }
            if (arrayList2.size() > 0) {
                for (Socket socket : arrayList2) {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    /* renamed from: a */
    public static void m565a(String str) {
        synchronized (f7135a) {
            if (f7150t != null) {
                f7150t.f7160r.m530a(str);
            }
        }
    }

    /* renamed from: b */
    public static int m561b() {
        int i;
        synchronized (f7135a) {
            i = f7147o;
        }
        return i;
    }

    /* renamed from: b */
    public static String m558b(Date date) {
        return new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.ENGLISH).format(date);
    }

    /* renamed from: b */
    public static void m560b(Context context) {
        context.stopService(new Intent(context, HttpServer.class));
    }

    static String b(String s0) {
        return ru.proghouse.robocam.HttpServer.m555c(s0);
    }


    /* renamed from: b */
    public static void m557b(j jVar, String str) {
        jVar.a("<msg><name>connectionWasBroken</name><reason>" + str + "</reason></msg>");
    }

    /* renamed from: c */
    public static int m556c() {
        int i;
        synchronized (f7135a) {
            i = f7136b;
        }
        return i;
    }

    /* renamed from: c */
    public static String m555c(String str) {
        return str.replace("/", f7138f).replace("\\", f7138f);
    }

    /* renamed from: z */
    private static void m532z() {
        f7137e.put(".htm", "text/html; charset=UTF-8");
        f7137e.put(".html", "text/html; charset=UTF-8");
        f7137e.put(".text", "text/plain");
        f7137e.put(".txt", "text/plain");
        f7137e.put(".js", "text/javascript; charset=UTF-8");
        f7137e.put(".xml", "text/xml; charset=UTF-8");
        f7137e.put(".css", "text/css");
        f7137e.put(".json", "application/json");
        f7137e.put(".ogg", "audio/ogg");
        f7137e.put(".m4a", "audio/mp4");
        f7137e.put(".wav", "audio/x-wav");
        f7137e.put(".png", "image/png");
        f7137e.put(".jpg", "image/jpeg");
        f7137e.put(".jpeg", "image/jpeg");
        f7137e.put(".gif", "image/gif");
        f7137e.put(".appcache", "text/cache-manifest");
    }

    @Override
    public void onDestroy() {
        try {
            synchronized (f7135a) {
                f7136b = 3;
                f7150t = null;
            }
            C2709k.m44a();
            this.f7158d = true;
            if (this.f7157c != null) {
                this.f7157c.close();
            }
            if (this.f7159q != null) {
                this.f7159q.b();
            }
            AbstractC2677a.m322q().mo174n();
            synchronized (f7135a) {
                f7136b = 0;
            }
            C2709k.m44a();
        } catch (IOException e) {
            e.printStackTrace();
        }
        super.onDestroy();
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        try {
            f7149s = C2714o.m0b(this);
            this.f7160r = new C2633a();
            this.f7159q = i.a(f7148p).a("/channel", this.f7160r);
            this.f7159q.a();
            String D = m569D();
            this.f7158d = false;
            this.f7157c = new ServerSocket(f7147o);
            synchronized (f7135a) {
                f7150t = this;
                f7136b = 1;
            }
            new Thread(new RunnableC2635c()).start();
            C2709k.m44a();
            while (!this.f7157c.isClosed() && !this.f7158d) {
                try {
                    new Thread(new RunnableC2634b(this, this.f7157c.accept(), getAssets(), D, getString(R.string.local_web_path))).start();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e2) {
            e2.printStackTrace();
        }
    }
}
