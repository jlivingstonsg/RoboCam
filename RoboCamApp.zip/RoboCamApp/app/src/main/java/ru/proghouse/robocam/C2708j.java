package ru.proghouse.robocam;

@SuppressWarnings("ALL")
public class C2708j {

    /* renamed from: a */
    public volatile boolean f7571a = false;

    /* renamed from: b */
    public byte[] f7572b = null;

    /* renamed from: c */
    public int f7573c = 0;

    /* renamed from: d */
    public byte[] f7574d = null;

    /* renamed from: e */
    public byte[] f7575e = null;

    /* renamed from: f */
    public byte[] f7576f = null;

    /* renamed from: g */
    public byte[] f7577g = null;

    /* renamed from: h */
    public byte[] f7578h = null;

    /* renamed from: i */
    public int f7579i = 0;

    /* renamed from: j */
    public int f7580j = 0;

    /* renamed from: k */
    public int f7581k = 0;

    /* renamed from: l */
    public int f7582l = 0;

    /* renamed from: m */
    public int f7583m = 0;

    /* renamed from: n */
    public int f7584n = 0;

    /* renamed from: o */
    public volatile boolean f7585o = false;

    /* renamed from: p */
    public volatile int f7586p = 0;

    /* renamed from: a */
    public void m45a() {
        this.f7571a = false;
        this.f7585o = false;
        this.f7586p = 0;
    }
}
