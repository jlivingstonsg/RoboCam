package ru.proghouse.robocam;

import android.app.Activity;
import android.support.v7.widget.AppCompatButton;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import java.util.List;

@SuppressWarnings("ALL")
public class C2712m {
    /* renamed from: a */
    public static CheckBox m19a(Activity activity, LinearLayout linearLayout, boolean z, int i, int i2) {
        CheckBox checkBox = new CheckBox(new ContextThemeWrapper(activity, (int) R.style.SettingsCheckBox), null, R.style.SettingsCheckBox);
        checkBox.setHeight(Math.round(TypedValue.applyDimension(1, 56.0f, activity.getResources().getDisplayMetrics())));
        checkBox.setChecked(z);
        checkBox.setText(i);
        checkBox.setPadding(i2, checkBox.getPaddingTop(), checkBox.getPaddingRight(), checkBox.getPaddingBottom());
        linearLayout.addView(checkBox);
        return checkBox;
    }

    /* renamed from: a */
    public static EditText m25a(Activity activity, LinearLayout linearLayout, float f, int i, int i2) {
        if (i != 0) {
            m24a(activity, linearLayout, i);
        }
        if (i2 != 0) {
            m15b(activity, linearLayout, i2);
        }
        EditText editText = new EditText(new ContextThemeWrapper(activity, (int) R.style.SettingsEditTextFloat), null, R.style.SettingsEditTextFloat);
        editText.setText(Float.toString(f));
        linearLayout.addView(editText);
        return editText;
    }

    /* renamed from: a */
    public static EditText m23a(Activity activity, LinearLayout linearLayout, int i, int i2, int i3) {
        if (i2 != 0) {
            m24a(activity, linearLayout, i2);
        }
        if (i3 != 0) {
            m15b(activity, linearLayout, i3);
        }
        EditText editText = new EditText(new ContextThemeWrapper(activity, (int) R.style.SettingsEditTextInteger), null, R.style.SettingsEditTextInteger);
        editText.setText(Integer.toString(i));
        linearLayout.addView(editText);
        return editText;
    }

    /* renamed from: a */
    public static EditText m21a(Activity activity, LinearLayout linearLayout, String str, int i, int i2) {
        if (i != 0) {
            m24a(activity, linearLayout, i);
        }
        if (i2 != 0) {
            m15b(activity, linearLayout, i2);
        }
        EditText editText = new EditText(new ContextThemeWrapper(activity, (int) R.style.SettingsEditText), null, R.style.SettingsEditText);
        editText.setText(str);
        linearLayout.addView(editText);
        return editText;
    }

    /* renamed from: a */
    public static ImageView m26a(Activity activity, LinearLayout linearLayout) {
        ImageView imageView = new ImageView(activity);
        imageView.setImageResource(R.drawable.spacer_small);
        linearLayout.addView(imageView);
        return imageView;
    }

    /* renamed from: a */
    public static Spinner m20a(Activity activity, LinearLayout linearLayout, List<String> list, int i, int i2, LinearLayout[] linearLayoutArr) {
        LinearLayout linearLayout2 = new LinearLayout(activity);
        if (linearLayoutArr != null && linearLayoutArr.length > 0) {
            linearLayoutArr[0] = linearLayout2;
        }
        linearLayout2.setOrientation(0);
        linearLayout2.setWeightSum(1.0f);
        linearLayout.addView(linearLayout2);
        Spinner spinner = new Spinner(new ContextThemeWrapper(activity, (int) R.style.SettingsSpinner), null, R.style.SettingsSpinner);
        m18a(spinner, activity, list, i2);
        spinner.setSelection(i);
        spinner.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout2.addView(spinner);
        ImageView imageView = new ImageView(activity);
        imageView.setBackgroundResource(R.drawable.abc_spinner);
        imageView.setLayoutParams(new LinearLayout.LayoutParams(-2, -1));
        linearLayout2.addView(imageView);
        return spinner;
    }

    /* renamed from: a */
    public static TextView m24a(Activity activity, LinearLayout linearLayout, int i) {
        TextView textView = new TextView(new ContextThemeWrapper(activity, (int) R.style.SettingsSectionEditTextTitle), null, R.style.SettingsSectionEditTextTitle);
        textView.setText(activity.getString(i));
        linearLayout.addView(textView);
        return textView;
    }

    /* renamed from: a */
    public static TextView m22a(Activity activity, LinearLayout linearLayout, String str) {
        TextView textView = new TextView(new ContextThemeWrapper(activity, (int) R.style.SettingsSectionEditTextDescBP), null, R.style.SettingsSectionEditTextDescBP);
        textView.setText(str);
        linearLayout.addView(textView);
        return textView;
    }

    /* renamed from: a */
    public static void m18a(Spinner spinner, Activity activity, List<String> list, int i) {
        m17a(spinner, activity, list, i, (int) R.layout.spinner_dropdown_item);
    }

    /* renamed from: a */
    public static void m17a(Spinner spinner, Activity activity, List<String> list, int i, int i2) {
        C2701d dVar = new C2701d(activity, spinner, R.layout.spinner_item, list, i);
        dVar.setDropDownViewResource(i2);
        spinner.setAdapter((SpinnerAdapter) dVar);
    }

    /* renamed from: b */
    public static ImageView m16b(Activity activity, LinearLayout linearLayout) {
        ImageView imageView = new ImageView(new ContextThemeWrapper(activity, (int) R.style.VerticalSeparator), null, R.style.VerticalSeparator);
        imageView.setLayoutParams(new ViewGroup.LayoutParams(-2, -1));
        linearLayout.addView(imageView);
        return imageView;
    }

    /* renamed from: b */
    public static TextView m15b(Activity activity, LinearLayout linearLayout, int i) {
        TextView textView = new TextView(new ContextThemeWrapper(activity, (int) R.style.SettingsSectionEditTextDesc), null, R.style.SettingsSectionEditTextDesc);
        textView.setText(activity.getString(i));
        linearLayout.addView(textView);
        return textView;
    }

    /* renamed from: c */
    public static Button m14c(Activity activity, LinearLayout linearLayout, int i) {
        AppCompatButton hVar = new AppCompatButton(new ContextThemeWrapper(activity, (int) R.style.SettingsActionButton), null, R.style.SettingsActionButton);
        hVar.setText(activity.getString(i));
        hVar.setFocusable(false);
        linearLayout.addView(hVar);
        return hVar;
    }
}
