package ru.proghouse.robocam;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Display;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
//import com.google.android.gms.ads.AbstractC0741a;
//import com.google.android.gms.ads.AdView;
//import com.google.android.gms.ads.C0759c;
import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import ru.proghouse.robocam.p062a.AbstractC2677a;

@SuppressWarnings("ALL")
public class LocalControllersActivity extends AppCompatActivity {

    /* renamed from: n */
    private static LocalControllersActivity f7190n = null;

    /* renamed from: o */
//    private AdView f7214o = null;

    /* renamed from: p */
    private WebView f7215p = null;

    /* renamed from: q */
    private String f7216q = null;

    /* renamed from: r */
    private double f7217r = 0.0d;

    /* renamed from: s */
    private int f7218s = 0;

    /* renamed from: t */
    private int f7219t = 0;

    /* renamed from: u */
    private int f7220u = 0;

    /* renamed from: v */
    private String f7221v = "";

    /* renamed from: w */
    private boolean f7222w = false;

    /* renamed from: x */
    private volatile boolean f7223x = false;

    /* renamed from: y */
    private ImageView f7224y = null;

    /* renamed from: z */
    private ImageView f7225z = null;

    /* renamed from: A */
    private ImageView f7191A = null;

    /* renamed from: B */
    private ImageView f7192B = null;

    /* renamed from: C */
    private ImageView f7193C = null;

    /* renamed from: D */
    private ImageView f7194D = null;

    /* renamed from: E */
    private TextView f7195E = null;

    /* renamed from: F */
    private TextView f7196F = null;

    /* renamed from: G */
    private RelativeLayout f7197G = null;

    /* renamed from: H */
    private String f7198H = "left-handed";

    /* renamed from: I */
    private int[] f7199I = {0, 0, 0, 0, 0, 0, 0, 0};

    /* renamed from: J */
    private int[] f7200J = {0, 0, 0, 0, 0, 0, 0, 0};

    /* renamed from: K */
    private int f7201K = -1;

    /* renamed from: L */
    private int f7202L = -1;

    /* renamed from: M */
    private boolean f7203M = true;

    /* renamed from: N */
    private boolean f7204N = false;

    /* renamed from: O */
    private boolean f7205O = true;

    /* renamed from: P */
    private boolean f7206P = false;

    /* renamed from: Q */
    private String f7207Q = "xywzabcd";

    /* renamed from: R */
    private String f7208R = "----";

    /* renamed from: S */
    private String f7209S = "00000000";

    /* renamed from: T */
    private int f7210T = 0;

    /* renamed from: U */
    private double f7211U = 1.0d;

    /* renamed from: V */
    private HashSet<Integer> f7212V = new HashSet<>();

    /* renamed from: W */
    private HashSet<Integer> f7213W = new HashSet<>();

    /* renamed from: a */
    private double m500a(ImageView imageView) {
        return (imageView.getLeft() + imageView.getRight()) / 2;
    }

    /* renamed from: a */
    private void m499a(ImageView imageView, int i) {
        String substring = this.f7208R.substring(i, i + 1);
        if (substring.equals("v")) {
            imageView.setImageResource(R.drawable.joystick1);
        } else if (substring.equals("c")) {
            imageView.setImageResource(R.drawable.joystick2);
        } else if (substring.equals("q")) {
            imageView.setImageResource(R.drawable.joystick3);
        } else if (substring.equals("a")) {
            imageView.setImageResource(R.drawable.joystick4);
        } else if (substring.equals("h")) {
            imageView.setImageResource(R.drawable.joystick7);
        } else if (substring.equals("t")) {
            imageView.setImageResource(R.drawable.joystick5);
        } else if (substring.equals("l")) {
            imageView.setImageResource(R.drawable.joystick6);
        }
        if (substring.equals("-")) {
            imageView.setVisibility(4);
        } else {
            imageView.setVisibility(0);
        }
    }

    /* renamed from: a */
    private void m497a(String str, double[] dArr) {
        double d;
        double d2;
        double d3;
        double d4;
        if (str.equals("v")) {
            dArr[0] = 0.0d;
            dArr[1] = dArr[1] < -100.0d ? -100.0d : dArr[1] > 100.0d ? 100.0d : dArr[1];
        } else if (str.equals("h")) {
            dArr[0] = dArr[0] < -100.0d ? -100.0d : dArr[0] > 100.0d ? 100.0d : dArr[0];
            dArr[1] = 0.0d;
        } else if (str.equals("c") && Math.sqrt((dArr[0] * dArr[0]) + (dArr[1] * dArr[1])) > 100.0d) {
            double atan2 = (Math.atan2(dArr[0], dArr[1]) - 1.5707963267948966d) * (-1.0d);
            dArr[0] = Math.cos(atan2) * 100.0d;
            dArr[1] = Math.sin(atan2) * 100.0d;
        } else if (str.equals("q")) {
            dArr[0] = dArr[0] < -100.0d ? -100.0d : dArr[0] > 100.0d ? 100.0d : dArr[0];
            dArr[1] = dArr[1] < -100.0d ? -100.0d : dArr[1] > 100.0d ? 100.0d : dArr[1];
        } else if (str.equals("t")) {
            if ((dArr[1] > -40.0d) && (dArr[1] < 40.0d)) {
                if ((dArr[0] >= -100.0d) && (dArr[0] < -40.0d)) {
                    d4 = -100.0d;
                } else {
                    d4 = ((dArr[0] > 100.0d ? 1 : (dArr[0] == 100.0d ? 0 : -1)) <= 0) & ((dArr[0] > 40.0d ? 1 : (dArr[0] == 40.0d ? 0 : -1)) > 0) ? 100.0d : 0.0d;
                }
            } else {
                d4 = 0.0d;
            }
            dArr[0] = d4;
            dArr[1] = 0.0d;
        } else if (str.equals("l")) {
            dArr[0] = 0.0d;
            if ((dArr[0] > -40.0d) && (dArr[0] < 40.0d)) {
                if ((dArr[1] >= -100.0d) && (dArr[1] < -40.0d)) {
                    d3 = -100.0d;
                } else {
                    d3 = ((dArr[1] > 100.0d ? 1 : (dArr[1] == 100.0d ? 0 : -1)) <= 0) & ((dArr[1] > 40.0d ? 1 : (dArr[1] == 40.0d ? 0 : -1)) > 0) ? 100.0d : 0.0d;
                }
            } else {
                d3 = 0.0d;
            }
            dArr[1] = d3;
        } else if (str.equals("a")) {
            if ((dArr[1] > -40.0d) && (dArr[1] < 40.0d)) {
                if ((dArr[0] >= -100.0d) && (dArr[0] < -40.0d)) {
                    d = -100.0d;
                } else {
                    d = ((dArr[0] > 100.0d ? 1 : (dArr[0] == 100.0d ? 0 : -1)) <= 0) & ((dArr[0] > 40.0d ? 1 : (dArr[0] == 40.0d ? 0 : -1)) > 0) ? 100.0d : 0.0d;
                }
            } else {
                d = 0.0d;
            }
            dArr[0] = d;
            if ((dArr[0] > -40.0d) && (dArr[0] < 40.0d)) {
                if ((dArr[1] >= -100.0d) && (dArr[1] < -40.0d)) {
                    d2 = -100.0d;
                } else {
                    d2 = ((dArr[1] > 100.0d ? 1 : (dArr[1] == 100.0d ? 0 : -1)) <= 0) & ((dArr[1] > 40.0d ? 1 : (dArr[1] == 40.0d ? 0 : -1)) > 0) ? 100.0d : 0.0d;
                }
            } else {
                d2 = 0.0d;
            }
            dArr[1] = d2;
        }
        dArr[0] = Math.round(dArr[0]);
        dArr[1] = Math.round(dArr[1]);
    }

    /* renamed from: a */
    private boolean m498a(ImageView imageView, int i, int i2) {
        return imageView.getLeft() <= i && imageView.getRight() >= i && imageView.getTop() <= i2 && imageView.getBottom() >= i2;
    }

    /* renamed from: b */
    private double m494b(ImageView imageView) {
        return (imageView.getTop() + imageView.getBottom()) / 2;
    }

    /* renamed from: c */
    private double m490c(ImageView imageView) {
        return (imageView.getWidth() * 450) / 540;
    }

    /* renamed from: c */
    private boolean m491c(int i) {
        try {
            return this.f7209S.substring(i, i + 1).equals("0");
        } catch (Throwable th) {
            th.printStackTrace();
            return true;
        }
    }

    /* renamed from: d */
    private String m488d(int i) {
        return this.f7208R.substring(i, i + 1);
    }

    /* renamed from: e */
    private void m486e(int i) {
        if (i == 1) {
            this.f7201K = -1;
            if (this.f7210T == 0) {
                if (m491c(0)) {
                    this.f7199I[0] = 0;
                }
                if (m491c(1)) {
                    this.f7199I[1] = 0;
                    return;
                }
                return;
            }
            if (m491c(4)) {
                this.f7199I[4] = 0;
            }
            if (m491c(5)) {
                this.f7199I[5] = 0;
                return;
            }
            return;
        }
        this.f7202L = -1;
        if (this.f7210T == 0) {
            if (m491c(2)) {
                this.f7199I[2] = 0;
            }
            if (m491c(3)) {
                this.f7199I[3] = 0;
                return;
            }
            return;
        }
        if (m491c(6)) {
            this.f7199I[6] = 0;
        }
        if (m491c(7)) {
            this.f7199I[7] = 0;
        }
    }

    /* renamed from: f */
    private int m484f(int i) {
        if (i >= 29 && i <= 54) {
            return (i - 29) + 65;
        }
        if (i >= 7 && i <= 16) {
            return (i - 7) + 48;
        }
        if (i == 67) {
            return 8;
        }
        if (i == 59 || i == 60) {
            return 16;
        }
        if (i == 113 || i == 114) {
            return 17;
        }
        if (i == 57 || i == 58) {
            return 18;
        }
        if (i == 143) {
            return 144;
        }
        if (i == 116) {
            return 145;
        }
        if (i >= 144 && i <= 153) {
            return (i - 144) + 96;
        }
        if (i == 121) {
            return 19;
        }
        if (i == 68) {
            return 192;
        }
        if (i == 69) {
            return 189;
        }
        if (i == 71) {
            return 219;
        }
        if (i == 72) {
            return 221;
        }
        if (i == 73) {
            return 220;
        }
        if (i == 74) {
            return 186;
        }
        if (i == 75) {
            return 222;
        }
        if (i == 55) {
            return 188;
        }
        if (i == 56) {
            return 190;
        }
        if (i == 76) {
            return 191;
        }
        if (i == 132) {
            return 113;
        }
        if (i == 134) {
            return 115;
        }
        if (i == 137) {
            return 118;
        }
        if (i == 138) {
            return 119;
        }
        if (i == 139) {
            return 120;
        }
        if (i == 140) {
            return 121;
        }
        if (i == 61) {
            return 9;
        }
        if (i == 28) {
            return 12;
        }
        if (i == 66) {
            return 13;
        }
        if (i == 115) {
            return 20;
        }
        if (i == 111) {
            return 27;
        }
        if (i == 62) {
            return 32;
        }
        if (i == 92) {
            return 33;
        }
        if (i == 93) {
            return 34;
        }
        if (i == 123) {
            return 35;
        }
        if (i == 122) {
            return 36;
        }
        if (i == 21) {
            return 37;
        }
        if (i == 19) {
            return 38;
        }
        if (i == 22) {
            return 39;
        }
        if (i == 20) {
            return 40;
        }
        if (i == 124) {
            return 45;
        }
        if (i == 112) {
            return 46;
        }
        if (i == 155) {
            return R.styleable.AppCompatTheme_editTextStyle;
        }
        if (i == 157) {
            return R.styleable.AppCompatTheme_radioButtonStyle;
        }
        if (i == 156) {
            return R.styleable.AppCompatTheme_ratingBarStyleIndicator;
        }
        if (i == 158) {
            return R.styleable.AppCompatTheme_ratingBarStyleSmall;
        }
        return 0;
    }

    /* renamed from: j */
    public static void m482j() {
        if (f7190n != null) {
            f7190n.f7197G.post(new Runnable() {
                @Override
                public void run() {
                    if (LocalControllersActivity.f7190n != null) {
                        LocalControllersActivity.f7190n.m477o();
                    }
                }
            });
        }
    }

    /* renamed from: l */
    private void m480l() {
        if (Build.VERSION.SDK_INT <= 17) {
            getWindow().setFlags(1024, 1024);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(6150);
        }
    }

    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void m479m() {
        Exception e;
        File b = null;
        File file = null;
        float f;
        float f2;
        String str = null;
        boolean z = true;
        if (!this.f7223x) {
            this.f7223x = true;
            try {
                b = C2714o.m0b(this);
                file = new File(b, "v.xml");
            } catch (Exception e2) {
                e = e2;
            }
            if (file.exists()) {
                Element[] elementArr = {null};
                String[] strArr = {null};
                String[] strArr2 = {null};
                Document parse = null;
                try {
                    parse = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(file);
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                } catch (SAXException saxException) {
                    saxException.printStackTrace();
                } catch (ParserConfigurationException parserConfigurationException) {
                    parserConfigurationException.printStackTrace();
                }
                if (MainActivity.m465a(parse, MainActivity.m468a(this), elementArr, strArr, strArr2)) {
                    File file2 = new File(b, parse.getDocumentElement().getAttribute("number"));
                    for (int i = 0; i < elementArr[0].getChildNodes().getLength(); i++) {
                        if (elementArr[0].getChildNodes().item(i).getNodeName().equals("device")) {
                            Element element = (Element) elementArr[0].getChildNodes().item(i);
                            if ((element.getAttribute("target") == null || element.getAttribute("target").isEmpty() || element.getAttribute("target").equals("server")) && ((element.getAttribute("screenMin") == null || element.getAttribute("screenMin").isEmpty() || this.f7217r >= Double.parseDouble(element.getAttribute("screenMin"))) && (element.getAttribute("sdkMin") == null || element.getAttribute("sdkMin").isEmpty() || Build.VERSION.SDK_INT >= Integer.parseInt(element.getAttribute("sdkMin"))))) {
                                str = element.getAttribute("path");
                                this.f7216q = element.getAttribute("url");
                                float parseFloat = Float.parseFloat(element.getAttribute("width"));
                                float parseFloat2 = Float.parseFloat(element.getAttribute("height"));
                                f2 = TypedValue.applyDimension(1, parseFloat, getResources().getDisplayMetrics());
                                f = TypedValue.applyDimension(1, parseFloat2, getResources().getDisplayMetrics());
                                this.f7221v = element.getAttribute("type");
                                break;
                            }
                        }
                    }
                    f = 0.0f;
                    f2 = 0.0f;
                    if (str != null && f2 > 0.0f && f > 0.0f && (this.f7221v.equals("replace") || (this.f7221v.equals("offline") && this.f7222w))) {
                        File file3 = new File(file2, str);
                        if (file3.exists()) {
                            String uri = file3.toURI().toString();
                            this.f7215p.getSettings().setJavaScriptEnabled(true);
                            this.f7215p.loadUrl(uri);
                            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(Math.round(f2), Math.round(f));
                            layoutParams.addRule(14);
                            this.f7215p.setLayoutParams(layoutParams);
                            try {
                                this.f7215p.setVisibility(0);
//                                this.f7214o.setVisibility(8);
                                z = false;
                            } catch (Exception e3) {
                                e = e3;
                                z = false;
                                e.printStackTrace();
                                if (z) {
                                }
                            }
                            if (z) {
                                try {
                                    this.f7215p.setVisibility(8);
//                                    this.f7214o.setVisibility(0);
//                                    C0759c a = new C0759c.C0761a().m5485a();
//                                    this.f7214o.setAdListener(new AbstractC0741a() {
//                                        @Override
//                                        /* renamed from: a */
//                                        public void mo411a() {
//                                            try {
//                                                LocalControllersActivity.this.f7215p.setVisibility(8);
//                                                LocalControllersActivity.this.f7214o.setVisibility(0);
//                                            } catch (Throwable th) {
//                                                th.printStackTrace();
//                                            }
//                                        }
//
//                                        @Override
//                                        /* renamed from: a */
//                                        public void mo410a(int i2) {
//                                            try {
//                                                if (LocalControllersActivity.this.f7221v.equals("offline")) {
//                                                    LocalControllersActivity.this.f7222w = true;
//                                                    LocalControllersActivity.this.f7223x = false;
//                                                    LocalControllersActivity.this.m479m();
//                                                }
//                                            } catch (Throwable th) {
//                                                th.printStackTrace();
//                                            }
//                                        }
//
//                                        @Override
//                                        /* renamed from: b */
//                                        public void mo409b() {
//                                            try {
//                                                LocalControllersActivity.this.f7215p.setVisibility(8);
//                                                LocalControllersActivity.this.f7214o.setVisibility(0);
//                                            } catch (Throwable th) {
//                                                th.printStackTrace();
//                                            }
//                                        }
//                                    });
//                                    this.f7214o.mo5446a(a);
                                    return;
                                } catch (Throwable th) {
                                    th.printStackTrace();
                                    return;
                                }
                            } else {
                                return;
                            }
                        }
                    }
                }
                if (z) {
                }
            }
        }
    }

    /* renamed from: n */
    private void m478n() {
        boolean z;
        int i = 0;
        while (true) {
            if (i >= 8) {
                z = false;
                break;
            } else if (this.f7199I[i] != this.f7200J[i]) {
                z = true;
                break;
            } else {
                i++;
            }
        }
        if (z) {
            String str = "";
            Hashtable hashtable = new Hashtable();
            for (int i2 = 0; i2 < 8; i2++) {
                if (this.f7199I[i2] != this.f7200J[i2]) {
                    hashtable.put(this.f7207Q.substring(i2, i2 + 1), Integer.valueOf(this.f7199I[i2]));
                    str = str + this.f7207Q.substring(i2, i2 + 1) + "=" + Integer.toString(this.f7199I[i2]) + ";";
                }
            }
            TextView textView = this.f7195E;
            if (str.length() > 0) {
                str = str.substring(0, str.length() - 1);
            }
            textView.setText(str);
            C2709k.m41a(hashtable);
            for (int i3 = 0; i3 < 8; i3++) {
                this.f7200J[i3] = this.f7199I[i3];
            }
        }
    }

    /* renamed from: o */
    public void m477o() {
        int i = 4;
        boolean z = false;
        try {
            this.f7208R = AbstractC2677a.m322q().mo182j() ? AbstractC2677a.m322q().mo199c() : "----";
            this.f7209S = AbstractC2677a.m322q().mo182j() ? AbstractC2677a.m322q().mo206b() : "00000000";
            this.f7205O = AbstractC2677a.m322q().mo182j() ? AbstractC2677a.m322q().m319t() : true;
            TextView textView = this.f7195E;
            if (this.f7205O) {
                i = 0;
            }
            textView.setVisibility(i);
            this.f7212V.clear();
            if (AbstractC2677a.m322q().mo182j()) {
                String d = AbstractC2677a.m322q().mo195d();
                for (int i2 = 0; i2 < d.length() / 3; i2++) {
                    this.f7212V.add(new Integer(d.substring(i2 * 3, (i2 * 3) + 3)));
                }
            }
            if (AbstractC2677a.m322q().mo182j()) {
                z = AbstractC2677a.m322q().mo192e();
            }
            this.f7204N = z;
            if (this.f7203M) {
                if (this.f7198H.equals("left-handed")) {
                    this.f7225z = (ImageView) findViewById(R.id.imageViewJoystick1);
                    this.f7224y = (ImageView) findViewById(R.id.imageViewJoystick2);
                    this.f7194D.setImageResource(R.drawable.hands_r);
                } else {
                    this.f7225z = (ImageView) findViewById(R.id.imageViewJoystick2);
                    this.f7224y = (ImageView) findViewById(R.id.imageViewJoystick1);
                    this.f7194D.setImageResource(R.drawable.hands_l);
                }
                if (this.f7210T == 0 && this.f7208R.substring(0, 2).equals("--")) {
                    this.f7210T = 1;
                }
                if (this.f7210T == 1 && this.f7208R.substring(2, 4).equals("--")) {
                    this.f7210T = 0;
                }
                if (this.f7210T == 0) {
                    m499a(this.f7225z, 0);
                    m499a(this.f7224y, 1);
                } else {
                    m499a(this.f7225z, 2);
                    m499a(this.f7224y, 3);
                }
                if (this.f7208R.substring(0, 2).equals("--") || this.f7208R.substring(2, 4).equals("--")) {
                    this.f7191A.setVisibility(4);
                } else {
                    this.f7191A.setVisibility(0);
                }
                if (this.f7210T == 0) {
                    this.f7191A.setImageResource(R.drawable.joystick_1_2);
                } else {
                    this.f7191A.setImageResource(R.drawable.joystick_3_4);
                }
                if (this.f7208R.equals("----")) {
                    this.f7194D.setVisibility(4);
                } else {
                    this.f7194D.setVisibility(0);
                }
            } else {
                this.f7225z.setVisibility(4);
                this.f7224y.setVisibility(4);
                this.f7191A.setVisibility(4);
                this.f7194D.setVisibility(4);
            }
            if (!AbstractC2677a.m322q().mo182j()) {
                this.f7196F.setText(R.string.robot_is_not_connected);
            } else {
                this.f7196F.setText("");
            }
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }

    /* renamed from: p */
    private void m476p() {
        if (this.f7204N && this.f7203M && this.f7213W.size() > 0) {
            this.f7203M = false;
            m477o();
        }
        String str = "";
        Iterator<Integer> it = this.f7213W.iterator();
        while (it.hasNext()) {
            Integer next = it.next();
            if (!str.isEmpty()) {
                str = str + ", ";
            }
            str = str + next.toString();
        }
        this.f7195E.setText(str);
        C2709k.m42a((HashSet) this.f7213W.clone());
    }

    @Override
    public void onCreate(Bundle bundle) {
        int i;
        super.onCreate(bundle);
        setContentView(R.layout.activity_local_controllers);
        f7190n = this;
        this.f7197G = (RelativeLayout) findViewById(R.id.parentLayout);
//        m6459f().mo6331b();
        getSupportActionBar().show();
        m480l();
        SharedPreferences sharedPreferences = getSharedPreferences("RoboCamSettings", 0);
        this.f7198H = sharedPreferences.getString("local_control", "left-handed");
        this.f7210T = sharedPreferences.getInt("joystick_current_panel", 0);
        this.f7206P = sharedPreferences.getBoolean("maximize_joysticks", false);
        if (this.f7198H.equals("left-handed")) {
            this.f7225z = (ImageView) findViewById(R.id.imageViewJoystick1);
            this.f7224y = (ImageView) findViewById(R.id.imageViewJoystick2);
        } else {
            this.f7225z = (ImageView) findViewById(R.id.imageViewJoystick2);
            this.f7224y = (ImageView) findViewById(R.id.imageViewJoystick1);
        }
        this.f7195E = (TextView) findViewById(R.id.textViewDebugMessage);
        this.f7195E.setText("");
        this.f7196F = (TextView) findViewById(R.id.textViewText);
        this.f7196F.setText("");
        this.f7192B = (ImageView) findViewById(R.id.imageViewEmpty1);
        this.f7191A = (ImageView) findViewById(R.id.imageViewCurrentJoystick);
        this.f7193C = (ImageView) findViewById(R.id.imageViewEmpty2);
        this.f7194D = (ImageView) findViewById(R.id.imageViewHands);
        Display defaultDisplay = getWindowManager().getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        defaultDisplay.getMetrics(displayMetrics);
        int i2 = displayMetrics.widthPixels;
        int i3 = displayMetrics.heightPixels;
        if (Build.VERSION.SDK_INT < 14 || Build.VERSION.SDK_INT >= 17) {
            i = i3;
            i2 = i2;
        } else {
            try {
                i2 = ((Integer) Display.class.getMethod("getRawWidth", new Class[0]).invoke(defaultDisplay, new Object[0])).intValue();
                i = ((Integer) Display.class.getMethod("getRawHeight", new Class[0]).invoke(defaultDisplay, new Object[0])).intValue();
                i2 = i2;
            } catch (Exception e) {
                e.printStackTrace();
                i = i3;
            }
        }
        if (Build.VERSION.SDK_INT >= 17) {
            try {
                Point point = new Point();
                Display.class.getMethod("getRealSize", Point.class).invoke(defaultDisplay, point);
                i2 = point.x;
                i = point.y;
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        this.f7219t = i2;
        this.f7220u = i;
        this.f7218s = Math.min(i2, i);
        this.f7211U = this.f7218s / 1080.0d;
        this.f7217r = Math.min(i2 / displayMetrics.density, i / displayMetrics.density);
        this.f7225z.setVisibility(4);
        this.f7224y.setVisibility(4);
        int i4 = this.f7218s / 2;
        if (this.f7206P && i2 > i) {
            i4 = (int) Math.min((i - (120.0d * this.f7211U)) - (30.0d * this.f7211U), i2 / 2.0d);
        }
        int i5 = (int) (120.0d * this.f7211U);
        int i6 = (int) (30.0d * this.f7211U);
        this.f7224y.getLayoutParams().width = i4;
        this.f7224y.getLayoutParams().height = i4;
        this.f7225z.getLayoutParams().width = i4;
        this.f7225z.getLayoutParams().height = i4;
        this.f7192B.getLayoutParams().width = i6;
        this.f7192B.getLayoutParams().height = i6;
        this.f7191A.getLayoutParams().width = i5;
        this.f7191A.getLayoutParams().height = i5;
        this.f7193C.getLayoutParams().width = i6;
        this.f7193C.getLayoutParams().height = i6;
        this.f7194D.getLayoutParams().width = i5;
        this.f7194D.getLayoutParams().height = i5;
        this.f7195E.setTextSize(0, Math.round(this.f7218s / 32));
        this.f7196F.setTextSize(0, Math.round(this.f7218s / 32));
        if (this.f7206P && i2 > i) {
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(i5, i5);
            layoutParams.addRule(3, R.id.imageViewEmpty2);
            layoutParams.addRule(0, R.id.imageViewEmpty2);
            this.f7191A.setLayoutParams(layoutParams);
            RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(i6, i6);
            layoutParams2.addRule(3, R.id.imageViewEmpty2);
            layoutParams2.addRule(0, R.id.imageViewCurrentJoystick);
            this.f7192B.setLayoutParams(layoutParams2);
            RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams(i5, i5);
            layoutParams3.addRule(3, R.id.imageViewEmpty2);
            layoutParams3.addRule(0, R.id.imageViewEmpty1);
            this.f7194D.setLayoutParams(layoutParams3);
        }
        m477o();
//        this.f7214o = (AdView) findViewById(R.id.adView);
        this.f7215p = (WebView) findViewById(R.id.banner);
        this.f7215p.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case 1:
                        if (LocalControllersActivity.this.f7216q == null || LocalControllersActivity.this.f7216q.isEmpty()) {
                            return false;
                        }
                        LocalControllersActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(LocalControllersActivity.this.f7216q)));
                        return false;
                    default:
                        return false;
                }
            }
        });
        this.f7215p.setVisibility(8);
//        this.f7214o.setVisibility(8);
        m479m();
    }

    public void onCurrentJoystickClick(View view) {
        if (this.f7201K < 0 && this.f7202L < 0 && this.f7191A.getVisibility() == 0) {
            if (this.f7210T == 0) {
                this.f7210T = 1;
            } else {
                this.f7210T = 0;
            }
            m477o();
            SharedPreferences.Editor edit = getSharedPreferences("RoboCamSettings", 0).edit();
            edit.putInt("joystick_current_panel", this.f7210T);
            if (Build.VERSION.SDK_INT >= 9) {
                edit.apply();
            } else {
                edit.commit();
            }
        }
    }

    public void onHandsClick(View view) {
        if (this.f7201K < 0 && this.f7202L < 0 && this.f7194D.getVisibility() == 0) {
            if (this.f7198H.equals("left-handed")) {
                this.f7198H = "right-handed";
            } else {
                this.f7198H = "left-handed";
            }
            m477o();
            SharedPreferences.Editor edit = getSharedPreferences("RoboCamSettings", 0).edit();
            edit.putString("local_control", this.f7198H);
            if (Build.VERSION.SDK_INT >= 9) {
                edit.apply();
            } else {
                edit.commit();
            }
        }
    }

    @Override
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        int f = m484f(i);
        if (this.f7212V.contains(Integer.valueOf(f)) && !this.f7213W.contains(Integer.valueOf(f))) {
            this.f7213W.add(Integer.valueOf(f));
            m476p();
        }
        if (f > 0) {
            return true;
        }
        return super.onKeyDown(i, keyEvent);
    }

    @Override
    public boolean onKeyUp(int i, KeyEvent keyEvent) {
        if (keyEvent.getDownTime() == keyEvent.getEventTime()) {
            return super.onKeyUp(i, keyEvent);
        }
        int f = m484f(i);
        if (this.f7213W.contains(Integer.valueOf(f))) {
            this.f7213W.remove(Integer.valueOf(f));
            m476p();
        }
        if (f > 0) {
            return true;
        }
        return super.onKeyUp(i, keyEvent);
    }

    @Override
    public void onPause() {
        f7190n = null;
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        f7190n = this;
        m482j();
        m480l();
    }

    @Override
    public boolean onTouchEvent(MotionEvent motionEvent) {
        try {
            switch (motionEvent.getActionMasked()) {
                case 0:
                case 5:
                    int x = (int) motionEvent.getX(motionEvent.getActionIndex());
                    int y = (int) motionEvent.getY(motionEvent.getActionIndex());
                    if (m498a(this.f7225z, x, y) && this.f7201K < 0 && this.f7203M) {
                        this.f7201K = motionEvent.getPointerId(motionEvent.getActionIndex());
                    } else if (m498a(this.f7224y, x, y) && this.f7202L < 0 && this.f7203M) {
                        this.f7202L = motionEvent.getPointerId(motionEvent.getActionIndex());
                    }
                    if (!this.f7203M) {
                        this.f7203M = true;
                        m482j();
                        break;
                    }
                    break;
                case 1:
                case 3:
                case 6:
                    if (this.f7201K != motionEvent.getPointerId(motionEvent.getActionIndex())) {
                        if (this.f7202L == motionEvent.getPointerId(motionEvent.getActionIndex())) {
                            m486e(2);
                            break;
                        }
                    } else {
                        m486e(1);
                        break;
                    }
                    break;
            }
            double[] dArr = {0.0d, 0.0d};
            for (int i = 0; i < motionEvent.getPointerCount(); i++) {
                if (this.f7201K >= 0 && motionEvent.getPointerId(i) == this.f7201K) {
                    dArr[0] = (((m500a(this.f7225z) - motionEvent.getX(i)) * 100.0d) / m490c(this.f7225z)) * 2.0d * (-1.0d);
                    dArr[1] = (((m494b(this.f7225z) - motionEvent.getY(i)) * 100.0d) / m490c(this.f7225z)) * 2.0d;
                    if (this.f7210T == 0 && !m488d(0).equals("-")) {
                        m497a(m488d(0), dArr);
                        this.f7199I[0] = (int) dArr[0];
                        this.f7199I[1] = (int) dArr[1];
                    }
                    if (this.f7210T == 1 && !m488d(2).equals("-")) {
                        m497a(m488d(2), dArr);
                        this.f7199I[4] = (int) dArr[0];
                        this.f7199I[5] = (int) dArr[1];
                    }
                }
                if (this.f7202L >= 0 && motionEvent.getPointerId(i) == this.f7202L) {
                    dArr[0] = (((m500a(this.f7224y) - motionEvent.getX(i)) * 100.0d) / m490c(this.f7224y)) * 2.0d * (-1.0d);
                    dArr[1] = (((m494b(this.f7224y) - motionEvent.getY(i)) * 100.0d) / m490c(this.f7224y)) * 2.0d;
                    if (this.f7210T == 0 && !m488d(1).equals("-")) {
                        m497a(m488d(1), dArr);
                        this.f7199I[2] = (int) dArr[0];
                        this.f7199I[3] = (int) dArr[1];
                    }
                    if (this.f7210T == 1 && !m488d(3).equals("-")) {
                        m497a(m488d(3), dArr);
                        this.f7199I[6] = (int) dArr[0];
                        this.f7199I[7] = (int) dArr[1];
                    }
                }
            }
            m478n();
        } catch (Throwable th) {
            th.printStackTrace();
        }
        return false;
    }
}
