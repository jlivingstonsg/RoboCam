package ru.proghouse.robocam;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import ru.proghouse.robocam.p062a.AbstractC2677a;

@SuppressWarnings("ALL")
public class C2709k {

    /* renamed from: a */
    public static boolean f7587a = false;

    /* renamed from: b */
    private static List<AbstractC2710a> f7588b = new ArrayList();

    /* renamed from: c */
    private static volatile Date f7589c = new Date();

    @SuppressWarnings("ALL")
    public interface AbstractC2710a {
        /* renamed from: l */
        void mo36l();
    }

    /* renamed from: a */
    public static void m44a() {
        synchronized (HttpServer.f7135a) {
            for (int i = 0; i < f7588b.size(); i++) {
                f7588b.get(i).mo36l();
            }
        }
    }

    /* renamed from: a */
    public static void m43a(Date date) {
        f7589c = date;
    }

    /* renamed from: a */
    public static void m42a(HashSet<Integer> hashSet) {
        AbstractC2677a.m322q().mo221a(hashSet);
    }

    /* renamed from: a */
    public static void m41a(Hashtable<String, Integer> hashtable) {
        AbstractC2677a.m322q().mo220a(hashtable);
    }

    /* renamed from: a */
    public static void m40a(AbstractC2710a aVar) {
        synchronized (HttpServer.f7135a) {
            if (f7588b.indexOf(aVar) < 0) {
                f7588b.add(aVar);
            }
        }
    }

    /* renamed from: b */
    public static Date m39b() {
        return f7589c;
    }

    /* renamed from: b */
    public static void m38b(AbstractC2710a aVar) {
        synchronized (HttpServer.f7135a) {
            f7588b.remove(aVar);
        }
    }

    /* renamed from: c */
    public static void m37c() {
        HttpServer.m568a();
        LocalControllersActivity.m482j();
    }
}
